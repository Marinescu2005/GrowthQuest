import { 
  users, progressEntries, journalEntries, achievements, userSettings, statistics,
  type User, type InsertUser, type ProgressEntry, type InsertProgressEntry,
  type JournalEntry, type InsertJournalEntry, type Achievement, type InsertAchievement,
  type UserSettings, type InsertUserSettings, type Statistics, type InsertStatistics
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;

  // Progress operations
  getProgressEntries(userId: number): Promise<ProgressEntry[]>;
  createProgressEntry(entry: InsertProgressEntry): Promise<ProgressEntry>;
  updateProgressEntry(id: number, updates: Partial<ProgressEntry>): Promise<ProgressEntry | undefined>;

  // Journal operations
  getJournalEntries(userId: number): Promise<JournalEntry[]>;
  createJournalEntry(entry: InsertJournalEntry): Promise<JournalEntry>;
  updateJournalEntry(id: number, updates: Partial<JournalEntry>): Promise<JournalEntry | undefined>;
  deleteJournalEntry(id: number): Promise<boolean>;

  // Achievement operations
  getAchievements(userId: number): Promise<Achievement[]>;
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;

  // Settings operations
  getUserSettings(userId: number): Promise<UserSettings | undefined>;
  updateUserSettings(userId: number, settings: Partial<InsertUserSettings>): Promise<UserSettings>;

  // Statistics operations
  getStatistics(userId: number): Promise<Statistics | undefined>;
  updateStatistics(userId: number, stats: Partial<InsertStatistics>): Promise<Statistics>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private progressEntries: Map<number, ProgressEntry>;
  private journalEntries: Map<number, JournalEntry>;
  private achievements: Map<number, Achievement>;
  private userSettings: Map<number, UserSettings>;
  private statistics: Map<number, Statistics>;
  private currentId: number;

  constructor() {
    this.users = new Map();
    this.progressEntries = new Map();
    this.journalEntries = new Map();
    this.achievements = new Map();
    this.userSettings = new Map();
    this.statistics = new Map();
    this.currentId = 1;

    // Initialize with demo user
    this.initializeDemoData();
  }

  private initializeDemoData() {
    const demoUser: User = {
      id: 1,
      username: "dragonslayer",
      password: "password",
      displayName: "Dragon Slayer Alex",
      level: 42,
      experience: 15847,
      createdAt: new Date(),
    };

    const demoSettings: UserSettings = {
      id: 1,
      userId: 1,
      language: "ro",
      theme: "light",
      notifications: true,
      dailyReminders: true,
      reminderTime: "19:00",
      soundEffects: true,
      volume: 75,
      weekStartsOn: "monday",
      timeFormat: "24h",
    };

    const demoStats: Statistics = {
      id: 1,
      userId: 1,
      activeDays: 247,
      completedObjectives: 1234,
      currentLevel: 37,
      consistency: 23284,
      personalGoals: 12,
      personalResources: 8,
      updatedAt: new Date(),
    };

    this.users.set(1, demoUser);
    this.userSettings.set(1, demoSettings);
    this.statistics.set(1, demoStats);

    // Initialize progress entries for levels 1-12 as completed
    for (let level = 1; level <= 12; level++) {
      const entry: ProgressEntry = {
        id: level,
        userId: 1,
        level,
        completed: level <= 10,
        completedAt: level <= 10 ? new Date() : null,
        createdAt: new Date(),
      };
      this.progressEntries.set(level, entry);
    }

    this.currentId = 100;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getProgressEntries(userId: number): Promise<ProgressEntry[]> {
    return Array.from(this.progressEntries.values()).filter(entry => entry.userId === userId);
  }

  async createProgressEntry(insertEntry: InsertProgressEntry): Promise<ProgressEntry> {
    const id = this.currentId++;
    const entry: ProgressEntry = { ...insertEntry, id, createdAt: new Date() };
    this.progressEntries.set(id, entry);
    return entry;
  }

  async updateProgressEntry(id: number, updates: Partial<ProgressEntry>): Promise<ProgressEntry | undefined> {
    const entry = this.progressEntries.get(id);
    if (!entry) return undefined;
    const updatedEntry = { ...entry, ...updates };
    this.progressEntries.set(id, updatedEntry);
    return updatedEntry;
  }

  async getJournalEntries(userId: number): Promise<JournalEntry[]> {
    return Array.from(this.journalEntries.values())
      .filter(entry => entry.userId === userId)
      .sort((a, b) => b.date.getTime() - a.date.getTime());
  }

  async createJournalEntry(insertEntry: InsertJournalEntry): Promise<JournalEntry> {
    const id = this.currentId++;
    const entry: JournalEntry = { 
      ...insertEntry, 
      id, 
      date: insertEntry.date || new Date(),
      createdAt: new Date() 
    };
    this.journalEntries.set(id, entry);
    return entry;
  }

  async updateJournalEntry(id: number, updates: Partial<JournalEntry>): Promise<JournalEntry | undefined> {
    const entry = this.journalEntries.get(id);
    if (!entry) return undefined;
    const updatedEntry = { ...entry, ...updates };
    this.journalEntries.set(id, updatedEntry);
    return updatedEntry;
  }

  async deleteJournalEntry(id: number): Promise<boolean> {
    return this.journalEntries.delete(id);
  }

  async getAchievements(userId: number): Promise<Achievement[]> {
    return Array.from(this.achievements.values()).filter(achievement => achievement.userId === userId);
  }

  async createAchievement(insertAchievement: InsertAchievement): Promise<Achievement> {
    const id = this.currentId++;
    const achievement: Achievement = { ...insertAchievement, id, unlockedAt: new Date() };
    this.achievements.set(id, achievement);
    return achievement;
  }

  async getUserSettings(userId: number): Promise<UserSettings | undefined> {
    return Array.from(this.userSettings.values()).find(settings => settings.userId === userId);
  }

  async updateUserSettings(userId: number, updates: Partial<InsertUserSettings>): Promise<UserSettings> {
    const existingSettings = await this.getUserSettings(userId);
    const id = existingSettings?.id || this.currentId++;
    const settings: UserSettings = {
      id,
      userId,
      language: "ro",
      theme: "light",
      notifications: true,
      dailyReminders: true,
      reminderTime: "19:00",
      soundEffects: true,
      volume: 75,
      weekStartsOn: "monday",
      timeFormat: "24h",
      ...existingSettings,
      ...updates,
    };
    this.userSettings.set(id, settings);
    return settings;
  }

  async getStatistics(userId: number): Promise<Statistics | undefined> {
    return Array.from(this.statistics.values()).find(stats => stats.userId === userId);
  }

  async updateStatistics(userId: number, updates: Partial<InsertStatistics>): Promise<Statistics> {
    const existingStats = await this.getStatistics(userId);
    const id = existingStats?.id || this.currentId++;
    const stats: Statistics = {
      id,
      userId,
      activeDays: 0,
      completedObjectives: 0,
      currentLevel: 1,
      consistency: 0,
      personalGoals: 0,
      personalResources: 0,
      updatedAt: new Date(),
      ...existingStats,
      ...updates,
    };
    this.statistics.set(id, stats);
    return stats;
  }
}

export const storage = new MemStorage();

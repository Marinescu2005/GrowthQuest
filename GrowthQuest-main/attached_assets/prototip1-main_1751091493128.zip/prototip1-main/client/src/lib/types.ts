export interface LevelNode {
  level: number;
  completed: boolean;
  current?: boolean;
  locked?: boolean;
}

export interface ProgressArea {
  id: string;
  name: string;
  description: string;
  levelRange: string;
  totalLevels: number;
  completedLevels: number;
  unlocked: boolean;
}

export interface JournalStats {
  totalEntries: number;
  totalWords: number;
  currentMonth: string;
  currentDay: number;
}

export interface AchievementCategory {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  stats: Record<string, number>;
}

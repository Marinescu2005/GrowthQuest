import { useState } from "react";
import { useParams } from "wouter";
import SidebarClean from "@/components/SidebarClean";
import HeaderClean from "@/components/HeaderClean";
import ProgressMapClean from "@/components/ProgressMapClean";
import Statistics from "@/components/Statistics";
import JournalClean from "@/components/JournalClean";
import Profile from "@/components/Profile";
import Settings from "@/components/Settings";
import { useOrientation } from "@/hooks/use-mobile";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

type Section = "harta" | "statistici" | "jurnal" | "profil" | "setari";

const sectionTitles = {
  harta: { title: "Harta Progresului", subtitle: "Vizualizează progresul tău în câteva secțiuni simple" },
  statistici: { title: "Istoric & Statistici", subtitle: "Analizează performanța și progresul în timp" },
  jurnal: { title: "Jurnalul Meu", subtitle: "Locul tău de reflecție și inspirație" },
  profil: { title: "Profilul Meu", subtitle: "Dashboard personal TranscendUp" },
  setari: { title: "Setări", subtitle: "Personalizează experiența ta" }
};

export default function Dashboard() {
  const params = useParams();
  const currentSection = (params.section as Section) || "harta";
  const [activeSection, setActiveSection] = useState<Section>(currentSection);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { isMobile, isMobileLandscape, isMobilePortrait } = useOrientation();

  const renderContent = () => {
    switch (activeSection) {
      case "statistici":
        return <Statistics />;
      case "jurnal":
        return <JournalClean />;
      case "profil":
        return <Profile />;
      case "setari":
        return <Settings />;
      default:
        return <ProgressMapClean />;
    }
  };

  const currentTitle = sectionTitles[activeSection];

  const handleSectionChange = (section: Section) => {
    setActiveSection(section);
    if (isMobile) {
      setSidebarOpen(false);
    }
  };

  return (
    <div className={`flex h-screen bg-gradient-to-br from-emerald-50 via-green-50 to-emerald-100 ${isMobileLandscape ? 'flex-row' : ''}`}>
      {/* Mobile Sidebar Overlay */}
      {isMobile && sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        ${isMobile ? 'fixed left-0 top-0 h-full z-50 transform transition-transform duration-300' : 'relative'}
        ${isMobile && !sidebarOpen ? '-translate-x-full' : 'translate-x-0'}
        ${isMobileLandscape ? 'w-64' : ''}
      `}>
        <SidebarClean 
          activeSection={activeSection} 
          onSectionChange={handleSectionChange}
          isMobile={isMobile}
          isMobileLandscape={isMobileLandscape}
          onClose={() => setSidebarOpen(false)}
        />
      </div>
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <HeaderClean 
          title={currentTitle.title} 
          subtitle={currentTitle.subtitle}
          isMobile={isMobile}
          isMobileLandscape={isMobileLandscape}
          onMenuClick={() => setSidebarOpen(true)}
        />
        <main className={`flex-1 overflow-y-auto ${isMobile ? (isMobileLandscape ? 'p-3' : 'p-4') : 'p-8'}`}>
          {renderContent()}
        </main>
      </div>
    </div>
  );
}

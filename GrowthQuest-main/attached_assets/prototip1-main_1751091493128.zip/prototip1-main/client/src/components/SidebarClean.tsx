import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { 
  Map, 
  BarChart3, 
  BookOpen, 
  User as UserIcon, 
  Settings as SettingsIcon,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: "harta" | "statistici" | "jurnal" | "profil" | "setari") => void;
  isMobile?: boolean;
  isMobileLandscape?: boolean;
  onClose?: () => void;
}

export default function SidebarClean({ activeSection, onSectionChange, isMobile = false, isMobileLandscape = false, onClose }: SidebarProps) {
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  const menuItems = [
    { id: "harta", label: "Harta Progresului", icon: Map },
    { id: "statistici", label: "Istoric & Statistici", icon: BarChart3 },
    { id: "jurnal", label: "Jurnalul Meu", icon: BookOpen },
    { id: "profil", label: "Profilul Meu", icon: UserIcon },
    { id: "setari", label: "Setări", icon: SettingsIcon },
  ];

  return (
    <div className={`${isMobileLandscape ? 'w-64' : (isMobile ? 'w-80' : 'w-80')} bg-white/90 backdrop-blur-sm border-r border-emerald-200/60 flex flex-col shadow-sm h-full`}>
      <div className={`${isMobileLandscape ? 'p-4' : 'p-6'} border-b border-emerald-200/60`}>
        <div className="flex items-center justify-between">
          <div>
            <h1 className={`${isMobileLandscape ? 'text-lg' : (isMobile ? 'text-xl' : 'text-2xl')} font-bold text-emerald-800 mb-2`}>TranscendUp</h1>
            <p className={`${isMobileLandscape ? 'text-xs' : 'text-sm'} text-emerald-600`}>Platforma ta de dezvoltare personală</p>
          </div>
          {isMobile && onClose && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="text-slate-600 hover:bg-slate-100"
            >
              <X size={isMobileLandscape ? 16 : 20} />
            </Button>
          )}
        </div>
      </div>

      <nav className={`flex-1 p-4 space-y-2 ${isMobileLandscape ? 'space-y-1' : ''}`}>
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeSection === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onSectionChange(item.id as any)}
              className={`flex items-center ${isMobileLandscape ? 'px-3 py-2' : (isMobile ? 'px-4 py-3' : 'px-6 py-4')} text-left transition-all duration-200 rounded-lg mb-2 w-full ${
                isActive
                  ? `bg-emerald-500 text-white shadow-md`
                  : "text-slate-700 hover:bg-slate-100"
              }`}
            >
              <div className={`${isMobileLandscape ? 'w-6 h-6' : (isMobile ? 'w-8 h-8' : 'w-10 h-10')} rounded-lg flex items-center justify-center ${isMobileLandscape ? 'mr-2' : (isMobile ? 'mr-3' : 'mr-4')} ${
                isActive 
                  ? "bg-white/20" 
                  : "bg-slate-200"
              }`}>
                <Icon 
                  size={isMobileLandscape ? 14 : (isMobile ? 16 : 20)} 
                  className={isActive ? "text-white" : "text-slate-600"} 
                />
              </div>
              <div className="flex-1">
                <div className={`${isMobileLandscape ? 'text-xs' : (isMobile ? 'text-sm' : 'text-base')} font-semibold ${isActive ? "text-white" : "text-slate-800"}`}>
                  {item.label}
                </div>
              </div>
            </button>
          );
        })}
      </nav>

      {user && (
        <div className={`${isMobileLandscape ? 'p-3' : (isMobile ? 'p-4' : 'p-6')} border-t border-slate-200/60`}>
          <div className="flex items-center space-x-3">
            <div className={`${isMobileLandscape ? 'w-6 h-6' : (isMobile ? 'w-8 h-8' : 'w-10 h-10')} bg-slate-200 rounded-lg flex items-center justify-center`}>
              <UserIcon size={isMobileLandscape ? 14 : (isMobile ? 16 : 20)} className="text-slate-600" />
            </div>
            <div className="flex-1">
              <p className={`${isMobileLandscape ? 'text-xs' : (isMobile ? 'text-sm' : 'text-base')} font-medium text-slate-800`}>{user.username}</p>
              <p className="text-xs text-slate-600">Nivel {user.level || 1}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
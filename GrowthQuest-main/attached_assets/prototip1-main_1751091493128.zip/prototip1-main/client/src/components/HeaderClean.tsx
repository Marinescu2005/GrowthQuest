import { Bell, User, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";

interface HeaderProps {
  title: string;
  subtitle: string;
  isMobile?: boolean;
  isMobileLandscape?: boolean;
  onMenuClick?: () => void;
}

export default function HeaderClean({ title, subtitle, isMobile = false, isMobileLandscape = false, onMenuClick }: HeaderProps) {
  return (
    <header className={`bg-white/85 backdrop-blur-sm border-b border-emerald-200/60 ${isMobileLandscape ? 'px-3 py-2' : (isMobile ? 'px-4 py-4' : 'px-8 py-6')}`}>
      <div className="flex justify-between items-center">
        <div className="flex items-center">
          {isMobile && onMenuClick && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onMenuClick}
              className={`text-slate-600 hover:bg-slate-100 ${isMobileLandscape ? 'mr-2' : 'mr-3'}`}
            >
              <Menu size={isMobileLandscape ? 16 : 20} />
            </Button>
          )}
          <div>
            <h2 className={`${isMobileLandscape ? 'text-lg' : (isMobile ? 'text-xl' : 'text-3xl')} font-bold text-slate-800 ${isMobileLandscape ? 'mb-0' : (isMobile ? 'mb-1' : 'mb-2')}`}>{title}</h2>
            {!isMobileLandscape && (
              <p className={`${isMobile ? 'text-sm' : 'text-base'} text-emerald-700`}>{subtitle}</p>
            )}
          </div>
        </div>
        
        {!isMobile && (
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="text-slate-600 hover:bg-slate-100">
              <Bell size={20} />
            </Button>
            <div className="text-right">
              <p className="text-sm text-slate-600">Progres general</p>
              <p className="text-lg font-semibold text-slate-800">Nivel 12</p>
            </div>
            <div className="w-10 h-10 bg-emerald-500 rounded-lg flex items-center justify-center">
              <User size={20} className="text-white" />
            </div>
          </div>
        )}
        
        {isMobile && (
          <div className="flex items-center space-x-2">
            <div className="text-right">
              <p className={`${isMobileLandscape ? 'text-xs' : 'text-xs'} text-slate-600`}>Nivel 12</p>
            </div>
            <div className={`${isMobileLandscape ? 'w-6 h-6' : 'w-8 h-8'} bg-emerald-500 rounded-lg flex items-center justify-center`}>
              <User size={isMobileLandscape ? 12 : 16} className="text-white" />
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { JournalEntry, InsertJournalEntry } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { PlusCircle, BookOpen, Calendar, Search, Filter, Edit, Trash2, Clock } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useOrientation } from "@/hooks/use-mobile";

export default function JournalClean() {
  const [showNewEntry, setShowNewEntry] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newContent, setNewContent] = useState("");
  const [category, setCategory] = useState("personal");
  const [editingEntry, setEditingEntry] = useState<JournalEntry | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { isMobile, isMobileLandscape, isMobilePortrait } = useOrientation();

  const { data: journalEntries = [] } = useQuery<JournalEntry[]>({
    queryKey: ["/api/journal"],
  });

  const createEntryMutation = useMutation({
    mutationFn: (entry: InsertJournalEntry) => apiRequest("POST", "/api/journal", entry),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/journal"] });
      resetForm();
      toast({
        title: "Intrare adăugată",
        description: "Intrarea în jurnal a fost salvată cu succes!",
      });
    },
  });

  const updateEntryMutation = useMutation({
    mutationFn: ({ id, ...entry }: { id: number } & Partial<JournalEntry>) => 
      apiRequest("PATCH", `/api/journal/${id}`, entry),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/journal"] });
      resetForm();
      toast({
        title: "Intrare actualizată",
        description: "Intrarea în jurnal a fost actualizată cu succes!",
      });
    },
  });

  const deleteEntryMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/journal/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/journal"] });
      toast({
        title: "Intrare ștearsă",
        description: "Intrarea din jurnal a fost ștearsă cu succes!",
      });
    },
  });

  const resetForm = () => {
    setShowNewEntry(false);
    setEditingEntry(null);
    setNewTitle("");
    setNewContent("");
    setCategory("personal");
  };

  const handleSubmit = () => {
    if (!newTitle.trim() || !newContent.trim()) {
      toast({
        title: "Eroare",
        description: "Te rog completează toate câmpurile!",
        variant: "destructive",
      });
      return;
    }

    if (editingEntry) {
      updateEntryMutation.mutate({
        id: editingEntry.id,
        title: newTitle,
        content: newContent,
        category,
      });
    } else {
      createEntryMutation.mutate({
        title: newTitle,
        content: newContent,
        category,
        userId: 1, // Demo user ID
      });
    }
  };

  const handleEdit = (entry: JournalEntry) => {
    setEditingEntry(entry);
    setNewTitle(entry.title);
    setNewContent(entry.content);
    setCategory(entry.category);
    setShowNewEntry(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Ești sigur că vrei să ștergi această intrare?")) {
      deleteEntryMutation.mutate(id);
    }
  };

  const getCategoryStyle = (category: string) => {
    switch (category) {
      case "personal": return "bg-emerald-100 text-emerald-700 border-emerald-200";
      case "work": return "bg-blue-100 text-blue-700 border-blue-200";
      case "goals": return "bg-amber-100 text-amber-700 border-amber-200";
      case "reflection": return "bg-purple-100 text-purple-700 border-purple-200";
      default: return "bg-slate-100 text-slate-700 border-slate-200";
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "personal": return "Personal";
      case "work": return "Profesional";
      case "goals": return "Obiective";
      case "reflection": return "Reflecții";
      default: return "General";
    }
  };

  const wordCount = journalEntries.reduce((total, entry) => 
    total + entry.content.split(/\s+/).filter(word => word.length > 0).length, 0
  );

  const thisMonthEntries = journalEntries.filter(entry => {
    const entryDate = new Date(entry.createdAt);
    const now = new Date();
    return entryDate.getMonth() === now.getMonth() && entryDate.getFullYear() === now.getFullYear();
  }).length;

  return (
    <div className="space-y-6">
      {/* Header & Stats */}
      <div className={`grid ${isMobileLandscape ? 'grid-cols-4 gap-3' : (isMobile ? 'grid-cols-2 gap-4' : 'grid-cols-1 md:grid-cols-4 gap-6')}`}>
        <Card className="bg-white/80 backdrop-blur-sm border-emerald-200/50 shadow-sm">
          <CardContent className={`${isMobile ? 'p-4' : 'p-6'} text-center`}>
            <div className={`${isMobile ? 'w-8 h-8' : 'w-12 h-12'} bg-emerald-500 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-sm`}>
              <BookOpen className="text-white" size={isMobile ? 16 : 20} />
            </div>
            <h3 className={`font-bold text-slate-800 mb-2 ${isMobile ? 'text-sm' : 'text-base'}`}>Intrări Totale</h3>
            <p className={`${isMobile ? 'text-lg' : 'text-2xl'} font-bold text-emerald-600`}>{journalEntries.length}</p>
          </CardContent>
        </Card>

        <Card className="bg-white/80 backdrop-blur-sm border-blue-200/50 shadow-sm">
          <CardContent className={`${isMobile ? 'p-4' : 'p-6'} text-center`}>
            <div className={`${isMobile ? 'w-8 h-8' : 'w-12 h-12'} bg-blue-500 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-sm`}>
              <Calendar className="text-white" size={isMobile ? 16 : 20} />
            </div>
            <h3 className={`font-bold text-slate-800 mb-2 ${isMobile ? 'text-sm' : 'text-base'}`}>
              {isMobile ? "Luna aceasta" : "Această Lună"}
            </h3>
            <p className={`${isMobile ? 'text-lg' : 'text-2xl'} font-bold text-blue-600`}>{thisMonthEntries}</p>
          </CardContent>
        </Card>

        {!isMobile && (
          <>
            <Card className="bg-white/80 backdrop-blur-sm border-amber-200/50 shadow-sm">
              <CardContent className={`${isMobileLandscape ? 'p-4' : 'p-6'} text-center`}>
                <div className={`${isMobileLandscape ? 'w-8 h-8' : 'w-12 h-12'} bg-amber-500 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-sm`}>
                  <PlusCircle className="text-white" size={isMobileLandscape ? 16 : 20} />
                </div>
                <h3 className={`font-bold text-slate-800 mb-2 ${isMobileLandscape ? 'text-sm' : ''}`}>Cuvinte Scrise</h3>
                <p className={`${isMobileLandscape ? 'text-lg' : 'text-2xl'} font-bold text-amber-600`}>{wordCount.toLocaleString()}</p>
              </CardContent>
            </Card>

            <Card className="bg-white/80 backdrop-blur-sm border-purple-200/50 shadow-sm">
              <CardContent className={`${isMobileLandscape ? 'p-4' : 'p-6'} text-center`}>
                <div className={`${isMobileLandscape ? 'w-8 h-8' : 'w-12 h-12'} bg-purple-500 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-sm`}>
                  <Clock className="text-white" size={isMobileLandscape ? 16 : 20} />
                </div>
                <h3 className={`font-bold text-slate-800 mb-2 ${isMobileLandscape ? 'text-sm' : ''}`}>Intrări Recente</h3>
                <p className={`${isMobileLandscape ? 'text-lg' : 'text-2xl'} font-bold text-purple-600`}>
                  {journalEntries.filter(entry => {
                    const entryDate = new Date(entry.createdAt);
                    const weekAgo = new Date();
                    weekAgo.setDate(weekAgo.getDate() - 7);
                    return entryDate > weekAgo;
                  }).length}
                </p>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      {/* Action Bar */}
      <div className={`flex ${isMobile ? 'flex-col' : 'flex-col sm:flex-row'} gap-4 items-start ${isMobile ? '' : 'sm:items-center'} justify-between`}>
        {!isMobile && (
          <div className="flex gap-2">
            <Input
              placeholder="Caută în jurnal..."
              className="w-64"
            />
            <Button variant="outline" size="icon">
              <Search size={16} />
            </Button>
            <Button variant="outline" size="icon">
              <Filter size={16} />
            </Button>
          </div>
        )}
        <Button
          onClick={() => setShowNewEntry(true)}
          className={`bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg ${isMobile ? 'w-full py-3' : 'px-6 py-3'} shadow-sm`}
        >
          <PlusCircle className="mr-2" size={18} />
          {editingEntry ? "Editează Intrarea" : "Intrare Nouă"}
        </Button>
      </div>

      {/* New Entry Form */}
      {showNewEntry && (
        <Card className="bg-white/80 backdrop-blur-sm border-emerald-200/50 shadow-sm">
          <CardHeader className={isMobile ? "p-4" : ""}>
            <CardTitle className="text-slate-800">
              {editingEntry ? "Editează Intrarea" : "Intrare Nouă în Jurnal"}
            </CardTitle>
          </CardHeader>
          <CardContent className={`space-y-4 ${isMobile ? 'p-4 pt-0' : ''}`}>
            <div>
              <Input
                placeholder="Titlul intrării..."
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className={`${isMobile ? 'text-base' : 'text-lg'} font-medium`}
              />
            </div>
            <div>
              <Textarea
                placeholder="Scrie-ți gândurile aici..."
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                className={`${isMobile ? 'min-h-32' : 'min-h-40'} resize-none`}
              />
            </div>
            <div className="flex gap-2">
              <select 
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800"
              >
                <option value="personal">Personal</option>
                <option value="work">Profesional</option>
                <option value="goals">Obiective</option>
                <option value="reflection">Reflecții</option>
              </select>
            </div>
            <div className={`flex gap-2 pt-4 ${isMobile ? 'flex-col' : ''}`}>
              <Button
                onClick={handleSubmit}
                disabled={createEntryMutation.isPending || updateEntryMutation.isPending}
                className={`bg-emerald-500 hover:bg-emerald-600 text-white ${isMobile ? 'w-full' : ''}`}
              >
                {(createEntryMutation.isPending || updateEntryMutation.isPending) ? "Se salvează..." : "Salvează"}
              </Button>
              <Button
                variant="outline"
                onClick={resetForm}
                className={isMobile ? 'w-full' : ''}
              >
                Anulează
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Journal Entries */}
      <div className={`grid ${isMobileLandscape ? 'grid-cols-2 gap-4' : (isMobile ? 'grid-cols-1' : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3')} gap-6`}>
        {journalEntries.length === 0 ? (
          <div className="col-span-full text-center py-12">
            <BookOpen size={isMobile ? 40 : 48} className="mx-auto text-slate-400 mb-4" />
            <h3 className={`${isMobile ? 'text-lg' : 'text-xl'} font-semibold text-slate-700 mb-2`}>Nicio intrare încă</h3>
            <p className={`text-slate-500 mb-6 ${isMobile ? 'text-sm' : ''}`}>Începe să-ți scrii jurnalul pentru a-ți urmări progresul!</p>
            <Button
              onClick={() => setShowNewEntry(true)}
              className={`bg-emerald-500 hover:bg-emerald-600 text-white ${isMobile ? 'w-full' : ''}`}
            >
              <PlusCircle className="mr-2" size={18} />
              Prima Intrare
            </Button>
          </div>
        ) : (
          journalEntries.map((entry) => (
            <Card key={entry.id} className="bg-white/80 backdrop-blur-sm border-slate-200/50 shadow-sm hover:shadow-md transition-shadow">
              <CardHeader className={isMobile ? "p-4" : ""}>
                <div className="flex justify-between items-start">
                  <CardTitle className={`${isMobile ? 'text-base' : 'text-lg'} text-slate-800`}>{entry.title}</CardTitle>
                  <Badge 
                    variant="secondary" 
                    className={`${getCategoryStyle(entry.category)} ${isMobile ? 'text-xs' : ''}`}
                  >
                    {getCategoryLabel(entry.category)}
                  </Badge>
                </div>
                <p className={`${isMobile ? 'text-xs' : 'text-sm'} text-slate-600`}>
                  {new Date(entry.createdAt).toLocaleDateString('ro-RO', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </p>
              </CardHeader>
              <CardContent className={isMobile ? "p-4 pt-0" : ""}>
                <p className={`text-slate-700 line-clamp-3 ${isMobile ? 'text-sm' : ''} mb-4`}>
                  {entry.content}
                </p>
                <div className="flex justify-between items-center">
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size={isMobile ? "sm" : "default"}
                      onClick={() => handleEdit(entry)}
                      className="text-blue-600 hover:text-blue-700"
                    >
                      <Edit size={isMobile ? 14 : 16} className={isMobile ? "" : "mr-1"} />
                      {!isMobile && "Editează"}
                    </Button>
                    <Button
                      variant="outline"
                      size={isMobile ? "sm" : "default"}
                      onClick={() => handleDelete(entry.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 size={isMobile ? 14 : 16} className={isMobile ? "" : "mr-1"} />
                      {!isMobile && "Șterge"}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
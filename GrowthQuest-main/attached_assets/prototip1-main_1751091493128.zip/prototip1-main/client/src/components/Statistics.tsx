import { useQuery } from "@tanstack/react-query";
import { Statistics as StatsType } from "@shared/schema";
import { BarChart3, Clock, Trophy } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function Statistics() {
  const { data: stats } = useQuery<StatsType>({
    queryKey: ["/api/statistics"],
  });

  if (!stats) {
    return <div>Loading statistics...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Key Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-white border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 bg-blue-500 rounded-xl flex items-center justify-center mx-auto mb-6 shadow-sm">
              <BarChart3 className="text-white" size={28} />
            </div>
            <h3 className="font-bold text-neutral-900 mb-3 text-xl">Prezentare</h3>
            <p className="text-neutral-600 mb-6 font-medium">Statistici principale</p>
            <div className="space-y-4">
              <div className="bg-wisdom-50 rounded-xl p-4">
                <div className="text-3xl font-bold text-wisdom-600 mb-1">{stats.activeDays}</div>
                <span className="text-sm text-wisdom-700 font-medium">Zile Active</span>
              </div>
              <div className="bg-growth-50 rounded-xl p-4">
                <div className="text-2xl font-bold text-growth-600 mb-1">{Math.round(stats.activeDays / 30 * 100)}%</div>
                <span className="text-sm text-growth-700 font-medium">Consistență lunară</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 bg-emerald-500 rounded-xl flex items-center justify-center mx-auto mb-6 shadow-sm">
              <Clock className="text-white" size={28} />
            </div>
            <h3 className="font-bold text-slate-800 mb-3 text-xl">Cronologie</h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              Vizualizează momentele cheie ale progresului tău pentru a identifica tendințele de creștere.
            </p>
            <div className="space-y-4">
              <div className="bg-emerald-50 rounded-xl p-4">
                <div className="text-3xl font-bold text-emerald-600 mb-1">{stats.completedObjectives}</div>
                <span className="text-sm text-emerald-700 font-medium">Obiective</span>
              </div>
              <div className="bg-emerald-50 rounded-xl p-4">
                <div className="text-2xl font-bold text-emerald-600 mb-1">{stats.consistency.toLocaleString()}</div>
                <span className="text-sm text-emerald-700 font-medium">Puncte consistență</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 bg-amber-500 rounded-xl flex items-center justify-center mx-auto mb-6 shadow-sm">
              <Trophy className="text-white" size={28} />
            </div>
            <h3 className="font-bold text-slate-800 mb-3 text-xl">Analiză</h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              Analizează performanțele tale în detaliu și găsește oportunități de îmbunătățire continuă.
            </p>
            <div className="space-y-4">
              <div className="bg-amber-50 rounded-xl p-4">
                <div className="text-3xl font-bold text-amber-600 mb-1">{stats.currentLevel}</div>
                <span className="text-sm text-amber-700 font-medium">Nivel curent</span>
              </div>
              <div className="bg-amber-50 rounded-xl p-4">
                <div className="text-2xl font-bold text-amber-600 mb-1">{stats.personalGoals}</div>
                <span className="text-sm text-amber-700 font-medium">Obiective personale</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Progress Overview */}
      <Card className="bg-white border-slate-200 shadow-sm">
        <CardContent className="p-8">
          <h3 className="text-2xl font-bold text-slate-800 mb-8">Progres Rapid</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6 bg-gradient-to-br from-growth-50 to-growth-100 rounded-2xl">
              <div className="text-5xl font-bold text-growth-600 mb-3">{stats.activeDays}</div>
              <p className="text-growth-700 font-semibold">Zile Active</p>
              <div className="mt-4 w-full bg-growth-200 rounded-full h-2">
                <div className="bg-growth-500 h-2 rounded-full" style={{ width: `${Math.min(stats.activeDays / 365 * 100, 100)}%` }} />
              </div>
              <p className="text-xs text-growth-600 mt-2">{Math.round(stats.activeDays / 365 * 100)}% din an</p>
            </div>
            <div className="text-center p-6 bg-gradient-to-br from-wisdom-50 to-wisdom-100 rounded-2xl">
              <div className="text-5xl font-bold text-wisdom-600 mb-3">{stats.completedObjectives.toLocaleString()}</div>
              <p className="text-wisdom-700 font-semibold">Obiective Complete</p>
              <div className="mt-4 w-full bg-wisdom-200 rounded-full h-2">
                <div className="bg-wisdom-500 h-2 rounded-full" style={{ width: `${Math.min(stats.completedObjectives / 2000 * 100, 100)}%` }} />
              </div>
              <p className="text-xs text-wisdom-600 mt-2">Către 2,000 obiective</p>
            </div>
            <div className="text-center p-6 bg-gradient-to-br from-energy-50 to-energy-100 rounded-2xl">
              <div className="text-5xl font-bold text-energy-600 mb-3">{stats.currentLevel}</div>
              <p className="text-energy-700 font-semibold">Nivel Curent</p>
              <div className="mt-4 w-full bg-energy-200 rounded-full h-2">
                <div className="bg-energy-500 h-2 rounded-full" style={{ width: `${Math.min(stats.currentLevel / 100 * 100, 100)}%` }} />
              </div>
              <p className="text-xs text-energy-600 mt-2">Către nivel 100</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Progress Charts Placeholder */}
      <Card className="card-shadow">
        <CardContent className="p-6">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">Evoluția Progresului</h3>
          <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
            <div className="text-center text-gray-500">
              <BarChart3 size={48} className="mx-auto mb-4" />
              <p>Graficul progresului va fi afișat aici</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { UserSettings } from "@shared/schema";
import { 
  ArrowLeft, 
  Globe, 
  Bell, 
  Clock, 
  Palette, 
  Volume2, 
  Calendar,
  User as UserIcon
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: settings } = useQuery<UserSettings>({
    queryKey: ["/api/settings"],
  });

  const updateSettingsMutation = useMutation({
    mutationFn: (updates: Partial<UserSettings>) =>
      apiRequest("PATCH", "/api/settings", updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Setări actualizate",
        description: "Setările au fost salvate cu succes!",
      });
    },
  });

  const handleSettingChange = (key: keyof UserSettings, value: any) => {
    updateSettingsMutation.mutate({ [key]: value });
  };

  if (!settings) {
    return <div>Loading settings...</div>;
  }

  return (
    <div className="max-w-2xl space-y-6">
      <Card className="card-shadow">
        <CardContent className="p-6">
          {/* Settings Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="text-gray-600" size={16} />
              </Button>
              <h2 className="text-xl font-bold text-gray-900">Setări</h2>
            </div>
            <div className="w-10 h-10 gradient-bg rounded-full flex items-center justify-center">
              <UserIcon className="text-white" size={20} />
            </div>
          </div>

          {/* Language Settings */}
          <div className="border-b border-neutral-200 pb-8 mb-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 wisdom-gradient rounded-xl flex items-center justify-center">
                  <Globe className="text-white" size={20} />
                </div>
                <div>
                  <h3 className="font-bold text-neutral-900 text-lg">Limba aplicației</h3>
                  <p className="text-neutral-600 text-sm mt-1">Alege limba preferată pentru interfață</p>
                </div>
              </div>
              <Select
                value={settings.language}
                onValueChange={(value) => handleSettingChange("language", value)}
              >
                <SelectTrigger className="w-40 rounded-xl border-wisdom-300">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ro">🇷🇴 Română</SelectItem>
                  <SelectItem value="en">🇺🇸 English</SelectItem>
                  <SelectItem value="es">🇪🇸 Español</SelectItem>
                  <SelectItem value="fr">🇫🇷 Français</SelectItem>
                  <SelectItem value="de">🇩🇪 Deutsch</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Notification Settings */}
          <div className="space-y-8">
            <div className="bg-gradient-to-r from-energy-50 to-energy-100 rounded-xl p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 energy-gradient rounded-xl flex items-center justify-center">
                    <Bell className="text-white" size={20} />
                  </div>
                  <div>
                    <h3 className="font-bold text-neutral-900 text-lg">Notificări</h3>
                    <p className="text-neutral-600 text-sm mt-1">Primește notificări pentru activități importante</p>
                  </div>
                </div>
                <Switch
                  checked={settings.notifications}
                  onCheckedChange={(checked) => handleSettingChange("notifications", checked)}
                />
              </div>
            </div>

            <div className="bg-gradient-to-r from-growth-50 to-growth-100 rounded-xl p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 growth-gradient rounded-xl flex items-center justify-center">
                    <Clock className="text-white" size={20} />
                  </div>
                  <div>
                    <h3 className="font-bold text-neutral-900 text-lg">Reminder-uri zilnice</h3>
                    <p className="text-neutral-600 text-sm mt-1">Notificări pentru obiectivele zilnice</p>
                  </div>
                </div>
                <Switch
                  checked={settings.dailyReminders}
                  onCheckedChange={(checked) => handleSettingChange("dailyReminders", checked)}
                />
              </div>
            </div>

            <div className="bg-gradient-to-r from-peace-50 to-peace-100 rounded-xl p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 peace-gradient rounded-xl flex items-center justify-center">
                    <Clock className="text-white" size={20} />
                  </div>
                  <div>
                    <h3 className="font-bold text-neutral-900 text-lg">Ora reminder-ului</h3>
                    <p className="text-neutral-600 text-sm mt-1">Când să primești notificările zilnice</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3 bg-white/70 rounded-xl px-4 py-2">
                  <span className="text-lg font-bold text-peace-700">{settings.reminderTime}</span>
                  <Clock className="text-peace-600" size={18} />
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Theme Settings */}
      <Card className="card-shadow">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Palette className="text-purple-500" size={20} />
              <div>
                <h3 className="font-medium text-gray-900">Tema aplicație</h3>
              </div>
            </div>
            <Select
              value={settings.theme}
              onValueChange={(value) => handleSettingChange("theme", value)}
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="light">Luminos</SelectItem>
                <SelectItem value="dark">Întunecat</SelectItem>
                <SelectItem value="auto">Auto</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Audio Settings */}
      <Card className="card-shadow">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <Volume2 className="text-green-500" size={20} />
              <div>
                <h3 className="font-medium text-gray-900">Efecte sonore</h3>
                <p className="text-sm text-gray-500">Sunete interactive</p>
              </div>
            </div>
            <Switch
              checked={settings.soundEffects}
              onCheckedChange={(checked) => handleSettingChange("soundEffects", checked)}
            />
          </div>
          <div className="mt-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">Volum</label>
            <Slider
              value={[settings.volume]}
              onValueChange={([value]) => handleSettingChange("volume", value)}
              max={100}
              step={1}
              className="w-full"
            />
          </div>
        </CardContent>
      </Card>

      {/* Additional Settings */}
      <Card className="card-shadow">
        <CardContent className="p-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Calendar className="text-blue-500" size={20} />
                <span className="text-sm font-medium text-gray-900">Săptămâna începe cu</span>
              </div>
              <Select
                value={settings.weekStartsOn}
                onValueChange={(value) => handleSettingChange("weekStartsOn", value)}
              >
                <SelectTrigger className="w-24">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="monday">Luni</SelectItem>
                  <SelectItem value="sunday">Duminică</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Clock className="text-gray-500" size={20} />
                <span className="text-sm font-medium text-gray-900">Format oră</span>
              </div>
              <Select
                value={settings.timeFormat}
                onValueChange={(value) => handleSettingChange("timeFormat", value)}
              >
                <SelectTrigger className="w-16">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="24h">24h</SelectItem>
                  <SelectItem value="12h">12h</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

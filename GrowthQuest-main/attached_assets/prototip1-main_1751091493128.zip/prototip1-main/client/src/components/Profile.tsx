import { useQuery } from "@tanstack/react-query";
import { User, Statistics } from "@shared/schema";
import { User as UserIcon, History, Gem, Heart } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

export default function Profile() {
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  const { data: stats } = useQuery<Statistics>({
    queryKey: ["/api/statistics"],
  });

  if (!user || !stats) {
    return <div>Loading profile...</div>;
  }

  const progressToNextLevel = ((user.experience % 1000) / 1000) * 100;
  const totalProgress = (user.experience / 16500) * 100;

  return (
    <div className="space-y-6">
      <Card className="card-shadow">
        <CardContent className="p-6">
          {/* Profile Header */}
          <div className="text-center mb-12">
            <div className="w-24 h-24 gradient-bg rounded-full flex items-center justify-center mx-auto mb-6 glow-effect floating-animation">
              <UserIcon className="text-white" size={36} />
            </div>
            <h2 className="text-3xl font-bold text-neutral-900 mb-2">Bun venit, {user.displayName}</h2>
            <p className="text-neutral-600 text-lg font-medium">Dashboard personal TranscendUp</p>
            <div className="mt-4 inline-flex items-center px-4 py-2 bg-gradient-to-r from-growth-100 to-wisdom-100 rounded-full">
              <div className="w-2 h-2 bg-growth-500 rounded-full mr-2 animate-pulse"></div>
              <span className="text-sm font-medium text-neutral-700">Activ acum</span>
            </div>
          </div>

          {/* Overall Progress */}
          <div className="bg-gradient-to-r from-wisdom-50 to-wisdom-100 border border-wisdom-300 rounded-2xl p-8 mb-10">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-wisdom-900">Progres General: Etapa {user.level}</h3>
              <div className="px-4 py-2 bg-wisdom-500 text-white rounded-xl font-bold">
                {Math.round(totalProgress)}%
              </div>
            </div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-wisdom-700 font-medium">{user.experience.toLocaleString()} / 16,500 puncte progres</span>
              <span className="text-sm text-wisdom-600">Către nivel {user.level + 1}</span>
            </div>
            <div className="w-full bg-wisdom-200 rounded-full h-4 mb-4">
              <div 
                className="bg-gradient-to-r from-wisdom-500 to-wisdom-600 h-4 rounded-full transition-all duration-1000 ease-out" 
                style={{ width: `${totalProgress}%` }}
              />
            </div>
            <div className="grid grid-cols-2 gap-4 mt-6">
              <div className="text-center p-4 bg-white/50 rounded-xl">
                <div className="text-2xl font-bold text-wisdom-600">{progressToNextLevel.toFixed(0)}%</div>
                <span className="text-sm text-wisdom-700">Progres către următorul nivel</span>
              </div>
              <div className="text-center p-4 bg-white/50 rounded-xl">
                <div className="text-2xl font-bold text-energy-600">{Math.ceil((16500 - user.experience) / 100)}</div>
                <span className="text-sm text-energy-700">Zile până la maxim</span>
              </div>
            </div>
          </div>

          {/* Achievement Categories */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* History Tracker */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                    <History className="text-white" size={20} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-blue-900">History Tracker</h4>
                    <p className="text-sm text-blue-600">Pasiuni & Performanță</p>
                  </div>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-blue-700">Zile Active</span>
                  <span className="font-semibold text-blue-900">{stats.activeDays}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-blue-700">Obiective Complete</span>
                  <span className="font-semibold text-blue-900">{stats.completedObjectives}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-blue-700">Etapa Curentă</span>
                  <span className="font-semibold text-blue-900">{stats.currentLevel}</span>
                </div>
              </div>
            </div>

            {/* Terrain Treasure */}
            <div className="bg-primary-50 border border-primary-200 rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary-500 rounded-lg flex items-center justify-center">
                    <Gem className="text-white" size={20} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-primary-900">Terrain Treasure</h4>
                    <p className="text-sm text-primary-600">Navigare & Explorare</p>
                  </div>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-primary-700">Progres Navigare</span>
                  <span className="font-semibold text-primary-900">37%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-primary-700">Puncte Acumulate</span>
                  <span className="font-semibold text-primary-900">37</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-primary-700">Resurse Descoperite</span>
                  <span className="font-semibold text-primary-900">0</span>
                </div>
              </div>
            </div>
          </div>

          {/* Personal Progress */}
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center">
                <Heart className="text-white" size={20} />
              </div>
              <div>
                <h4 className="font-semibold text-purple-900">Progres Personal</h4>
                <p className="text-sm text-purple-600">Obiective & Consistență</p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-900">{stats.consistency.toLocaleString()}</div>
                <p className="text-sm text-purple-600">Consistența</p>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-900">{stats.personalGoals}</div>
                <p className="text-sm text-purple-600">Obiective Atinse</p>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-900">{stats.personalResources}</div>
                <p className="text-sm text-purple-600">Resurse Personale</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

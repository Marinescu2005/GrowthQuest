import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Trophy, Target, Star, MapPin, Users, BookOpen, Zap } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useOrientation } from "@/hooks/use-mobile";

interface ProgressEntry {
  id: number;
  userId: number;
  level: number;
  completed: boolean;
  completedAt?: Date;
  createdAt: Date;
}

export default function ProgressMapClean() {
  const { isMobile, isMobileLandscape, isMobilePortrait } = useOrientation();
  
  const { data: user } = useQuery({
    queryKey: ["/api/user"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  const { data: progressEntries = [] } = useQuery<ProgressEntry[]>({
    queryKey: ["/api/progress"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  if (!user || !progressEntries) {
    return (
      <div className="space-y-6">
        <div className={`grid grid-cols-1 ${isMobile ? '' : 'lg:grid-cols-3'} gap-6`}>
          <div className={`${isMobile ? '' : 'lg:col-span-2'} bg-slate-100 animate-pulse rounded-xl h-96`}></div>
          {!isMobile && <div className="bg-slate-100 animate-pulse rounded-xl h-96"></div>}
        </div>
      </div>
    );
  }

  const completedLevels = progressEntries.filter((entry: any) => entry.completed).length;
  const totalLevels = 20;
  const progressPercentage = (completedLevels / totalLevels) * 100;

  const getLevelStatus = (level: number) => {
    const entry = progressEntries.find((p: ProgressEntry) => p.level === level);
    if (entry?.completed) return "completed";
    const uncompletedLevels = progressEntries.filter((p: ProgressEntry) => !p.completed).map((p: ProgressEntry) => p.level);
    if (uncompletedLevels.length > 0 && level === Math.min(...uncompletedLevels)) return "current";
    const completedLevels = progressEntries.filter((p: ProgressEntry) => p.completed).map((p: ProgressEntry) => p.level);
    if (completedLevels.length === 0 && level === 1) return "current";
    if (completedLevels.length > 0 && level <= Math.max(...completedLevels) + 1) return "available";
    return "locked";
  };

  const getLevelIcon = (status: string) => {
    switch (status) {
      case "completed": return <Star className="w-4 h-4 text-yellow-500" fill="currentColor" />;
      case "current": return <Target className="w-4 h-4 text-emerald-600" />;
      case "available": return <div className="w-2 h-2 bg-slate-400 rounded-full" />;
      default: return <div className="w-2 h-2 bg-slate-200 rounded-full" />;
    }
  };

  const getLevelStyle = (status: string) => {
    switch (status) {
      case "completed": 
        return "bg-emerald-50 border-emerald-200";
      case "current": 
        return "bg-blue-50 border-blue-200 ring-2 ring-blue-300";
      case "available": 
        return "bg-slate-50 border-slate-200 hover:bg-slate-100 cursor-pointer";
      default: 
        return "bg-slate-50 border-slate-200 opacity-50";
    }
  };

  return (
    <div className="space-y-6">
      {/* Main Progress Area */}
      <div className={`grid grid-cols-1 ${isMobile ? '' : 'lg:grid-cols-3'} gap-6`}>
        {/* Progress Overview Card */}
        <Card className={`${isMobile ? '' : 'lg:col-span-2'} bg-white/80 backdrop-blur-sm border-emerald-200/50 shadow-sm`}>
          <CardContent className={isMobile ? "p-4" : "p-8"}>
            <div className={`flex ${isMobile ? 'flex-col space-y-4' : 'items-center justify-between'} ${isMobile ? 'mb-6' : 'mb-8'}`}>
              <h3 className={`${isMobile ? 'text-xl' : 'text-2xl'} font-bold text-slate-800 flex items-center`}>
                <div className={`${isMobile ? 'w-6 h-6' : 'w-8 h-8'} bg-emerald-500 rounded-full flex items-center justify-center ${isMobile ? 'mr-2' : 'mr-3'} shadow-sm`}>
                  <span className={`text-white ${isMobile ? 'text-xs' : 'text-sm'}`}>🌱</span>
                </div>
                Câmpia Plată
              </h3>
              <div className={`${isMobile ? 'text-center' : 'text-right'}`}>
                <span className="text-sm text-slate-600">Progres Requreis</span>
                <div className={`${isMobile ? 'text-xl' : 'text-2xl'} font-bold text-slate-800`}>{completedLevels}/{totalLevels}</div>
              </div>
            </div>
            
            <div className="mb-6">
              <div className="flex justify-between items-center mb-4">
                <span className="text-sm text-slate-600">Nivel 1-20 • Începutul călătoriei tale</span>
                <span className="text-sm text-slate-600">{Math.floor((completedLevels / totalLevels) * 100)}% complet</span>
              </div>
            </div>

            {/* Progress Map Grid */}
            <div className={`grid ${isMobileLandscape ? 'grid-cols-8 gap-2' : (isMobile ? 'grid-cols-5 gap-2' : 'grid-cols-10 gap-3')} ${isMobile ? 'mb-6' : 'mb-8'}`}>
              {Array.from({ length: 20 }, (_, i) => {
                const level = i + 1;
                const status = getLevelStatus(level);
                const hasReward = level % 5 === 0 && status === "completed";
                
                return (
                  <div key={level} className="relative">
                    <div
                      className={`
                        aspect-square rounded-full border-2 flex items-center justify-center
                        transition-all duration-200 ease-in-out relative
                        ${getLevelStyle(status)}
                      `}
                    >
                      <div className="flex flex-col items-center justify-center">
                        {status === "completed" ? (
                          <div className={`${isMobile ? 'w-5 h-5' : 'w-6 h-6'} bg-emerald-500 rounded-full flex items-center justify-center`}>
                            <svg className={`${isMobile ? 'w-3 h-3' : 'w-4 h-4'} text-white`} fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                          </div>
                        ) : status === "current" ? (
                          <div className={`${isMobile ? 'w-5 h-5' : 'w-6 h-6'} bg-blue-500 rounded-full flex items-center justify-center`}>
                            <span className={`text-white ${isMobile ? 'text-xs' : 'text-xs'} font-bold`}>{level}</span>
                          </div>
                        ) : status === "available" ? (
                          <div className={`${isMobile ? 'w-5 h-5' : 'w-6 h-6'} bg-slate-300 rounded-full flex items-center justify-center`}>
                            <span className={`text-slate-600 ${isMobile ? 'text-xs' : 'text-xs'} font-medium`}>{level}</span>
                          </div>
                        ) : (
                          <div className={`${isMobile ? 'w-5 h-5' : 'w-6 h-6'} bg-slate-200 rounded-full flex items-center justify-center`}>
                            <span className={`text-slate-400 ${isMobile ? 'text-xs' : 'text-xs'}`}>{level}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    {hasReward && (
                      <div className={`absolute -top-1 -right-1 ${isMobile ? 'w-4 h-4' : 'w-6 h-6'} bg-orange-400 rounded-full flex items-center justify-center`}>
                        <span className={`text-white ${isMobile ? 'text-xs' : 'text-xs'}`}>🏆</span>
                      </div>
                    )}
                    {level % 5 === 0 && level <= 15 && !isMobile && (
                      <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2">
                        <span className="text-xs text-orange-600 font-medium">Recompensă</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Rewards Section */}
            <div className={`bg-orange-50 border border-orange-200 rounded-xl ${isMobile ? 'p-4' : 'p-6'}`}>
              <div className="flex items-center mb-4">
                <Trophy className={`${isMobile ? 'w-4 h-4' : 'w-5 h-5'} text-orange-600 mr-2`} />
                <h4 className={`${isMobile ? 'text-base' : 'text-lg'} font-semibold text-orange-800`}>Recompense câștigate: 2 cărți</h4>
              </div>
              <p className="text-sm text-orange-700 mb-4">Urmărirea recompensei: Nivel 15</p>
              <div className={`bg-white rounded-lg ${isMobile ? 'p-3' : 'p-4'}`}>
                <div className="text-center">
                  <div className={`${isMobile ? 'text-xl' : 'text-2xl'} font-bold text-orange-600 mb-1`}>50-150 XP</div>
                  <span className="text-sm text-orange-700">mediu pe nivel</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Sidebar with Progress Stats */}
        {!isMobile && (
          <Card className="bg-white/80 backdrop-blur-sm border-emerald-200/50 shadow-sm">
            <CardContent className="p-8">
            <div className="text-center mb-6">
              <div className="text-4xl font-bold text-emerald-600 mb-2">{completedLevels}/{totalLevels}</div>
              <p className="text-sm text-slate-600 mb-2">Progres Requreis</p>
              <div className="w-full bg-slate-200 rounded-full h-2 mb-4">
                <div 
                  className="bg-emerald-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${(completedLevels / totalLevels) * 100}%` }}
                ></div>
              </div>
              <div className="text-sm text-slate-500">
                {Math.floor((completedLevels / totalLevels) * 100)}% complet • 8 rămase
              </div>
            </div>

            <div className="space-y-4 mb-6">
              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-emerald-800">Nivel curent</span>
                  <span className="text-lg font-bold text-emerald-600">
                    {Math.max(...progressEntries.filter((p: any) => p.completed).map((p: any) => p.level), 0) + 1}
                  </span>
                </div>
              </div>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-blue-800">Experiență</span>
                  <span className="text-lg font-bold text-blue-600">{completedLevels * 75} XP</span>
                </div>
              </div>
            </div>

              <Button className="w-full bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg py-3 font-medium">
                Continuă Aventura
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Mobile Progress Stats */}
      {isMobilePortrait && (
        <Card className="bg-white/80 backdrop-blur-sm border-emerald-200/50 shadow-sm">
          <CardContent className="p-4">
            <div className="text-center mb-4">
              <div className="text-3xl font-bold text-emerald-600 mb-2">{completedLevels}/{totalLevels}</div>
              <p className="text-sm text-slate-600 mb-2">Progres Requreis</p>
              <div className="w-full bg-slate-200 rounded-full h-2 mb-4">
                <div 
                  className="bg-emerald-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${(completedLevels / totalLevels) * 100}%` }}
                ></div>
              </div>
              <div className="text-sm text-slate-500">
                {Math.floor((completedLevels / totalLevels) * 100)}% complet • 8 rămase
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3">
                <div className="text-center">
                  <span className="text-sm font-medium text-emerald-800">Nivel curent</span>
                  <div className="text-lg font-bold text-emerald-600">
                    {Math.max(...progressEntries.filter((p: any) => p.completed).map((p: any) => p.level), 0) + 1}
                  </div>
                </div>
              </div>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <div className="text-center">
                  <span className="text-sm font-medium text-blue-800">Experiență</span>
                  <div className="text-lg font-bold text-blue-600">{completedLevels * 75} XP</div>
                </div>
              </div>
            </div>

            <Button className="w-full bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg py-3 font-medium">
              Continuă Aventura
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Next Areas Preview */}
      <div className={`grid grid-cols-1 ${isMobile ? '' : 'md:grid-cols-2'} gap-6`}>
        <Card className="bg-blue-50/50 border-blue-200/50 shadow-sm hover:shadow-md transition-shadow">
          <CardContent className={isMobile ? "p-4" : "p-6"}>
            <div className="flex items-center mb-4">
              <div className={`${isMobile ? 'w-8 h-8' : 'w-10 h-10'} bg-blue-500 rounded-full flex items-center justify-center ${isMobile ? 'mr-3' : 'mr-4'} shadow-sm`}>
                <span className={`text-white ${isMobile ? 'text-xs' : 'text-sm'}`}>🏔️</span>
              </div>
              <div>
                <h4 className={`${isMobile ? 'text-sm' : 'text-base'} font-semibold text-blue-900`}>Podișul</h4>
                <p className="text-xs text-blue-700">Mediu</p>
              </div>
            </div>
            <p className="text-sm text-blue-700 mb-3">Nivele 21-40 • Provocări în creștere</p>
            <Badge className="bg-blue-100 text-blue-700 border-blue-200 text-xs">Se deblochează la nivel 20</Badge>
          </CardContent>
        </Card>

        {!isMobile && (
          <Card className="bg-purple-50/50 border-purple-200/50 shadow-sm hover:shadow-md transition-shadow">
            <CardContent className="p-6">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center mr-4 shadow-sm">
                <span className="text-white text-sm">⚡</span>
              </div>
              <div>
                <h4 className="font-semibold text-purple-900">Muntele Înțelepciunii</h4>
                <p className="text-sm text-purple-700">Dificil</p>
              </div>
            </div>
              <p className="text-sm text-purple-700 mb-3">Nivele 41-60 • Teste avansate</p>
              <Badge className="bg-purple-100 text-purple-700 border-purple-200">Se deblochează la nivel 40</Badge>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
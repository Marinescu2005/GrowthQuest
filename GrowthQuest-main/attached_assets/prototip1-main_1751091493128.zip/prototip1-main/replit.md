# TranscendUp - Personal Development Platform

## Overview

TranscendUp is a personal development platform built with React and Express, featuring a gamified progress tracking system. The application helps users track their personal growth journey through interactive maps, journal entries, statistics, and achievement systems. The platform is designed with a Romanian language interface and focuses on providing an engaging user experience for personal development.

## System Architecture

The application follows a full-stack architecture with:

- **Frontend**: React with TypeScript using Vite as the build tool
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **UI Framework**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing

The system uses a monorepo structure with shared TypeScript schemas between client and server.

## Key Components

### Frontend Architecture
- **React SPA**: Single-page application with component-based architecture
- **UI Components**: Comprehensive set of shadcn/ui components for consistent design
- **Responsive Design**: Mobile-first approach with Tailwind CSS
- **Type Safety**: Full TypeScript implementation with shared schemas

### Backend Architecture
- **Express Server**: RESTful API with middleware for logging and error handling
- **Database Layer**: Drizzle ORM with PostgreSQL for data persistence
- **Session Management**: Cookie-based session handling
- **Memory Storage Fallback**: In-memory storage implementation for development

### Database Schema
The application uses five main entities:
- **Users**: Core user information with experience and levels
- **Progress Entries**: Individual progress tracking items
- **Journal Entries**: Personal reflection and note-taking
- **Achievements**: Gamification elements with points and categories
- **User Settings**: Personalization preferences including language and theme
- **Statistics**: Aggregated user activity data

## Data Flow

1. **Authentication**: Demo user system (currently uses user ID 1)
2. **Progress Tracking**: Users can mark levels as completed, earning experience points
3. **Journal System**: Create, read, update, and delete personal journal entries
4. **Achievement System**: Automatic achievement unlocking based on user activities
5. **Settings Management**: User preferences for language, theme, and notifications

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for Neon database
- **drizzle-orm**: Type-safe ORM for database operations
- **@tanstack/react-query**: Server state management and caching
- **wouter**: Lightweight client-side routing
- **date-fns**: Date manipulation and formatting

### UI Dependencies
- **@radix-ui**: Comprehensive set of headless UI components
- **tailwindcss**: Utility-first CSS framework
- **lucide-react**: Icon library
- **class-variance-authority**: Component variant management

### Development Dependencies
- **vite**: Modern build tool and dev server
- **typescript**: Type safety and development experience
- **esbuild**: Fast bundling for production builds

## Deployment Strategy

The application is configured for deployment on Replit with the following setup:

### Development Environment
- **Dev Server**: Runs on port 5000 with hot module replacement
- **Database**: PostgreSQL 16 module enabled
- **Build Process**: Vite for client-side bundling, esbuild for server bundling

### Production Build
- **Client Build**: Static assets generated to `dist/public`
- **Server Build**: Bundled server code to `dist/index.js`
- **Deployment Target**: Autoscale deployment on Replit

### Environment Configuration
- **DATABASE_URL**: Required environment variable for PostgreSQL connection
- **NODE_ENV**: Environment detection for development/production modes
- **Session Management**: PostgreSQL-backed sessions in production

## Recent Changes
- June 25, 2025: Complete design overhaul to match user's preferred aesthetic
  - First iteration: Clean minimalist design with slate/emerald/blue palette
  - Second iteration: Updated to green pastel theme matching user's reference image
  - Implemented circular level indicators with checkmarks for completed levels
  - Added reward system with orange trophy icons every 5 levels
  - Created progress tracking with percentage completion and XP system
  - Updated color scheme to emerald-focused with green gradients for pleasant visual appeal
  - Added full mobile responsive design with collapsible sidebar and optimized layouts
  - Implemented orientation support for both portrait and landscape modes on mobile
  - Optimized layouts for landscape mode with adjusted grid systems and component sizing
  - Maintained Romanian language interface throughout

## Changelog
- June 24, 2025. Initial setup
- June 25, 2025. Design transformation to minimalist clean aesthetic

## User Preferences

Preferred design style: Minimalist and clean but slightly vibrant and visually pleasing
Preferred communication style: Simple, everyday language in Romanian
import { users, journalEntries, type User, type InsertUser, type JournalEntry, type InsertJournalEntry, type UpdateJournalEntry } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Journal entries
  getAllJournalEntries(): Promise<JournalEntry[]>;
  getJournalEntry(id: number): Promise<JournalEntry | undefined>;
  createJournalEntry(entry: InsertJournalEntry): Promise<JournalEntry>;
  updateJournalEntry(id: number, entry: UpdateJournalEntry): Promise<JournalEntry | undefined>;
  deleteJournalEntry(id: number): Promise<boolean>;
  searchJournalEntries(query: string): Promise<JournalEntry[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private journalEntries: Map<number, JournalEntry>;
  private currentUserId: number;
  private currentJournalId: number;

  constructor() {
    this.users = new Map();
    this.journalEntries = new Map();
    this.currentUserId = 1;
    this.currentJournalId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllJournalEntries(): Promise<JournalEntry[]> {
    return Array.from(this.journalEntries.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async getJournalEntry(id: number): Promise<JournalEntry | undefined> {
    return this.journalEntries.get(id);
  }

  async createJournalEntry(insertEntry: InsertJournalEntry): Promise<JournalEntry> {
    const id = this.currentJournalId++;
    const now = new Date();
    const wordCount = insertEntry.content.split(/\s+/).filter(word => word.length > 0).length;
    
    const entry: JournalEntry = {
      id,
      title: insertEntry.title,
      content: insertEntry.content,
      wordCount,
      createdAt: now,
      updatedAt: now,
    };
    
    this.journalEntries.set(id, entry);
    return entry;
  }

  async updateJournalEntry(id: number, updateEntry: UpdateJournalEntry): Promise<JournalEntry | undefined> {
    const existingEntry = this.journalEntries.get(id);
    if (!existingEntry) {
      return undefined;
    }

    const wordCount = updateEntry.content 
      ? updateEntry.content.split(/\s+/).filter(word => word.length > 0).length
      : existingEntry.wordCount;

    const updatedEntry: JournalEntry = {
      ...existingEntry,
      ...updateEntry,
      wordCount,
      updatedAt: new Date(),
    };

    this.journalEntries.set(id, updatedEntry);
    return updatedEntry;
  }

  async deleteJournalEntry(id: number): Promise<boolean> {
    return this.journalEntries.delete(id);
  }

  async searchJournalEntries(query: string): Promise<JournalEntry[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.journalEntries.values())
      .filter(entry => 
        entry.title.toLowerCase().includes(lowerQuery) ||
        entry.content.toLowerCase().includes(lowerQuery)
      )
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
}

export const storage = new MemStorage();

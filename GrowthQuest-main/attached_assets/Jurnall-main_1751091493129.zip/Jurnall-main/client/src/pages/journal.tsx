import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { JournalBook } from "@/components/journal/journal-book";
import { SearchModal } from "@/components/journal/search-modal";
import { DeleteModal } from "@/components/journal/delete-modal";
import { ArrowLeft, Plus, Search, Calendar, Download, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { JournalEntry } from "@shared/schema";

export default function Journal() {
  const [currentEntryIndex, setCurrentEntryIndex] = useState(0);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [entryToDelete, setEntryToDelete] = useState<number | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());

  const { data: entries = [], isLoading, refetch } = useQuery<JournalEntry[]>({
    queryKey: ["/api/journal-entries"],
  });

  // Update current time every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  const currentEntry = entries[currentEntryIndex];
  const totalPages = Math.max(entries.length, 1);

  const handlePreviousPage = () => {
    if (currentEntryIndex > 0) {
      setCurrentEntryIndex(currentEntryIndex - 1);
    }
  };

  const handleNextPage = () => {
    if (currentEntryIndex < entries.length - 1) {
      setCurrentEntryIndex(currentEntryIndex + 1);
    } else {
      // Creează o nouă pagină când ajungi la sfârșitul jurnalului
      setCurrentEntryIndex(entries.length);
    }
  };

  const handleDeleteEntry = (id: number) => {
    setEntryToDelete(id);
    setShowDeleteModal(true);
  };

  const handleDeleteConfirmed = () => {
    // Adjust current index if needed
    if (currentEntryIndex >= entries.length - 1 && currentEntryIndex > 0) {
      setCurrentEntryIndex(currentEntryIndex - 1);
    }
    refetch();
  };

  // Listen for search navigation events
  useEffect(() => {
    const handleNavigateToEntry = (event: CustomEvent) => {
      const { entryId } = event.detail;
      const entryIndex = entries.findIndex(entry => entry.id === entryId);
      if (entryIndex !== -1) {
        setCurrentEntryIndex(entryIndex);
      }
    };

    window.addEventListener('navigate-to-entry', handleNavigateToEntry as EventListener);
    return () => {
      window.removeEventListener('navigate-to-entry', handleNavigateToEntry as EventListener);
    };
  }, [entries]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-gray-100/50 to-green-50/30 dark:bg-gradient-to-br dark:from-gray-900 dark:via-gray-800 dark:to-green-900/20 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-4 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-gray-100/50 to-green-50/30 dark:bg-gradient-to-br dark:from-gray-900 dark:via-gray-800 dark:to-green-900/20">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white dark:bg-gray-900 backdrop-blur-md border-b-2 border-green-200 dark:border-green-700 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-6 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-green-600 to-emerald-600 flex items-center justify-center shadow-md">
              <BookOpen className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                Jurnalul Meu
              </h1>
              <p className="text-sm text-gray-600 dark:text-gray-300">Locul tău de reflecție și inspirație</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowSearchModal(true)}
              className="border-green-200 text-green-700 hover:bg-green-50 dark:border-green-700 dark:text-green-300 dark:hover:bg-green-900/20"
            >
              <Search className="h-4 w-4 mr-2" />
              Caută
            </Button>
            
            <Button 
              variant="outline" 
              size="sm"
              className="border-green-200 text-green-700 hover:bg-green-50 dark:border-green-700 dark:text-green-300 dark:hover:bg-green-900/20"
            >
              <Calendar className="h-4 w-4 mr-2" />
              Calendar
            </Button>

            <Button 
              variant="outline" 
              size="sm"
              className="border-green-200 text-green-700 hover:bg-green-50 dark:border-green-700 dark:text-green-300 dark:hover:bg-green-900/20"
            >
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-6 py-12">
        <JournalBook
          currentEntry={currentEntry}
          currentTime={currentTime}
          entries={entries}
          currentEntryIndex={currentEntryIndex}
          onPreviousPage={handlePreviousPage}
          onNextPage={handleNextPage}
          onDeleteEntry={handleDeleteEntry}
          onRefetch={refetch}
        />
      </div>

      {/* Modals */}
      <SearchModal
        isOpen={showSearchModal}
        onClose={() => setShowSearchModal(false)}
      />
      
      <DeleteModal
        isOpen={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        entryId={entryToDelete}
        onDeleteConfirmed={handleDeleteConfirmed}
      />
    </div>
  );
}

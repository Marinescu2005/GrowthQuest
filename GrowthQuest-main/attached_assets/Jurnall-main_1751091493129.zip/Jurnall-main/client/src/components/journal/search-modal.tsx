import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { ro } from "date-fns/locale";
import { Search, X, ArrowRight } from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import type { JournalEntry } from "@shared/schema";

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SearchModal({ isOpen, onClose }: SearchModalProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: allEntries = [] } = useQuery<JournalEntry[]>({
    queryKey: ["/api/journal-entries"],
  });

  // Client-side search for better context matching
  const searchResults = searchQuery.length > 0 
    ? allEntries.filter(entry => 
        entry.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        entry.content.toLowerCase().includes(searchQuery.toLowerCase())
      ).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    : [];

  const isLoading = false;

  const highlightText = (text: string, query: string) => {
    if (!query) return text;
    
    const parts = text.split(new RegExp(`(${query})`, 'gi'));
    return parts.map((part, index) => 
      part.toLowerCase() === query.toLowerCase() ? (
        <mark key={index} className="bg-yellow-200 dark:bg-yellow-800/60 text-yellow-900 dark:text-yellow-100 px-1 py-0.5 rounded font-semibold">
          {part}
        </mark>
      ) : part
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-white dark:bg-gray-900 border-2 border-gray-300 dark:border-gray-600 max-w-2xl shadow-2xl">
        <DialogTitle className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Caută în jurnal</DialogTitle>
        
        <div className="flex items-center space-x-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500 h-5 w-5" />
            <Input
              type="text"
              placeholder="Caută în titluri și conținut..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 pr-4 py-3 bg-gray-50 dark:bg-gray-800 border-2 border-gray-300 dark:border-gray-600 focus:border-green-500 focus:ring-green-500/20 dark:focus:border-green-400 rounded-2xl"
              autoFocus
            />
          </div>
          <Button
            variant="outline"
            size="icon"
            className="w-12 h-12 rounded-2xl border-2 border-gray-300 hover:bg-gray-100 dark:border-gray-600 dark:hover:bg-gray-800"
            onClick={onClose}
          >
            <X className="h-4 w-4 text-gray-600 dark:text-gray-400" />
          </Button>
        </div>
        
        {/* Search Results */}
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {isLoading && searchQuery && (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="text-muted-foreground mt-3">Se caută...</p>
            </div>
          )}
          
          {!isLoading && searchQuery && searchResults.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Nu s-au găsit rezultate pentru "{searchQuery}"</p>
            </div>
          )}
          
          {searchResults.map((result) => (
            <div
              key={result.id}
              className="p-5 bg-gray-50 dark:bg-gray-800 rounded-2xl border-2 border-gray-200 dark:border-gray-700 hover:border-green-400 dark:hover:border-green-500 hover:bg-green-50 dark:hover:bg-green-950/30 transition-all cursor-pointer group shadow-sm hover:shadow-md"
              onClick={() => {
                // Find the index of this entry and navigate to it
                const entryIndex = searchResults.findIndex(entry => entry.id === result.id);
                if (entryIndex !== -1) {
                  // Navigate to the entry by triggering a custom event or using a callback
                  window.dispatchEvent(new CustomEvent('navigate-to-entry', { 
                    detail: { entryId: result.id } 
                  }));
                }
                onClose();
              }}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-2 text-lg">
                    {highlightText(result.title, searchQuery)}
                  </h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-3 bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded-lg inline-block">
                    {format(new Date(result.createdAt), "d MMMM yyyy", { locale: ro })}
                  </p>
                  <p className="text-sm text-gray-700 dark:text-gray-300 line-clamp-3 mb-3">
                    {highlightText(result.content.substring(0, 200) + (result.content.length > 200 ? "..." : ""), searchQuery)}
                  </p>
                  <div className="flex items-center space-x-3">
                    <span className="text-xs text-gray-600 dark:text-gray-400 bg-gray-200 dark:bg-gray-700 px-2 py-1 rounded">
                      {result.wordCount} cuvinte
                    </span>
                    <span className="text-xs text-green-600 dark:text-green-400 font-medium">
                      Click pentru navigare
                    </span>
                  </div>
                </div>
                <ArrowRight className="text-gray-400 group-hover:text-green-600 dark:text-gray-500 dark:group-hover:text-green-400 mt-1 h-5 w-5 transition-colors" />
              </div>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}

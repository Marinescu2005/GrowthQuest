import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { AlertTriangle } from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { TornPage } from "./torn-page";

interface DeleteModalProps {
  isOpen: boolean;
  onClose: () => void;
  entryId: number | null;
  onDeleteConfirmed: () => void;
}

export function DeleteModal({ isOpen, onClose, entryId, onDeleteConfirmed }: DeleteModalProps) {
  const [showTornPage, setShowTornPage] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/journal-entries/${id}`);
    },
    onSuccess: () => {
      setShowTornPage(true);
      setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: ["/api/journal-entries"] });
        toast({
          title: "Pagină ruptă",
          description: "Pagina a fost ruptă din caiet.",
        });
        onDeleteConfirmed();
        onClose();
        setShowTornPage(false);
      }, 2000);
    },
    onError: () => {
      toast({
        title: "Eroare la ștergere",
        description: "Nu s-a putut rupe pagina din caiet.",
        variant: "destructive",
      });
    },
  });

  const handleConfirmDelete = () => {
    if (entryId) {
      deleteMutation.mutate(entryId);
    }
  };

  if (showTornPage) {
    return (
      <Dialog open={isOpen} onOpenChange={() => {}}>
        <DialogContent className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700 max-w-lg">
          <DialogTitle className="sr-only">Pagină ruptă</DialogTitle>
          <TornPage
            entry={{
              id: entryId || 0,
              title: "Pagină ruptă",
              createdAt: new Date()
            }}
          />
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700 max-w-md">
        <DialogTitle className="sr-only">Confirmă ștergerea</DialogTitle>
        
        <div className="text-center p-6">
          <div className="w-16 h-16 mx-auto mb-6 rounded-3xl bg-red-50 dark:bg-red-900/20 flex items-center justify-center">
            <AlertTriangle className="h-8 w-8 text-red-500" />
          </div>
          
          <h3 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">
            Ștergi această intrare?
          </h3>
          <p className="text-muted-foreground mb-8 leading-relaxed">
            Această acțiune va șterge definitiv intrarea din jurnal. Nu o vei putea recupera după ștergere.
          </p>
          
          <div className="flex space-x-3">
            <Button
              variant="outline"
              className="flex-1"
              onClick={onClose}
              disabled={deleteMutation.isPending}
            >
              Anulează
            </Button>
            <Button
              variant="destructive"
              className="flex-1 bg-red-500 hover:bg-red-600 text-white"
              onClick={handleConfirmDelete}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "Se șterge..." : "Șterge"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

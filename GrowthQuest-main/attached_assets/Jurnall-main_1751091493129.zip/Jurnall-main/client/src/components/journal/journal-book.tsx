import { useState } from "react";
import { format } from "date-fns";
import { ro } from "date-fns/locale";
import { Book, ChevronLeft, ChevronRight, BookOpen, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { WritingInterface } from "./writing-interface";
import type { JournalEntry } from "@shared/schema";

interface JournalBookProps {
  currentEntry?: JournalEntry;
  currentTime: Date;
  entries: JournalEntry[];
  currentEntryIndex: number;
  onPreviousPage: () => void;
  onNextPage: () => void;
  onDeleteEntry: (id: number) => void;
  onRefetch: () => void;
}

export function JournalBook({
  currentEntry,
  currentTime,
  entries,
  currentEntryIndex,
  onPreviousPage,
  onNextPage,
  onDeleteEntry,
  onRefetch,
}: JournalBookProps) {
  const [isCreatingNew, setIsCreatingNew] = useState(false);

  const handleCreateNew = () => {
    setIsCreatingNew(true);
  };

  const handleEntryCreated = () => {
    setIsCreatingNew(false);
    onRefetch();
  };

  const handleCancelNew = () => {
    setIsCreatingNew(false);
  };

  const formatDate = (date: Date) => {
    return format(date, "d MMMM yyyy", { locale: ro });
  };

  const formatTime = (date: Date) => {
    return format(date, "HH:mm", { locale: ro });
  };

  // Calculate page numbers for double page layout
  const leftPageNumber = currentEntryIndex * 2 + 1;
  const rightPageNumber = currentEntryIndex * 2 + 2;
  const totalPages = Math.max(entries.length * 2, 2);

  return (
    <div className="journal-container max-w-5xl w-full relative">
      {/* Clean Journal Card */}
      <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-xl border-2 border-gray-200 dark:border-gray-700 overflow-hidden min-h-[650px]">
        
        {/* Header */}
        <div className="border-b-2 border-gray-200 dark:border-gray-700 p-6 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/30 dark:to-emerald-900/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-green-600 to-emerald-600 flex items-center justify-center shadow-md">
                <BookOpen className="h-6 w-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  {currentEntry?.title || "Pagină nouă"}
                </h2>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  {currentEntry ? formatDate(new Date(currentEntry.createdAt)) : formatDate(currentTime)}
                  {currentEntry && ` • ${formatTime(new Date(currentEntry.createdAt))}`}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-300">
              <span className="font-medium bg-green-100 dark:bg-green-900/50 px-3 py-1 rounded-lg">
                Pagina {currentEntryIndex + 1} din {Math.max(entries.length + 1, 1)}
              </span>
              {entries.length > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowSearchModal(true)}
                  className="border-green-300 text-green-700 hover:bg-green-100 hover:border-green-400 dark:border-green-600 dark:text-green-400 dark:hover:bg-green-900/30"
                >
                  <Search className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="p-8 min-h-[500px]">
          {currentEntryIndex >= entries.length ? (
            // New entry mode when navigating beyond existing entries
            <WritingInterface
              entry={undefined}
              onSave={() => {
                handleEntryCreated();
                setCurrentEntryIndex(entries.length); // Stay on the new entry
              }}
              onCancel={entries.length > 0 ? () => setCurrentEntryIndex(entries.length - 1) : undefined}
              isNotebookMode={true}
            />
          ) : isCreatingNew || (!currentEntry && entries.length === 0) ? (
            <WritingInterface
              entry={isCreatingNew ? undefined : currentEntry}
              onSave={handleEntryCreated}
              onCancel={entries.length > 0 ? handleCancelNew : undefined}
              onDelete={currentEntry ? () => onDeleteEntry(currentEntry.id) : undefined}
              isNotebookMode={true}
            />
          ) : currentEntry ? (
            <WritingInterface
              entry={currentEntry}
              onSave={onRefetch}
              onDelete={() => onDeleteEntry(currentEntry.id)}
              isNotebookMode={true}
            />
          ) : (
            // Empty State
            <div className="text-center py-24">
              <div className="w-24 h-24 mx-auto mb-8 rounded-3xl bg-gradient-to-br from-green-100 to-emerald-100 dark:from-green-900/30 dark:to-emerald-900/30 flex items-center justify-center shadow-lg">
                <Book className="h-12 w-12 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-2xl font-semibold mb-4 text-green-800 dark:text-green-200">Începe să scrii</h3>
              <p className="text-green-600/70 dark:text-green-400/70 mb-10 max-w-md mx-auto leading-relaxed text-lg">
                Creează prima ta intrare în jurnal. Un loc pentru gândurile și momentele tale importante.
              </p>
              <Button
                onClick={handleCreateNew}
                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white px-8 py-3 rounded-2xl shadow-lg transform hover:scale-105 transition-all duration-200"
              >
                <Book className="mr-2 h-5 w-5" />
                Prima Intrare
              </Button>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="border-t border-green-100 dark:border-green-800/30 p-6 bg-gradient-to-r from-green-50/30 to-emerald-50/20 dark:from-green-900/20 dark:to-emerald-900/15">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="sm"
              className="text-green-600 dark:text-green-400 hover:text-green-800 hover:bg-green-100/50 dark:hover:text-green-200 dark:hover:bg-green-900/20 disabled:opacity-40 disabled:cursor-not-allowed px-4 py-2"
              onClick={onPreviousPage}
              disabled={currentEntryIndex === 0}
            >
              <ChevronLeft className="h-4 w-4 mr-2" />
              Anterior
            </Button>
            
            <div className="flex items-center space-x-3">
              {Array.from({ length: Math.max(entries.length + 1, 1) }).map((_, index) => (
                <div
                  key={index}
                  className={`w-3 h-3 rounded-full transition-all duration-200 ${
                    index === currentEntryIndex 
                      ? "bg-green-600 dark:bg-green-400 scale-125 shadow-sm" 
                      : "bg-green-200 dark:bg-green-700/50 hover:bg-green-300 dark:hover:bg-green-600/50"
                  }`}
                />
              ))}
            </div>
            
            <Button
              variant="ghost"
              size="sm"
              className="text-green-600 dark:text-green-400 hover:text-green-800 hover:bg-green-100/50 dark:hover:text-green-200 dark:hover:bg-green-900/20 px-4 py-2"
              onClick={onNextPage}
            >
              {currentEntryIndex >= entries.length ? "Pagină nouă" : "Următor"}
              <ChevronRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>


    </div>
  );
}

import { useState } from "react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { ro } from "date-fns/locale";

interface TornPageProps {
  entry: {
    id: number;
    title: string;
    createdAt: Date;
  };
  onRestore?: () => void;
}

export function TornPage({ entry, onRestore }: TornPageProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div className="relative h-full flex items-center justify-center">
      <motion.div
        className="torn-page-container relative"
        onHoverStart={() => setIsHovered(true)}
        onHoverEnd={() => setIsHovered(false)}
        whileHover={{ scale: 1.02 }}
        transition={{ duration: 0.2 }}
      >
        {/* Torn Page Effect */}
        <div className="relative w-48 h-64 transform rotate-2">
          {/* Paper Background */}
          <div className="absolute inset-0 bg-white dark:bg-gray-100 shadow-lg">
            {/* Torn Edge Effect */}
            <div className="absolute top-0 left-0 right-0 h-6 bg-white dark:bg-gray-100 torn-edge"></div>
            
            {/* Page Lines */}
            <div className="absolute inset-0 pt-8">
              {[...Array(15)].map((_, i) => (
                <div
                  key={i}
                  className="h-[1px] bg-blue-200 dark:bg-blue-300 mx-4 opacity-30"
                  style={{ top: `${32 + i * 16}px` }}
                ></div>
              ))}
            </div>
            
            {/* Red Margin Line */}
            <div className="absolute left-8 top-8 bottom-4 w-[1px] bg-red-300 dark:bg-red-400 opacity-40"></div>
            
            {/* Content */}
            <div className="p-6 pt-10">
              <div className="text-xs text-gray-500 mb-2">
                {format(entry.createdAt, "d MMMM yyyy", { locale: ro })}
              </div>
              <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-800 line-clamp-2">
                {entry.title}
              </h4>
              <div className="mt-4 space-y-2">
                <div className="h-[1px] bg-gray-300 w-3/4"></div>
                <div className="h-[1px] bg-gray-300 w-5/6"></div>
                <div className="h-[1px] bg-gray-300 w-2/3"></div>
              </div>
            </div>
            
            {/* Page Number */}
            <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-xs text-gray-400">
              {entry.id}
            </div>
          </div>
          
          {/* Torn Pieces */}
          <div className="absolute -top-2 left-4 w-6 h-4 bg-white dark:bg-gray-100 transform rotate-12 shadow-sm"></div>
          <div className="absolute -top-1 right-8 w-4 h-3 bg-white dark:bg-gray-100 transform -rotate-6 shadow-sm"></div>
        </div>
        
        {/* Overlay Message */}
        <motion.div
          className="absolute inset-0 flex items-center justify-center bg-black/60 rounded-lg"
          initial={{ opacity: 0 }}
          animate={{ opacity: isHovered ? 1 : 0 }}
          transition={{ duration: 0.2 }}
        >
          <div className="text-center text-white">
            <p className="text-sm font-medium mb-2">Pagină ruptă</p>
            <p className="text-xs opacity-80">Intrarea a fost ștearsă</p>
            {onRestore && (
              <button
                onClick={onRestore}
                className="mt-3 text-xs bg-white/20 hover:bg-white/30 px-3 py-1 rounded-full transition-colors"
              >
                Restaurează
              </button>
            )}
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}
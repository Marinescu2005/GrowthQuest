import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { ro } from "date-fns/locale";
import { Trash2, Save, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { JournalEntry, InsertJournalEntry, UpdateJournalEntry } from "@shared/schema";

interface WritingInterfaceProps {
  entry?: JournalEntry;
  onSave: () => void;
  onCancel?: () => void;
  onDelete?: () => void;
  isNotebookMode?: boolean;
}

export function WritingInterface({ entry, onSave, onCancel, onDelete, isNotebookMode = false }: WritingInterfaceProps) {
  const [title, setTitle] = useState(entry?.title || "");
  const [content, setContent] = useState(entry?.content || "");
  const [lastSaved, setLastSaved] = useState<Date | null>(entry?.updatedAt || null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const wordCount = content.split(/\s+/).filter(word => word.length > 0).length;

  // Auto-save functionality
  useEffect(() => {
    if (!entry || (!title.trim() && !content.trim())) return;

    const autoSaveTimer = setTimeout(() => {
      if (title !== entry.title || content !== entry.content) {
        handleSave();
      }
    }, 5000); // Auto-save after 5 seconds of inactivity

    return () => clearTimeout(autoSaveTimer);
  }, [title, content, entry]);

  const createMutation = useMutation({
    mutationFn: async (data: InsertJournalEntry) => {
      const response = await apiRequest("POST", "/api/journal-entries", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/journal-entries"] });
      setLastSaved(new Date());
      toast({
        title: "Intrare salvată",
        description: "Intrarea din jurnal a fost salvată cu succes.",
      });
      onSave();
    },
    onError: () => {
      toast({
        title: "Eroare la salvare",
        description: "Nu s-a putut salva intrarea din jurnal.",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: UpdateJournalEntry) => {
      const response = await apiRequest("PATCH", `/api/journal-entries/${entry!.id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/journal-entries"] });
      setLastSaved(new Date());
      toast({
        title: "Intrare actualizată",
        description: "Intrarea din jurnal a fost actualizată cu succes.",
      });
      onSave();
    },
    onError: () => {
      toast({
        title: "Eroare la actualizare",
        description: "Nu s-a putut actualiza intrarea din jurnal.",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    if (!title.trim() && !content.trim()) {
      toast({
        title: "Câmpuri goale",
        description: "Te rog să completezi cel puțin titlul sau conținutul.",
        variant: "destructive",
      });
      return;
    }

    const data = {
      title: title.trim() || "Intrare fără titlu",
      content: content.trim(),
      wordCount,
    };

    if (entry) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const formatLastModified = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "acum";
    if (diffInMinutes < 60) return `acum ${diffInMinutes} minute`;
    if (diffInMinutes < 1440) return `acum ${Math.floor(diffInMinutes / 60)} ore`;
    
    return format(date, "d MMMM yyyy", { locale: ro });
  };

  if (isNotebookMode) {
    return (
      <div className="clean-writing h-full flex flex-col">
        {/* Title */}
        <div className="mb-8">
          <Input
            type="text"
            placeholder="Titlul intrării..."
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="bg-transparent text-2xl font-semibold text-gray-900 dark:text-white placeholder:text-gray-400 dark:placeholder:text-gray-500 border-none outline-none focus:ring-0 w-full px-0 py-3"
          />
        </div>

        {/* Writing Area */}
        <div className="flex-1 mb-6">
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Scrie aici gândurile tale..."
            className="w-full h-full bg-transparent text-gray-800 dark:text-gray-200 placeholder:text-gray-400 dark:placeholder:text-gray-500 border-none outline-none resize-none leading-relaxed text-lg p-0 focus:ring-0"
          />
        </div>

        {/* Bottom Status */}
        <div className="flex items-center justify-between pt-6 border-t-2 border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-4">
            {/* Auto-save indicator */}
            {(createMutation.isPending || updateMutation.isPending) && (
              <div className="flex items-center space-x-2 text-sm text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-900/20 px-3 py-1 rounded-lg">
                <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
                <span>Se salvează...</span>
              </div>
            )}
            
            {lastSaved && !(createMutation.isPending || updateMutation.isPending) && (
              <div className="flex items-center space-x-2 text-sm text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-900/20 px-3 py-1 rounded-lg">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>Salvat</span>
              </div>
            )}
            
            <span className="text-sm text-gray-600 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-lg">
              {wordCount} cuvinte
            </span>
          </div>
          
          <div className="flex items-center space-x-3">
            {onDelete && (
              <Button
                variant="ghost"
                size="sm"
                className="border-red-300 text-red-600 hover:bg-red-50 hover:border-red-400 dark:border-red-600 dark:text-red-400 dark:hover:bg-red-900/20"
                onClick={onDelete}
                title="Șterge intrarea"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
            
            <Button
              onClick={handleSave}
              disabled={createMutation.isPending || updateMutation.isPending}
              className="bg-green-600 hover:bg-green-700 text-white shadow-md px-8 py-2 border-2 border-green-700"
              size="sm"
            >
              <Save className="mr-2 h-4 w-4" />
              {entry ? "Actualizează" : "Salvează"}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="writing-interface h-full flex flex-col">
      {/* Entry Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4 flex-1">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-green-600 to-emerald-600 flex items-center justify-center text-white font-bold shadow-lg">
            {entry?.id || "✨"}
          </div>
          <Input
            type="text"
            placeholder="Titlul intrării..."
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="bg-transparent text-xl font-bold text-gray-900 dark:text-white placeholder-gray-400 border-none outline-none focus:ring-0 transition-colors flex-1"
          />
        </div>
        
        {/* Entry Actions */}
        <div className="flex items-center space-x-3">
          {/* Auto-save indicator */}
          {(createMutation.isPending || updateMutation.isPending) && (
            <div className="flex items-center space-x-2 text-sm text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-900/20 px-3 py-1 rounded-lg border border-orange-200 dark:border-orange-800">
              <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
              <span>Se salvează...</span>
            </div>
          )}
          
          {lastSaved && !(createMutation.isPending || updateMutation.isPending) && (
            <div className="flex items-center space-x-2 text-sm text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-900/20 px-3 py-1 rounded-lg border border-green-200 dark:border-green-800">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span>Salvat</span>
            </div>
          )}
          
          {onCancel && (
            <Button
              variant="ghost"
              size="icon"
              className="w-9 h-9 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 border border-gray-300 dark:border-gray-600"
              onClick={onCancel}
              title="Anulează"
            >
              <X className="h-4 w-4" />
            </Button>
          )}
          
          {onDelete && (
            <Button
              variant="ghost"
              size="icon"
              className="w-9 h-9 rounded-xl hover:bg-red-50 dark:hover:bg-red-900/20 text-red-500 hover:text-red-600 border border-red-300 dark:border-red-600"
              onClick={onDelete}
              title="Șterge pagina"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>

      {/* Writing Area */}
      <div className="flex-1 mb-6">
        <Textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Începe să scrii aici... Descrie ziua ta, gândurile sau orice îți vine în minte."
          className="w-full h-full bg-transparent text-gray-800 dark:text-gray-200 placeholder:text-gray-400 dark:placeholder:text-gray-500 border-none outline-none resize-none leading-relaxed text-lg p-0 focus:ring-0"
        />
      </div>

      {/* Writing Tools */}
      <div className="flex items-center justify-between pt-6 border-t-2 border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-4">
          <span className="text-sm text-gray-600 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-lg">
            {wordCount} cuvinte
          </span>
          {lastSaved && (
            <span className="text-sm text-gray-600 dark:text-gray-400">
              Actualizat {formatLastModified(lastSaved)}
            </span>
          )}
        </div>
        
        <Button
          onClick={handleSave}
          disabled={createMutation.isPending || updateMutation.isPending}
          className="bg-green-600 hover:bg-green-700 text-white shadow-md px-8 py-2 border-2 border-green-700"
          size="sm"
        >
          <Save className="mr-2 h-4 w-4" />
          {entry ? "Actualizează" : "Salvează"}
        </Button>
      </div>
    </div>
  );
}

# Journal Application - Replit.md

## Overview

This is a modern full-stack journal application built with React frontend and Express backend. The application allows users to create, read, update, and delete journal entries with a clean, book-like interface. It features real-time search functionality, auto-save capabilities, and responsive design.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Bundler**: Vite for fast development and optimized builds
- **UI Framework**: Tailwind CSS with shadcn/ui component library
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript for type safety
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Development Storage**: In-memory storage fallback for development

## Key Components

### Database Layer
- **ORM**: Drizzle ORM with schema-first approach
- **Schema Location**: `shared/schema.ts` for type sharing between client and server
- **Tables**: 
  - `users` - User authentication (prepared for future use)
  - `journal_entries` - Main journal entries with title, content, timestamps, and word count
- **Migrations**: Managed through `drizzle.config.ts`

### API Layer
- **REST API**: Express routes in `server/routes.ts`
- **Endpoints**:
  - GET `/api/journal-entries` - Fetch all entries
  - GET `/api/journal-entries/:id` - Fetch single entry
  - POST `/api/journal-entries` - Create new entry
  - PATCH `/api/journal-entries/:id` - Update entry
  - DELETE `/api/journal-entries/:id` - Delete entry
- **Validation**: Zod schemas for request validation
- **Error Handling**: Centralized error handling with proper HTTP status codes

### Frontend Components
- **Journal Book Interface**: Book-like pagination interface
- **Writing Interface**: Rich text editing with auto-save
- **Search Modal**: Real-time search through entries
- **Delete Modal**: Confirmation dialog for entry deletion

## Data Flow

1. **Entry Creation**: User creates new entry → Frontend validates → API creates entry → Database stores → UI updates
2. **Entry Editing**: User modifies entry → Auto-save triggers → API updates entry → Database updates → UI reflects changes
3. **Search**: User types query → API searches entries → Results displayed in modal
4. **Pagination**: User navigates entries → Frontend manages current index → Displays appropriate entry

## External Dependencies

### Production Dependencies
- **@neondatabase/serverless**: Neon PostgreSQL driver
- **drizzle-orm**: Database ORM
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI primitives
- **wouter**: Lightweight routing
- **date-fns**: Date formatting and manipulation
- **zod**: Schema validation

### Development Dependencies
- **Vite**: Build tool and dev server
- **TypeScript**: Type checking
- **Tailwind CSS**: Utility-first CSS framework
- **PostCSS**: CSS processing

## Deployment Strategy

### Replit Configuration
- **Runtime**: Node.js 20 with PostgreSQL 16 module
- **Development**: `npm run dev` starts both frontend and backend
- **Build Process**: Vite builds frontend, esbuild bundles backend
- **Production**: Serves static files and API from single Express server

### Environment Setup
- **Database**: Requires `DATABASE_URL` environment variable
- **Port**: Configures port 5000 for local development
- **Auto-scaling**: Configured for Replit's autoscale deployment

### Build Process
1. Frontend build: Vite compiles React app to `dist/public`
2. Backend build: esbuild bundles server code to `dist/index.js`
3. Production: Single Node.js process serves both static files and API

## Changelog

```
Changelog:
- June 24, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```
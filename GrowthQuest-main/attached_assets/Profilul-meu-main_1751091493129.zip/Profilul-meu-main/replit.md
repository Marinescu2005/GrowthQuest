# RPG Profile System

## Overview

This is a full-stack web application that implements an RPG-style user profile system with achievements, collectible cards, streak tracking, and extensive customization options. The application provides a gamified experience for users to track their progress, unlock achievements, collect cards, and maintain activity streaks.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: React Query (@tanstack/react-query) for server state management
- **UI Components**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with custom RPG-themed color palette and design tokens
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM for schema management and queries
- **Database Provider**: Neon Database (@neondatabase/serverless) for serverless PostgreSQL
- **Session Management**: Express sessions with PostgreSQL session store
- **Development**: TSX for TypeScript execution in development

### Data Storage Strategy
- **Primary Database**: PostgreSQL hosted on Neon for production scalability
- **ORM**: Drizzle ORM chosen for type-safe database operations and excellent TypeScript integration
- **Schema Management**: Drizzle Kit for migrations and schema synchronization
- **Session Storage**: PostgreSQL-backed sessions using connect-pg-simple

## Key Components

### Database Schema
The application uses a comprehensive schema with the following core entities:
- **Users**: Complete user profiles with RPG progression (level, XP, streaks, customization)
- **Achievements**: Achievement system with categories, requirements, and rewards
- **UserAchievements**: Junction table tracking user progress on achievements
- **Cards**: Collectible card system with rarity tiers (common, rare, epic, legendary)
- **UserCards**: User's card collection and unlock tracking
- **StreakHistory**: Daily activity tracking for streak calculations
- **StreakMilestones**: Configurable streak rewards and milestones

### Frontend Components
- **ProfileHeader**: RPG-styled user profile display with level, XP, and stats
- **AchievementsTab**: Achievement browser with progress tracking and completion status
- **CardsTab**: Card collection viewer with rarity filtering and unlock status
- **StreakTab**: Calendar-based streak visualization and milestone tracking
- **CustomizationTab**: User preference management for themes, animations, and visual settings

### API Layer
RESTful API endpoints providing:
- User profile management (GET, PATCH)
- Achievement system endpoints
- Card collection management
- Streak tracking and history
- Real-time progress updates

## Data Flow

1. **User Profile Loading**: React Query fetches user data from `/api/profile/:id` endpoint
2. **Achievement Tracking**: Background processes monitor user actions and update achievement progress
3. **Card Unlocking**: Achievement completions and milestones trigger card unlock events
4. **Streak Management**: Daily check-ins update streak counters and trigger milestone rewards
5. **Customization Sync**: User preference changes immediately update the UI and sync to the database
6. **Real-time Updates**: React Query's caching and invalidation provide responsive UI updates

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React Query, React Hook Form with Zod validation
- **UI Components**: Complete Radix UI component library for accessible, customizable components
- **Database**: Drizzle ORM with PostgreSQL driver and Neon serverless adapter
- **Development Tools**: Vite, TypeScript, ESBuild for optimized builds

### Styling and Design
- **Tailwind CSS**: Utility-first CSS framework with custom RPG theme configuration
- **Lucide React**: Comprehensive icon library for consistent iconography
- **Custom Animations**: CSS animations and transitions for RPG-style visual effects

### Deployment Dependencies
- **Replit Integration**: Custom Vite plugins for Replit development environment
- **Production Build**: ESBuild bundling for optimized server-side code

## Deployment Strategy

### Development Environment
- **Replit Configuration**: Optimized for Replit's cloud development environment
- **Hot Reloading**: Vite dev server with HMR for rapid development iteration
- **Database**: Automatic PostgreSQL 16 module provisioning in Replit environment

### Production Deployment
- **Build Process**: Two-stage build (client-side Vite build + server-side ESBuild bundle)
- **Runtime**: Node.js production server serving static assets and API endpoints
- **Database**: Production PostgreSQL instance with connection pooling
- **Autoscaling**: Configured for Replit's autoscale deployment target

### Environment Configuration
- **Development**: `npm run dev` - Concurrent client and server development
- **Production**: `npm run build && npm run start` - Optimized production deployment
- **Database Migrations**: `npm run db:push` for schema synchronization

## Changelog

- June 24, 2025: Initial RPG profile system setup
- June 24, 2025: Redesigned as central dashboard integrating HistoryTracker and TerrainTreasure progress
- June 24, 2025: Adapted interface to complement existing TranscendUp applications without duplication
- June 25, 2025: Complete visual redesign matching modern map-style interface with clean cards, elegant gradients, and sophisticated layout

## User Preferences

Preferred communication style: Simple, everyday language.
Language preference: Romanian language for user interface and communication.
Design preference: Minimalist, sophisticated platform-style interface avoiding childish RPG elements while maintaining visual appeal and elegant colors.
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get user profile
  app.get("/api/profile/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Remove password from response
      const { password, ...userProfile } = user;
      res.json(userProfile);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user profile" });
    }
  });

  // Update user profile
  app.patch("/api/profile/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const updates = req.body;
      
      const updatedUser = await storage.updateUser(userId, updates);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const { password, ...userProfile } = updatedUser;
      res.json(userProfile);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user profile" });
    }
  });

  // Get all achievements
  app.get("/api/achievements", async (req, res) => {
    try {
      const achievements = await storage.getAllAchievements();
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch achievements" });
    }
  });

  // Get user achievements with progress
  app.get("/api/profile/:id/achievements", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const userAchievements = await storage.getUserAchievements(userId);
      
      // Also get all achievements to show locked ones
      const allAchievements = await storage.getAllAchievements();
      const unlockedAchievementIds = new Set(userAchievements.map(ua => ua.achievementId));
      
      const lockedAchievements = allAchievements
        .filter(a => !unlockedAchievementIds.has(a.id))
        .map(achievement => ({
          achievement,
          progress: 0,
          maxProgress: 1,
          isCompleted: false,
        }));

      res.json({
        unlocked: userAchievements,
        locked: lockedAchievements,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user achievements" });
    }
  });

  // Get all cards
  app.get("/api/cards", async (req, res) => {
    try {
      const cards = await storage.getAllCards();
      res.json(cards);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch cards" });
    }
  });

  // Get user cards
  app.get("/api/profile/:id/cards", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const userCards = await storage.getUserCards(userId);
      
      // Also get all cards to show locked ones
      const allCards = await storage.getAllCards();
      const unlockedCardIds = new Set(userCards.map(uc => uc.cardId));
      
      const lockedCards = allCards
        .filter(c => !unlockedCardIds.has(c.id))
        .map(card => ({
          card,
          isLocked: true,
        }));

      res.json({
        unlocked: userCards,
        locked: lockedCards,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user cards" });
    }
  });

  // Get user streak history
  app.get("/api/profile/:id/streak", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const year = parseInt(req.query.year as string) || new Date().getFullYear();
      const month = parseInt(req.query.month as string) || new Date().getMonth();
      
      const streakHistory = await storage.getUserStreakHistory(userId, year, month);
      const milestones = await storage.getStreakMilestones();
      
      res.json({
        history: streakHistory,
        milestones,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch streak data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

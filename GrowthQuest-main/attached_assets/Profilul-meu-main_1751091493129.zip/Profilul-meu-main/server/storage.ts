import { 
  users, 
  achievements, 
  userAchievements, 
  cards, 
  userCards, 
  streakHistory, 
  streakMilestones,
  type User, 
  type InsertUser,
  type Achievement,
  type InsertAchievement,
  type UserAchievement,
  type InsertUserAchievement,
  type Card,
  type InsertCard,
  type UserCard,
  type InsertUserCard,
  type StreakHistory,
  type InsertStreakHistory,
  type StreakMilestone,
  type InsertStreakMilestone
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<InsertUser>): Promise<User | undefined>;

  // Achievements
  getAllAchievements(): Promise<Achievement[]>;
  getUserAchievements(userId: number): Promise<(UserAchievement & { achievement: Achievement })[]>;
  getUserAchievementProgress(userId: number, achievementId: number): Promise<UserAchievement | undefined>;
  updateUserAchievementProgress(userId: number, achievementId: number, progress: number): Promise<UserAchievement>;
  completeUserAchievement(userId: number, achievementId: number): Promise<UserAchievement>;

  // Cards
  getAllCards(): Promise<Card[]>;
  getUserCards(userId: number): Promise<(UserCard & { card: Card })[]>;
  unlockUserCard(userId: number, cardId: number): Promise<UserCard>;

  // Streak
  getUserStreakHistory(userId: number, year: number, month: number): Promise<StreakHistory[]>;
  updateStreakDay(userId: number, date: Date, completed: boolean): Promise<StreakHistory>;
  getStreakMilestones(): Promise<StreakMilestone[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private achievements: Map<number, Achievement>;
  private userAchievements: Map<string, UserAchievement>;
  private cards: Map<number, Card>;
  private userCards: Map<string, UserCard>;
  private streakHistory: Map<string, StreakHistory>;
  private streakMilestones: Map<number, StreakMilestone>;
  private currentId: number;

  constructor() {
    this.users = new Map();
    this.achievements = new Map();
    this.userAchievements = new Map();
    this.cards = new Map();
    this.userCards = new Map();
    this.streakHistory = new Map();
    this.streakMilestones = new Map();
    this.currentId = 1;
    
    this.seedData();
  }

  private seedData() {
    // Seed default user
    const defaultUser: User = {
      id: 1,
      username: "dragonslayer",
      password: "password123",
      name: "Dragon Slayer Alex",
      title: "Master of Transcendence",
      level: 42,
      xp: 15847,
      maxXp: 18500,
      avatarFrame: "gold",
      background: "purple-blue",
      theme: "dark-rpg",
      animationLevel: "full",
      showParticleEffects: true,
      currentStreak: 23,
      bestStreak: 47,
      streakStartDate: new Date("2024-03-15"),
      totalHours: 342,
    };
    this.users.set(1, defaultUser);
    this.currentId = 2;

    // Seed achievements
    const defaultAchievements: Achievement[] = [
      {
        id: 1,
        title: "First Steps",
        description: "Complete your first daily challenge",
        icon: "crown",
        xpReward: 100,
        category: "beginner",
        requirement: "Complete 1 daily challenge",
        isHidden: false,
      },
      {
        id: 2,
        title: "Streak Master",
        description: "Maintain a 30-day streak",
        icon: "fire",
        xpReward: 500,
        category: "consistency",
        requirement: "Complete 30 consecutive days",
        isHidden: false,
      },
      {
        id: 3,
        title: "Legend",
        description: "Reach level 100",
        icon: "crown",
        xpReward: 2000,
        category: "progression",
        requirement: "Reach level 100",
        isHidden: false,
      },
      {
        id: 4,
        title: "Card Collector",
        description: "Unlocked 50 unique cards",
        icon: "check",
        xpReward: 250,
        category: "collection",
        requirement: "Unlock 50 cards",
        isHidden: false,
      },
    ];

    defaultAchievements.forEach(achievement => {
      this.achievements.set(achievement.id, achievement);
    });

    // Seed user achievements
    this.userAchievements.set("1-1", {
      id: 1,
      userId: 1,
      achievementId: 1,
      unlockedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
      progress: 1,
      maxProgress: 1,
      isCompleted: true,
    });

    this.userAchievements.set("1-2", {
      id: 2,
      userId: 1,
      achievementId: 2,
      unlockedAt: new Date(),
      progress: 23,
      maxProgress: 30,
      isCompleted: false,
    });

    this.userAchievements.set("1-4", {
      id: 3,
      userId: 1,
      achievementId: 4,
      unlockedAt: new Date(Date.now() - 60 * 60 * 1000), // 1 hour ago
      progress: 50,
      maxProgress: 50,
      isCompleted: true,
    });

    // Seed cards
    const defaultCards: Card[] = [
      {
        id: 1,
        name: "Dragon Avatar",
        description: "Mystical companion",
        rarity: "epic",
        icon: "dragon",
        category: "avatars",
        unlockRequirement: "Reach level 25",
      },
      {
        id: 2,
        name: "Magic Wand",
        description: "Spell enhancement",
        rarity: "rare",
        icon: "magic",
        category: "items",
        unlockRequirement: "Complete 10 challenges",
      },
      {
        id: 3,
        name: "Ancient Sword",
        description: "Legendary weapon",
        rarity: "legendary",
        icon: "sword",
        category: "weapons",
        unlockRequirement: "Reach level 50",
      },
    ];

    defaultCards.forEach(card => {
      this.cards.set(card.id, card);
    });

    // Seed user cards
    this.userCards.set("1-1", {
      id: 1,
      userId: 1,
      cardId: 1,
      unlockedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    });

    this.userCards.set("1-2", {
      id: 2,
      userId: 1,
      cardId: 2,
      unlockedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    });

    // Seed streak milestones
    const defaultMilestones: StreakMilestone[] = [
      {
        id: 1,
        title: "7 Day Warrior",
        description: "First week completed",
        icon: "medal",
        daysRequired: 7,
      },
      {
        id: 2,
        title: "Monthly Master",
        description: "Completed a full month",
        icon: "trophy",
        daysRequired: 30,
      },
      {
        id: 3,
        title: "Legendary Streak",
        description: "100 days of dedication",
        icon: "crown",
        daysRequired: 100,
      },
    ];

    defaultMilestones.forEach(milestone => {
      this.streakMilestones.set(milestone.id, milestone);
    });

    // Seed some streak history for the current month
    const today = new Date();
    for (let i = 1; i <= 23; i++) {
      const date = new Date(today.getFullYear(), today.getMonth(), i);
      this.streakHistory.set(`1-${date.toISOString().split('T')[0]}`, {
        id: i,
        userId: 1,
        date,
        completed: true,
      });
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { 
      id,
      username: insertUser.username,
      password: insertUser.password,
      name: insertUser.name,
      title: insertUser.title || "Novice Transcender",
      level: insertUser.level || 1,
      xp: insertUser.xp || 0,
      maxXp: insertUser.maxXp || 1000,
      avatarFrame: insertUser.avatarFrame || "gold",
      background: insertUser.background || "purple-blue",
      theme: insertUser.theme || "dark-rpg",
      animationLevel: insertUser.animationLevel || "full",
      showParticleEffects: insertUser.showParticleEffects ?? true,
      currentStreak: insertUser.currentStreak || 0,
      bestStreak: insertUser.bestStreak || 0,
      streakStartDate: insertUser.streakStartDate || null,
      totalHours: insertUser.totalHours || 0,
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;

    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getAllAchievements(): Promise<Achievement[]> {
    return Array.from(this.achievements.values());
  }

  async getUserAchievements(userId: number): Promise<(UserAchievement & { achievement: Achievement })[]> {
    const userAchievements = Array.from(this.userAchievements.values())
      .filter(ua => ua.userId === userId);
    
    return userAchievements.map(ua => ({
      ...ua,
      achievement: this.achievements.get(ua.achievementId)!,
    }));
  }

  async getUserAchievementProgress(userId: number, achievementId: number): Promise<UserAchievement | undefined> {
    return this.userAchievements.get(`${userId}-${achievementId}`);
  }

  async updateUserAchievementProgress(userId: number, achievementId: number, progress: number): Promise<UserAchievement> {
    const key = `${userId}-${achievementId}`;
    const existing = this.userAchievements.get(key);
    
    if (existing) {
      existing.progress = progress;
      return existing;
    }

    const newUserAchievement: UserAchievement = {
      id: this.currentId++,
      userId,
      achievementId,
      unlockedAt: new Date(),
      progress,
      maxProgress: this.achievements.get(achievementId)?.xpReward || 1,
      isCompleted: false,
    };

    this.userAchievements.set(key, newUserAchievement);
    return newUserAchievement;
  }

  async completeUserAchievement(userId: number, achievementId: number): Promise<UserAchievement> {
    const key = `${userId}-${achievementId}`;
    const existing = this.userAchievements.get(key);
    
    if (existing) {
      existing.isCompleted = true;
      existing.progress = existing.maxProgress;
      return existing;
    }

    const newUserAchievement: UserAchievement = {
      id: this.currentId++,
      userId,
      achievementId,
      unlockedAt: new Date(),
      progress: 1,
      maxProgress: 1,
      isCompleted: true,
    };

    this.userAchievements.set(key, newUserAchievement);
    return newUserAchievement;
  }

  async getAllCards(): Promise<Card[]> {
    return Array.from(this.cards.values());
  }

  async getUserCards(userId: number): Promise<(UserCard & { card: Card })[]> {
    const userCards = Array.from(this.userCards.values())
      .filter(uc => uc.userId === userId);
    
    return userCards.map(uc => ({
      ...uc,
      card: this.cards.get(uc.cardId)!,
    }));
  }

  async unlockUserCard(userId: number, cardId: number): Promise<UserCard> {
    const key = `${userId}-${cardId}`;
    const existing = this.userCards.get(key);
    
    if (existing) {
      return existing;
    }

    const newUserCard: UserCard = {
      id: this.currentId++,
      userId,
      cardId,
      unlockedAt: new Date(),
    };

    this.userCards.set(key, newUserCard);
    return newUserCard;
  }

  async getUserStreakHistory(userId: number, year: number, month: number): Promise<StreakHistory[]> {
    return Array.from(this.streakHistory.values())
      .filter(sh => 
        sh.userId === userId && 
        sh.date.getFullYear() === year && 
        sh.date.getMonth() === month
      );
  }

  async updateStreakDay(userId: number, date: Date, completed: boolean): Promise<StreakHistory> {
    const key = `${userId}-${date.toISOString().split('T')[0]}`;
    const existing = this.streakHistory.get(key);
    
    if (existing) {
      existing.completed = completed;
      return existing;
    }

    const newStreakHistory: StreakHistory = {
      id: this.currentId++,
      userId,
      date,
      completed,
    };

    this.streakHistory.set(key, newStreakHistory);
    return newStreakHistory;
  }

  async getStreakMilestones(): Promise<StreakMilestone[]> {
    return Array.from(this.streakMilestones.values());
  }
}

export const storage = new MemStorage();

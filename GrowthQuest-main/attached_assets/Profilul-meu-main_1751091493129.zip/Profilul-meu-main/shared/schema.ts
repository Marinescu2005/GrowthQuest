import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  title: text("title").notNull().default("Novice Transcender"),
  level: integer("level").notNull().default(1),
  xp: integer("xp").notNull().default(0),
  maxXp: integer("max_xp").notNull().default(1000),
  avatarFrame: text("avatar_frame").notNull().default("gold"),
  background: text("background").notNull().default("purple-blue"),
  theme: text("theme").notNull().default("dark-rpg"),
  animationLevel: text("animation_level").notNull().default("full"),
  showParticleEffects: boolean("show_particle_effects").notNull().default(true),
  currentStreak: integer("current_streak").notNull().default(0),
  bestStreak: integer("best_streak").notNull().default(0),
  streakStartDate: timestamp("streak_start_date"),
  totalHours: integer("total_hours").notNull().default(0),
});

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  xpReward: integer("xp_reward").notNull(),
  category: text("category").notNull(),
  requirement: text("requirement").notNull(),
  isHidden: boolean("is_hidden").notNull().default(false),
});

export const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  achievementId: integer("achievement_id").notNull(),
  unlockedAt: timestamp("unlocked_at").notNull().defaultNow(),
  progress: integer("progress").notNull().default(0),
  maxProgress: integer("max_progress").notNull().default(1),
  isCompleted: boolean("is_completed").notNull().default(false),
});

export const cards = pgTable("cards", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  rarity: text("rarity").notNull(), // common, rare, epic, legendary
  icon: text("icon").notNull(),
  category: text("category").notNull(),
  unlockRequirement: text("unlock_requirement").notNull(),
});

export const userCards = pgTable("user_cards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  cardId: integer("card_id").notNull(),
  unlockedAt: timestamp("unlocked_at").notNull().defaultNow(),
});

export const streakHistory = pgTable("streak_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: timestamp("date").notNull(),
  completed: boolean("completed").notNull().default(false),
});

export const streakMilestones = pgTable("streak_milestones", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  daysRequired: integer("days_required").notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const insertAchievementSchema = createInsertSchema(achievements).omit({
  id: true,
});

export const insertUserAchievementSchema = createInsertSchema(userAchievements).omit({
  id: true,
  unlockedAt: true,
});

export const insertCardSchema = createInsertSchema(cards).omit({
  id: true,
});

export const insertUserCardSchema = createInsertSchema(userCards).omit({
  id: true,
  unlockedAt: true,
});

export const insertStreakHistorySchema = createInsertSchema(streakHistory).omit({
  id: true,
});

export const insertStreakMilestoneSchema = createInsertSchema(streakMilestones).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;

export type UserAchievement = typeof userAchievements.$inferSelect;
export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;

export type Card = typeof cards.$inferSelect;
export type InsertCard = z.infer<typeof insertCardSchema>;

export type UserCard = typeof userCards.$inferSelect;
export type InsertUserCard = z.infer<typeof insertUserCardSchema>;

export type StreakHistory = typeof streakHistory.$inferSelect;
export type InsertStreakHistory = z.infer<typeof insertStreakHistorySchema>;

export type StreakMilestone = typeof streakMilestones.$inferSelect;
export type InsertStreakMilestone = z.infer<typeof insertStreakMilestoneSchema>;

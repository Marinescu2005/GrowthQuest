import { Progress } from "@/components/ui/progress";
import { User } from "lucide-react";

interface ProfileHeaderProps {
  user: {
    id: number;
    name: string;
    title: string;
    level: number;
    xp: number;
    maxXp: number;
    currentStreak: number;
    bestStreak: number;
    totalHours: number;
    avatarFrame: string;
  };
}

export default function ProfileHeader({ user }: ProfileHeaderProps) {
  const xpPercentage = (user.xp / user.maxXp) * 100;

  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-rpg-darker via-rpg-dark to-purple-900 border-b border-rpg-purple/30">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `radial-gradient(circle at 25% 25%, rgba(139, 92, 246, 0.3) 0%, transparent 50%), radial-gradient(circle at 75% 75%, rgba(245, 158, 11, 0.2) 0%, transparent 50%)`,
          }}
        />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row items-center lg:items-start gap-6">
          {/* Avatar Section */}
          <div className="relative">
            <div className="w-32 h-32 lg:w-40 lg:h-40 rounded-full bg-gradient-to-br from-rpg-gold via-rpg-purple to-rpg-blue p-1 shadow-rpg">
              <div className="w-full h-full rounded-full bg-rpg-darker flex items-center justify-center">
                <User className="w-12 h-12 lg:w-16 lg:h-16 text-rpg-gold" />
              </div>
            </div>
            {/* Level Badge */}
            <div className="absolute -bottom-2 -right-2 bg-rpg-gold text-rpg-dark px-3 py-1 rounded-full text-sm font-bold shadow-gold">
              Level {user.level}
            </div>
          </div>

          {/* Player Info */}
          <div className="flex-1 text-center lg:text-left">
            <h1 className="text-3xl lg:text-4xl font-bold text-rpg-gold mb-2">
              {user.name}
            </h1>
            <p className="text-rpg-blue-light mb-4">{user.title}</p>

            {/* XP Progress Bar */}
            <div className="mb-4">
              <div className="flex justify-between text-sm mb-1">
                <span>Experience</span>
                <span>
                  {user.xp.toLocaleString()} / {user.maxXp.toLocaleString()} XP
                </span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-3 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-rpg-blue to-rpg-purple h-full rounded-full transition-all duration-500 ease-out"
                  style={{ width: `${xpPercentage}%` }}
                />
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-center">
              <div className="bg-gray-800/50 rounded-lg p-3 backdrop-blur-sm">
                <div className="text-rpg-gold font-bold text-xl">127</div>
                <div className="text-xs text-gray-400">Achievements</div>
              </div>
              <div className="bg-gray-800/50 rounded-lg p-3 backdrop-blur-sm">
                <div className="text-rpg-green font-bold text-xl">
                  {user.currentStreak}
                </div>
                <div className="text-xs text-gray-400">Day Streak</div>
              </div>
              <div className="bg-gray-800/50 rounded-lg p-3 backdrop-blur-sm">
                <div className="text-rpg-blue font-bold text-xl">89</div>
                <div className="text-xs text-gray-400">Cards Unlocked</div>
              </div>
              <div className="bg-gray-800/50 rounded-lg p-3 backdrop-blur-sm">
                <div className="text-rpg-purple font-bold text-xl">
                  {user.totalHours}
                </div>
                <div className="text-xs text-gray-400">Hours Played</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useQuery } from "@tanstack/react-query";
import { Crown, Flame, Lock, Check, Star } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface AchievementsTabProps {
  userId: number;
}

const getAchievementIcon = (icon: string) => {
  switch (icon) {
    case "crown":
      return Crown;
    case "fire":
      return Flame;
    case "check":
      return Check;
    default:
      return Star;
  }
};

export default function AchievementsTab({ userId }: AchievementsTabProps) {
  const { data: achievementsData, isLoading } = useQuery({
    queryKey: [`/api/profile/${userId}/achievements`],
  });

  if (isLoading) {
    return (
      <div className="text-center py-8">
        <div className="text-gray-600">Se încarcă realizările...</div>
      </div>
    );
  }

  const { unlocked = [], locked = [] } = achievementsData || {};
  const recentAchievements = unlocked
    .filter((ua: any) => ua.isCompleted)
    .sort((a: any, b: any) => new Date(b.unlockedAt).getTime() - new Date(a.unlockedAt).getTime())
    .slice(0, 3);

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h3 className="text-lg font-medium text-gray-800 mb-2">Obiective Personale</h3>
        <p className="text-gray-600">Progresul și realizările tale în platformă</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {/* Completed Achievements */}
        {unlocked
          .filter((ua: any) => ua.isCompleted)
          .map((userAchievement: any) => {
            const IconComponent = getAchievementIcon(userAchievement.achievement.icon);
            return (
              <div
                key={userAchievement.id}
                className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-green-200 dark:border-green-800 shadow-sm hover:shadow-md transition-all duration-200"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="w-10 h-10 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                    <IconComponent className="w-5 h-5 text-green-600 dark:text-green-400" />
                  </div>
                  <div className="px-2 py-1 bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 text-xs font-medium rounded-full">COMPLETAT</div>
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">{userAchievement.achievement.title}</h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">{userAchievement.achievement.description}</p>
                <div className="flex items-center justify-between">
                  <div className="text-green-600 dark:text-green-400 text-sm font-medium">+{userAchievement.achievement.xpReward} XP</div>
                  <div className="text-xs text-gray-500">
                    {new Date(userAchievement.unlockedAt).toLocaleDateString()}
                  </div>
                </div>
              </div>
            );
          })}

        {/* In Progress Achievements */}
        {unlocked
          .filter((ua: any) => !ua.isCompleted)
          .map((userAchievement: any) => {
            const IconComponent = getAchievementIcon(userAchievement.achievement.icon);
            const progressPercentage = (userAchievement.progress / userAchievement.maxProgress) * 100;
            return (
              <div
                key={userAchievement.id}
                className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-blue-200 dark:border-blue-800 shadow-sm hover:shadow-md transition-all duration-200"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                    <IconComponent className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div className="px-2 py-1 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 text-xs font-medium rounded-full">ÎN PROGRES</div>
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">{userAchievement.achievement.title}</h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">{userAchievement.achievement.description}</p>
                <div className="mb-3">
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div
                      className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${progressPercentage}%` }}
                    />
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    {userAchievement.progress}/{userAchievement.maxProgress}
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="text-blue-600 dark:text-blue-400 text-sm font-medium">+{userAchievement.achievement.xpReward} XP</div>
                  <div className="text-xs text-gray-500">
                    {userAchievement.maxProgress - userAchievement.progress} rămase
                  </div>
                </div>
              </div>
            );
          })}

        {/* Locked Achievements */}
        {locked.map((lockedAchievement: any) => {
          return (
            <div
              key={lockedAchievement.achievement.id}
              className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700 shadow-sm opacity-60 hover:opacity-80 transition-opacity duration-200"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center">
                  <Lock className="w-5 h-5 text-gray-400" />
                </div>
                <div className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400 text-xs font-medium rounded-full">BLOCAT</div>
              </div>
              <h3 className="font-semibold text-gray-500 dark:text-gray-400 mb-2">
                {lockedAchievement.achievement.title}
              </h3>
              <p className="text-gray-400 dark:text-gray-500 text-sm mb-3">
                {lockedAchievement.achievement.description}
              </p>
              <div className="flex items-center justify-between">
                <div className="text-gray-400 dark:text-gray-500 text-sm">
                  +{lockedAchievement.achievement.xpReward} XP
                </div>
                <div className="text-xs text-gray-500">
                  {lockedAchievement.achievement.requirement}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent Achievements */}
      {recentAchievements.length > 0 && (
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            <Star className="inline-block w-5 h-5 mr-2 text-yellow-500" />
            Realizări Recente
          </h3>
          <div className="space-y-3">
            {recentAchievements.map((achievement: any) => {
              const IconComponent = getAchievementIcon(achievement.achievement.icon);
              return (
                <div
                  key={achievement.id}
                  className="flex items-center gap-4 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg"
                >
                  <div className="w-10 h-10 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                    <IconComponent className="w-5 h-5 text-green-600 dark:text-green-400" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-gray-900 dark:text-white">{achievement.achievement.title}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">{achievement.achievement.description}</div>
                  </div>
                  <div className="text-green-600 dark:text-green-400 text-sm font-medium">+{achievement.achievement.xpReward} XP</div>
                  <div className="text-xs text-gray-500">
                    {new Date(achievement.unlockedAt).toLocaleDateString()}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

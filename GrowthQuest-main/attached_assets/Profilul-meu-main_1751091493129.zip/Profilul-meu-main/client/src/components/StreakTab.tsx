import { useQuery } from "@tanstack/react-query";
import { Flame, Calendar, Trophy, Check, X, Medal } from "lucide-react";

interface StreakTabProps {
  userId: number;
}

export default function StreakTab({ userId }: StreakTabProps) {
  const currentDate = new Date();
  const { data: streakData, isLoading } = useQuery({
    queryKey: [`/api/profile/${userId}/streak`, { year: currentDate.getFullYear(), month: currentDate.getMonth() }],
  });

  const { data: user } = useQuery({
    queryKey: [`/api/profile/${userId}`],
  });

  if (isLoading) {
    return (
      <div className="text-center py-8">
        <div className="text-gray-600">Se încarcă datele streak-ului...</div>
      </div>
    );
  }

  const { history = [], milestones = [] } = streakData || {};

  // Generate calendar days for current month
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const daysInMonth = lastDay.getDate();
  const startingDayOfWeek = firstDay.getDay();

  const calendarDays = [];
  
  // Add empty cells for days before the first day of the month
  for (let i = 0; i < startingDayOfWeek; i++) {
    calendarDays.push(null);
  }

  // Add actual days of the month
  for (let day = 1; day <= daysInMonth; day++) {
    const dayData = history.find((h: any) => {
      const historyDate = new Date(h.date);
      return historyDate.getDate() === day;
    });
    
    calendarDays.push({
      day,
      completed: dayData?.completed || false,
      hasData: !!dayData,
    });
  }

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h3 className="text-lg font-medium text-gray-800 mb-2">Progres Temporal</h3>
        <p className="text-gray-600">Consistența și continuitatea în dezvoltare</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Current Streak Info */}
        <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
          <div className="text-center">
            <div className="w-14 h-14 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full mx-auto flex items-center justify-center mb-4">
              <Flame className="w-7 h-7 text-white" />
            </div>
            <h4 className="text-2xl font-semibold text-gray-800 mb-2">
              {user?.currentStreak || 0} zile
            </h4>
            <p className="text-gray-600 mb-4">Streak actual</p>
            <div className="text-sm text-gray-500 space-y-1">
              <div>
                Început: {user?.streakStartDate ? new Date(user.streakStartDate).toLocaleDateString('ro-RO') : "N/A"}
              </div>
              <div>Record: {user?.bestStreak || 0} zile</div>
            </div>
          </div>
        </div>

        {/* Streak Calendar */}
        <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
          <h4 className="text-md font-medium mb-4 text-gray-800 text-center">
            <Calendar className="inline-block w-4 h-4 mr-2 text-blue-500" />
            Luna aceasta
          </h4>
          
          {/* Calendar Header */}
          <div className="grid grid-cols-7 gap-1 text-center text-xs mb-2">
            {["Dum", "Lun", "Mar", "Mie", "Joi", "Vin", "Sâm"].map((day) => (
              <div key={day} className="text-gray-500 p-2 font-medium">
                {day}
              </div>
            ))}
          </div>
          
          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-1">
            {calendarDays.map((dayData, index) => {
              if (!dayData) {
                return <div key={index} className="w-8 h-8" />;
              }

              let bgColor = "bg-gray-100";
              let textColor = "text-gray-500";
              let icon = null;
              
              if (dayData.hasData) {
                if (dayData.completed) {
                  bgColor = "bg-green-500";
                  textColor = "text-white";
                  icon = <Check className="w-3 h-3 text-white" />;
                } else {
                  bgColor = "bg-red-500";
                  textColor = "text-white";
                  icon = <X className="w-3 h-3 text-white" />;
                }
              }

              return (
                <div
                  key={index}
                  className={`w-8 h-8 ${bgColor} rounded-lg flex items-center justify-center text-xs font-medium ${textColor} ${
                    !dayData.hasData ? "opacity-50" : ""
                  }`}
                >
                  {icon || dayData.day}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Streak Milestones */}
      <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
        <h4 className="text-md font-medium mb-6 text-gray-800 text-center">
          <Trophy className="inline-block w-4 h-4 mr-2 text-yellow-500" />
          Obiective streak
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {milestones.map((milestone: any) => {
            const isUnlocked = (user?.bestStreak || 0) >= milestone.daysRequired;
            const isInProgress = (user?.currentStreak || 0) >= milestone.daysRequired && !isUnlocked;
            
            return (
              <div
                key={milestone.id}
                className={`rounded-lg p-4 border-2 ${
                  isUnlocked
                    ? "bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-300"
                    : isInProgress
                    ? "bg-gradient-to-br from-blue-50 to-blue-100 border-blue-300"
                    : "bg-gray-50 border-gray-200"
                }`}
              >
                <div className="text-center">
                  <div
                    className={`w-12 h-12 rounded-full mx-auto flex items-center justify-center mb-3 ${
                      isUnlocked
                        ? "bg-yellow-500"
                        : isInProgress
                        ? "bg-blue-500"
                        : "bg-gray-400"
                    }`}
                  >
                    <Medal className="w-6 h-6 text-white" />
                  </div>
                  <div
                    className={`font-semibold ${
                      isUnlocked
                        ? "text-yellow-700"
                        : isInProgress
                        ? "text-blue-700"
                        : "text-gray-500"
                    }`}
                  >
                    {milestone.title}
                  </div>
                  <div className="text-sm text-gray-600 mt-1">{milestone.description}</div>
                  <div className="text-xs text-gray-500 mt-2">
                    {milestone.daysRequired} zile necesare
                  </div>
                  {isUnlocked && (
                    <div className="mt-2">
                      <span className="inline-block px-2 py-1 bg-yellow-100 text-yellow-700 text-xs font-medium rounded-full">
                        Deblocat
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

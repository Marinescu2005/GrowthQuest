import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Lock } from "lucide-react";

interface CardsTabProps {
  userId: number;
}

const rarityColors = {
  common: "from-gray-500 to-gray-700",
  rare: "from-blue-500 to-blue-700",
  epic: "from-purple-600 to-purple-800",
  legendary: "from-yellow-500 to-orange-600",
};

const rarityTextColors = {
  common: "text-gray-400",
  rare: "text-blue-400",
  epic: "text-purple-400",
  legendary: "text-yellow-400",
};

const getCardIcon = (icon: string) => {
  // This would normally be a proper icon mapping
  return icon;
};

export default function CardsTab({ userId }: CardsTabProps) {
  const [activeFilter, setActiveFilter] = useState("all");

  const { data: cardsData, isLoading } = useQuery({
    queryKey: [`/api/profile/${userId}/cards`],
  });

  if (isLoading) {
    return (
      <div className="text-center py-8">
        <div className="text-gray-600">Se încarcă colecția de cărți...</div>
      </div>
    );
  }

  const { unlocked = [], locked = [] } = cardsData || {};
  const allCards = [...unlocked, ...locked];

  const filteredCards = allCards.filter((cardItem: any) => {
    if (activeFilter === "all") return true;
    if (cardItem.card) {
      return cardItem.card.rarity === activeFilter;
    }
    return false;
  });

  const filters = [
    { label: "Toate Cărțile", value: "all" },
    { label: "Comune", value: "common" },
    { label: "Rare", value: "rare" },
    { label: "Epice", value: "epic" },
    { label: "Legendare", value: "legendary" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Colecția Ta de Cărți</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-6">Explorează și administrează cărțile tale colecționate</p>
      </div>

      <div className="flex flex-wrap gap-2 mb-6">
        {filters.map((filter) => (
          <Button
            key={filter.value}
            variant={activeFilter === filter.value ? "default" : "outline"}
            onClick={() => setActiveFilter(filter.value)}
            size="sm"
            className={
              activeFilter === filter.value
                ? "bg-purple-500 text-white hover:bg-purple-600"
                : "bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
            }
          >
            {filter.label}
          </Button>
        ))}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {filteredCards.map((cardItem: any, index: number) => {
          const card = cardItem.card;
          const isLocked = cardItem.isLocked;

          if (!card) return null;

          return (
            <div
              key={card.id || index}
              className={`bg-white rounded-lg p-4 border-2 shadow-sm hover:shadow-md transition-all duration-200 ${
                isLocked 
                  ? "border-gray-200 opacity-60" 
                  : card.rarity === "legendary" 
                    ? "border-yellow-300 bg-gradient-to-br from-yellow-50 to-orange-50"
                    : card.rarity === "epic"
                    ? "border-purple-300 bg-gradient-to-br from-purple-50 to-purple-100"
                    : card.rarity === "rare"
                    ? "border-blue-300 bg-gradient-to-br from-blue-50 to-blue-100"
                    : "border-gray-300 bg-gradient-to-br from-gray-50 to-gray-100"
              } ${!isLocked ? "hover:scale-105" : ""}`}
            >
              <div className="text-center">
                <div className="relative mb-3">
                  <div
                    className={`w-12 h-12 rounded-lg mx-auto flex items-center justify-center ${
                      isLocked 
                        ? "bg-gray-200" 
                        : card.rarity === "legendary"
                        ? "bg-gradient-to-br from-yellow-400 to-orange-500"
                        : card.rarity === "epic"
                        ? "bg-gradient-to-br from-purple-400 to-purple-600"
                        : card.rarity === "rare"
                        ? "bg-gradient-to-br from-blue-400 to-blue-600"
                        : "bg-gradient-to-br from-gray-400 to-gray-600"
                    }`}
                  >
                    {isLocked ? (
                      <Lock className="w-5 h-5 text-gray-400" />
                    ) : (
                      <div className="text-lg text-white">
                        {getCardIcon(card.icon) === "dragon" && "🐉"}
                        {getCardIcon(card.icon) === "magic" && "✨"}
                        {getCardIcon(card.icon) === "sword" && "⚔️"}
                        {!["dragon", "magic", "sword"].includes(getCardIcon(card.icon)) && "🎴"}
                      </div>
                    )}
                  </div>
                  {!isLocked && (
                    <div
                      className={`absolute -top-1 -right-1 w-4 h-4 rounded-full text-xs flex items-center justify-center text-white font-bold ${
                        card.rarity === "legendary"
                          ? "bg-yellow-500"
                          : card.rarity === "epic"
                          ? "bg-purple-500"
                          : card.rarity === "rare"
                          ? "bg-blue-500"
                          : "bg-gray-500"
                      }`}
                    >
                      {card.rarity === "legendary" ? "L" : card.rarity === "epic" ? "E" : card.rarity === "rare" ? "R" : "C"}
                    </div>
                  )}
                </div>
                
                <h4 className={`text-sm font-semibold mb-1 ${isLocked ? "text-gray-400" : "text-gray-900"}`}>
                  {isLocked ? "???" : card.name}
                </h4>
                <p className={`text-xs ${isLocked ? "text-gray-400" : "text-gray-600"}`}>
                  {isLocked ? card.unlockRequirement : card.description}
                </p>
                
                {!isLocked && (
                  <div className="mt-2">
                    <span
                      className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${
                        card.rarity === "legendary"
                          ? "bg-yellow-100 text-yellow-700"
                          : card.rarity === "epic"
                          ? "bg-purple-100 text-purple-700"
                          : card.rarity === "rare"
                          ? "bg-blue-100 text-blue-700"
                          : "bg-gray-100 text-gray-700"
                      }`}
                    >
                      {card.rarity === "legendary" ? "Legendară" : card.rarity === "epic" ? "Epică" : card.rarity === "rare" ? "Rară" : "Comună"}
                    </span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {filteredCards.length === 0 && (
        <div className="text-center py-12">
          <div className="text-gray-500 text-lg mb-2">Nu s-au găsit cărți</div>
          <div className="text-gray-400 text-sm">
            {activeFilter === "all" ? "Începe-ți colecția completând provocări!" : `Nu există cărți ${activeFilter}`}
          </div>
        </div>
      )}
    </div>
  );
}

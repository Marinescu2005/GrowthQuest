import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { User } from "shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Palette, Monitor, Eye, Sparkles, Save, User as UserIcon, Edit3, Crown, Star, Shield, Gem } from "lucide-react";

interface CustomizationTabProps {
  user: {
    id: number;
    name: string;
    username: string;
    avatarFrame: string;
    background: string;
    theme: string;
    animationLevel: string;
    showParticleEffects: boolean;
  };
}

export default function CustomizationTab({ user }: CustomizationTabProps) {
  const [localSettings, setLocalSettings] = useState({
    name: user.name,
    username: user.username,
    avatarFrame: user.avatarFrame,
    background: user.background,
    theme: user.theme,
    animationLevel: user.animationLevel,
    showParticleEffects: user.showParticleEffects,
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch available profile icons from cards collection
  const { data: availableIcons, isLoading: iconsLoading } = useQuery({
    queryKey: [`/api/profile/${user.id}/cards`],
  });

  const updateMutation = useMutation({
    mutationFn: (updates: Partial<User>) =>
      apiRequest(`/api/profile/${user.id}`, {
        method: "PATCH",
        body: JSON.stringify(updates),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/profile/${user.id}`] });
      toast({
        title: "Profil actualizat",
        description: "Setările tale au fost salvate cu succes.",
      });
    },
    onError: () => {
      toast({
        title: "Eroare",
        description: "Nu s-au putut salva schimbările. Încearcă din nou.",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    updateMutation.mutate(localSettings);
  };

  // Process available icons from cards collection
  const { unlocked: unlockedCards = [] } = availableIcons || {};
  
  const availableProfileIcons = [
    { id: "user", icon: UserIcon, name: "Utilizator Standard", rarity: "common", unlocked: true, source: "default" },
    { id: "crown", icon: Crown, name: "Coroană Regală", rarity: "legendary", unlocked: true, source: "achievement" },
    { id: "star", icon: Star, name: "Steaua Progresului", rarity: "rare", unlocked: true, source: "progress" },
    { id: "shield", icon: Shield, name: "Scut Protector", rarity: "epic", unlocked: false, source: "card" },
    { id: "gem", icon: Gem, name: "Gemă Prețioasă", rarity: "legendary", unlocked: false, source: "card" },
    // Add icons from unlocked cards
    ...unlockedCards.map((cardItem: any) => ({
      id: `card-${cardItem.card.id}`,
      icon: Star, // Would map to proper icon based on card
      name: cardItem.card.name,
      rarity: cardItem.card.rarity,
      unlocked: true,
      source: "card"
    }))
  ];

  const rarityColors = {
    common: "bg-gray-100 text-gray-600 border-gray-200",
    rare: "bg-blue-100 text-blue-600 border-blue-200",
    epic: "bg-purple-100 text-purple-600 border-purple-200",
    legendary: "bg-yellow-100 text-yellow-600 border-yellow-200",
  };

  const backgroundOptions = [
    { value: "emerald-blue", label: "Emerald Professional", gradient: "from-emerald-500 to-blue-600", pattern: "clean" },
    { value: "purple-blue", label: "Violet Elegant", gradient: "from-purple-600 to-blue-600", pattern: "gradient" },
    { value: "green-teal", label: "Verde Profesional", gradient: "from-green-600 to-teal-600", pattern: "corporate" },
    { value: "orange-warm", label: "Portocaliu Cald", gradient: "from-orange-600 to-red-600", pattern: "energetic" },
    { value: "pink-soft", label: "Roz Subtil", gradient: "from-pink-500 to-purple-500", pattern: "soft" },
    { value: "blue-clean", label: "Albastru Curat", gradient: "from-blue-500 to-cyan-500", pattern: "minimal" },
    { value: "dark-mode", label: "Mod Întunecat", gradient: "from-gray-800 to-gray-900", pattern: "dark" },
    { value: "nature", label: "Natură", gradient: "from-green-400 to-emerald-600", pattern: "organic" },
    { value: "sunset", label: "Apus", gradient: "from-orange-400 to-pink-600", pattern: "warm" },
    { value: "ocean", label: "Ocean", gradient: "from-cyan-400 to-blue-700", pattern: "deep" },
  ];

  const themePresets = [
    { value: "professional", label: "Profesional", description: "Design curat pentru mediul de lucru" },
    { value: "creative", label: "Creativ", description: "Culori vibrante și elemente artistice" },
    { value: "minimal", label: "Minimalist", description: "Interfață simplă și focusată" },
    { value: "gaming", label: "Gaming", description: "Elemente dinamice și efecte vizuale" },
    { value: "academic", label: "Academic", description: "Stil profesional pentru studiu" },
  ];

  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h3 className="text-lg font-medium text-gray-800 mb-2">Customizare Profil</h3>
        <p className="text-gray-600">Personalizează identitatea și aspectul profilului tău</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Profile Information */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-4">
            <CardTitle className="text-base flex items-center gap-2">
              <Edit3 className="w-4 h-4" />
              Informații Profil
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <Label htmlFor="display-name">Nume Afișat</Label>
                <Input
                  id="display-name"
                  value={localSettings.name}
                  onChange={(e) => setLocalSettings(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Numele tău complet"
                  className="bg-white/70 border-gray-200 focus:border-emerald-500"
                />
                <p className="text-xs text-gray-500">Numele care apare pe profil și în aplicații</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="username">Nume Utilizator</Label>
                <Input
                  id="username"
                  value={localSettings.username}
                  onChange={(e) => setLocalSettings(prev => ({ ...prev, username: e.target.value }))}
                  placeholder="username"
                  className="bg-white/70 border-gray-200 focus:border-emerald-500"
                />
                <p className="text-xs text-gray-500">Identificator unique pentru cont</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status Profil</Label>
                <Select 
                  value={localSettings.status || "active"} 
                  onValueChange={(value) => setLocalSettings(prev => ({ ...prev, status: value }))}
                >
                  <SelectTrigger className="bg-white/70 border-gray-200">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">🟢 Activ</SelectItem>
                    <SelectItem value="busy">🟡 Ocupat</SelectItem>
                    <SelectItem value="away">🔴 Absent</SelectItem>
                    <SelectItem value="focus">🔵 Concentrat</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-500">Starea vizibilă pentru alții</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Profile Icon Selection */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-4">
            <CardTitle className="text-base flex items-center gap-2">
              <UserIcon className="w-4 h-4" />
              Iconiță Profil & Avatar
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Current Avatar Preview */}
            <div className="flex items-center justify-center p-6 bg-gradient-to-r from-emerald-50 to-blue-50 rounded-xl border border-emerald-100">
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg">
                  <UserIcon className="w-10 h-10 text-white" />
                </div>
                <p className="text-sm font-medium text-gray-800">Preview Avatar Curent</p>
                <p className="text-xs text-gray-600">{user.name}</p>
              </div>
            </div>

            {/* Icon Categories */}
            <div className="space-y-4">
              <div>
                <h4 className="font-medium text-gray-800 mb-3 flex items-center gap-2">
                  <Star className="w-4 h-4 text-yellow-500" />
                  Iconițe Disponibile
                </h4>
                <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                  {availableProfileIcons.map((iconOption) => {
                    const IconComponent = iconOption.icon;
                    const isSelected = localSettings.avatarFrame === iconOption.id;
                    const isUnlocked = iconOption.unlocked;
                    
                    return (
                      <button
                        key={iconOption.id}
                        onClick={() => isUnlocked && setLocalSettings(prev => ({ ...prev, avatarFrame: iconOption.id }))}
                        disabled={!isUnlocked}
                        className={`p-3 rounded-xl border-2 transition-all relative group ${
                          isSelected && isUnlocked
                            ? 'border-emerald-500 bg-emerald-50 shadow-lg'
                            : isUnlocked 
                            ? 'border-gray-200 hover:border-emerald-300 bg-white/70 hover:shadow-md'
                            : 'border-gray-100 bg-gray-50 opacity-60 cursor-not-allowed'
                        }`}
                        title={iconOption.name}
                      >
                        <div className="flex flex-col items-center space-y-2">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                            isUnlocked ? 'bg-gradient-to-br from-emerald-500 to-blue-600' : 'bg-gray-300'
                          }`}>
                            <IconComponent className="w-4 h-4 text-white" />
                          </div>
                          <Badge className={`text-xs ${rarityColors[iconOption.rarity as keyof typeof rarityColors]}`}>
                            {iconOption.source === 'card' ? '🎴' : iconOption.source === 'achievement' ? '🏆' : '⭐'}
                          </Badge>
                        </div>
                        {!isUnlocked && (
                          <div className="absolute inset-0 flex items-center justify-center bg-white/90 rounded-xl">
                            <div className="text-xs text-gray-500 font-medium">🔒</div>
                          </div>
                        )}
                        {isSelected && (
                          <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full flex items-center justify-center">
                            <div className="w-2 h-2 bg-white rounded-full"></div>
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="text-xs text-gray-500 p-4 bg-gradient-to-r from-blue-50 to-emerald-50 rounded-xl border border-blue-100">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-4 h-4 bg-blue-500 rounded flex items-center justify-center">
                    <div className="text-white text-xs">💡</div>
                  </div>
                  <span className="font-medium">Cum să deblochezi iconițe noi:</span>
                </div>
                <ul className="space-y-1 ml-6">
                  <li>🎴 Cărți rare din colecția ta</li>
                  <li>🏆 Completarea de realizări speciale</li>
                  <li>⭐ Progres în aplicațiile TranscendUp</li>
                  <li>🎯 Milestone-uri de activitate</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Background & Theme Customization */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-4">
            <CardTitle className="text-base flex items-center gap-2">
              <Palette className="w-4 h-4" />
              Temă & Personalizare Vizuală
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Theme Presets */}
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium">Preset-uri de Temă</Label>
                <p className="text-xs text-gray-500 mb-3">Selectează un stil predefinit pentru interfață</p>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {themePresets.map((preset) => (
                    <button
                      key={preset.value}
                      onClick={() => setLocalSettings(prev => ({ ...prev, themePreset: preset.value }))}
                      className={`p-4 rounded-xl border-2 transition-all text-left ${
                        localSettings.themePreset === preset.value
                          ? 'border-emerald-500 bg-emerald-50'
                          : 'border-gray-200 hover:border-emerald-300 bg-white/70'
                      }`}
                    >
                      <div className="font-medium text-gray-800 text-sm">{preset.label}</div>
                      <div className="text-xs text-gray-600 mt-1">{preset.description}</div>
                    </button>
                  ))}
                </div>
              </div>

              <Separator />

              {/* Background Options */}
              <div>
                <Label className="text-sm font-medium">Fundaluri Disponibile</Label>
                <p className="text-xs text-gray-500 mb-3">Personalizează aspectul general al platformei</p>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                  {backgroundOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => setLocalSettings(prev => ({ ...prev, background: option.value }))}
                      className={`p-3 rounded-xl border-2 transition-all group relative ${
                        localSettings.background === option.value
                          ? 'border-emerald-500 bg-emerald-50 shadow-lg'
                          : 'border-gray-200 hover:border-emerald-300 bg-white/70'
                      }`}
                    >
                      <div className="space-y-2">
                        <div className={`w-full h-8 rounded-lg bg-gradient-to-r ${option.gradient} shadow-sm`} />
                        <div className="text-xs font-medium text-gray-800 text-center">{option.label}</div>
                        <div className="text-xs text-gray-500 text-center">{option.pattern}</div>
                      </div>
                      {localSettings.background === option.value && (
                        <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full flex items-center justify-center">
                          <div className="w-2 h-2 bg-white rounded-full"></div>
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              <Separator />

              {/* Advanced Theme Settings */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <Label htmlFor="theme-select">Mod Afișare</Label>
                  <Select 
                    value={localSettings.theme} 
                    onValueChange={(value) => setLocalSettings(prev => ({ ...prev, theme: value }))}
                  >
                    <SelectTrigger id="theme-select" className="bg-white/70 border-gray-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">☀️ Luminos</SelectItem>
                      <SelectItem value="dark">🌙 Întunecat</SelectItem>
                      <SelectItem value="auto">🔄 Automat (Sistem)</SelectItem>
                      <SelectItem value="adaptive">🎨 Adaptiv</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="accent-color">Culoare Accent</Label>
                  <Select 
                    value={localSettings.accentColor || "emerald"} 
                    onValueChange={(value) => setLocalSettings(prev => ({ ...prev, accentColor: value }))}
                  >
                    <SelectTrigger className="bg-white/70 border-gray-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="emerald">🟢 Emerald</SelectItem>
                      <SelectItem value="blue">🔵 Blue</SelectItem>
                      <SelectItem value="purple">🟣 Purple</SelectItem>
                      <SelectItem value="orange">🟠 Orange</SelectItem>
                      <SelectItem value="pink">🩷 Pink</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Advanced Settings & Preferences */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-4">
            <CardTitle className="text-base flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              Setări Avansate & Preferințe
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Animation & Performance */}
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium">Performanță & Animații</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
                  <div className="space-y-3">
                    <Label htmlFor="animation-select">Nivel Animații</Label>
                    <Select 
                      value={localSettings.animationLevel} 
                      onValueChange={(value) => setLocalSettings(prev => ({ ...prev, animationLevel: value }))}
                    >
                      <SelectTrigger id="animation-select" className="bg-white/70 border-gray-200">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">🚫 Dezactivate</SelectItem>
                        <SelectItem value="reduced">⚡ Minimale</SelectItem>
                        <SelectItem value="normal">✨ Standard</SelectItem>
                        <SelectItem value="full">🎭 Complete</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="performance-mode">Mod Performanță</Label>
                    <Select 
                      value={localSettings.performanceMode || "balanced"} 
                      onValueChange={(value) => setLocalSettings(prev => ({ ...prev, performanceMode: value }))}
                    >
                      <SelectTrigger className="bg-white/70 border-gray-200">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="performance">🚀 Performanță Maximă</SelectItem>
                        <SelectItem value="balanced">⚖️ Echilibrat</SelectItem>
                        <SelectItem value="quality">🎨 Calitate Maximă</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Visual Effects */}
              <div>
                <Label className="text-sm font-medium mb-3 block">Efecte Vizuale</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl bg-white/70">
                    <div className="space-y-1">
                      <Label htmlFor="particle-effects" className="text-sm">Efecte Particule</Label>
                      <p className="text-xs text-gray-600">Particule și tranziții</p>
                    </div>
                    <Switch
                      id="particle-effects"
                      checked={localSettings.showParticleEffects}
                      onCheckedChange={(checked) => 
                        setLocalSettings(prev => ({ ...prev, showParticleEffects: checked }))
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl bg-white/70">
                    <div className="space-y-1">
                      <Label htmlFor="blur-effects" className="text-sm">Efecte Blur</Label>
                      <p className="text-xs text-gray-600">Backdrop blur pe carduri</p>
                    </div>
                    <Switch
                      id="blur-effects"
                      checked={localSettings.blurEffects !== false}
                      onCheckedChange={(checked) => 
                        setLocalSettings(prev => ({ ...prev, blurEffects: checked }))
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl bg-white/70">
                    <div className="space-y-1">
                      <Label htmlFor="smooth-scrolling" className="text-sm">Scroll Fluid</Label>
                      <p className="text-xs text-gray-600">Navigare mai fluidă</p>
                    </div>
                    <Switch
                      id="smooth-scrolling"
                      checked={localSettings.smoothScrolling !== false}
                      onCheckedChange={(checked) => 
                        setLocalSettings(prev => ({ ...prev, smoothScrolling: checked }))
                      }
                    />
                  </div>
                </div>
              </div>

              <Separator />

              {/* Notification & Privacy */}
              <div>
                <Label className="text-sm font-medium mb-3 block">Notificări & Confidențialitate</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl bg-white/70">
                    <div className="space-y-1">
                      <Label htmlFor="progress-notifications" className="text-sm">Notificări Progres</Label>
                      <p className="text-xs text-gray-600">Alertă la milestone-uri</p>
                    </div>
                    <Switch
                      id="progress-notifications"
                      checked={localSettings.progressNotifications !== false}
                      onCheckedChange={(checked) => 
                        setLocalSettings(prev => ({ ...prev, progressNotifications: checked }))
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl bg-white/70">
                    <div className="space-y-1">
                      <Label htmlFor="public-profile" className="text-sm">Profil Public</Label>
                      <p className="text-xs text-gray-600">Vizibilitate pentru alții</p>
                    </div>
                    <Switch
                      id="public-profile"
                      checked={localSettings.publicProfile !== false}
                      onCheckedChange={(checked) => 
                        setLocalSettings(prev => ({ ...prev, publicProfile: checked }))
                      }
                    />
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-between items-center pt-8 border-t border-gray-200">
        <div className="flex gap-3">
          <Button 
            variant="outline"
            onClick={() => setLocalSettings({
              name: user.name,
              username: user.username,
              avatarFrame: user.avatarFrame,
              background: user.background,
              theme: user.theme,
              animationLevel: user.animationLevel,
              showParticleEffects: user.showParticleEffects,
            })}
            className="px-6 py-2 border-gray-300 text-gray-700 hover:bg-gray-50"
          >
            Resetează la Implicit
          </Button>
          
          <Button 
            variant="outline"
            onClick={() => {
              const previewData = { ...localSettings };
              // Apply preview temporarily
              console.log("Preview mode:", previewData);
            }}
            className="px-6 py-2 border-emerald-300 text-emerald-700 hover:bg-emerald-50"
          >
            <Eye className="w-4 h-4 mr-2" />
            Preview
          </Button>
        </div>

        <Button 
          onClick={handleSave} 
          disabled={updateMutation.isPending}
          className="px-8 py-3 bg-gradient-to-r from-emerald-600 to-blue-600 hover:from-emerald-700 hover:to-blue-700 text-white font-medium rounded-xl shadow-lg hover:shadow-xl transition-all"
        >
          <Save className="w-4 h-4 mr-2" />
          {updateMutation.isPending ? "Se aplică..." : "Salvează Personalizarea"}
        </Button>
      </div>
    </div>
  );
}

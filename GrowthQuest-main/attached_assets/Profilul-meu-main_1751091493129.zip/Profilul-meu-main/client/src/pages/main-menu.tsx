import { Link } from "wouter";
import { User, Settings, BookOpen, Calendar, Map, Users, FileText, Trophy } from "lucide-react";

export default function MainMenu() {
  const menuItems = [
    {
      title: "Profilul Meu",
      description: "Vezi progresul și customizează-ți avatarul",
      icon: User,
      href: "/profile",
      color: "from-purple-500 to-blue-500"
    },
    {
      title: "Setări",
      description: "Configurează preferințele aplicației",
      icon: Settings,
      href: "/settings",
      color: "from-gray-500 to-gray-600"
    },
    {
      title: "Istoric",
      description: "Urmărește-ți activitatea și progresul",
      icon: Calendar,
      href: "/history",
      color: "from-green-500 to-emerald-500"
    },
    {
      title: "Jurnal",
      description: "Scrie și reflectează asupra zilei tale",
      icon: FileText,
      href: "/journal",
      color: "from-orange-500 to-red-500"
    },
    {
      title: "Harta",
      description: "Explorează și descoperă noi provocări",
      icon: Map,
      href: "/map",
      color: "from-blue-500 to-cyan-500"
    },
    {
      title: "Resurse",
      description: "Ghiduri și materiale de învățare",
      icon: BookOpen,
      href: "/resources",
      color: "from-indigo-500 to-purple-500"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">TranscendUp</h1>
              <p className="text-gray-600 dark:text-gray-400 mt-1">Platforma ta de dezvoltare personală</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center">
              <User className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Main Menu */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Meniu Principal</h2>
          <p className="text-gray-600 dark:text-gray-400">Alege o secțiune pentru a continua călătoria ta</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {menuItems.map((item, index) => {
            const IconComponent = item.icon;
            return (
              <Link key={index} href={item.href}>
                <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer border border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600">
                  <div className="flex items-start space-x-4">
                    <div className={`w-12 h-12 bg-gradient-to-br ${item.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">
                        {item.title}
                      </h3>
                      <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">
                        {item.description}
                      </p>
                    </div>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import ProfileHeader from "@/components/ProfileHeader";
import AchievementsTab from "@/components/AchievementsTab";
import CardsTab from "@/components/CardsTab";
import StreakTab from "@/components/StreakTab";
import CustomizationTab from "@/components/CustomizationTab";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, CreditCard, Flame, Palette, User, Star, Calendar, Settings, MapPin, BarChart3, Target } from "lucide-react";

export default function Profile() {
  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/profile/1"],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-gray-600 text-lg">Se încarcă profilul...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-red-500 text-lg">Eroare la încărcarea profilului</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50">
      <div className="max-w-6xl mx-auto p-6 space-y-6">
        {/* Header Section */}
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
                <User className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-semibold text-gray-800">{user.name}</h1>
                <p className="text-gray-600">Dashboard Personal TranscendUp</p>
              </div>
            </div>
            
            <div className="text-right">
              <div className="text-sm text-gray-600 mb-1">Progres Regiuni</div>
              <div className="text-2xl font-bold text-gray-800">{user.level}/20</div>
              <div className="text-xs text-emerald-600 font-medium">60% complet</div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
            <div 
              className="bg-gradient-to-r from-emerald-500 to-blue-600 h-2 rounded-full transition-all duration-700"
              style={{ width: `${(user.xp / user.maxXp) * 100}%` }}
            />
          </div>
          
          <div className="flex justify-between text-sm text-gray-600">
            <span>Etapa {user.level - 1}</span>
            <span>{user.xp.toLocaleString()} / {user.maxXp.toLocaleString()} XP</span>
            <span>Etapa {user.level + 1}</span>
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-4 border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                <BarChart3 className="w-4 h-4 text-white" />
              </div>
              <span className="text-xs text-gray-500">HistoryTracker</span>
            </div>
            <div className="text-xl font-bold text-gray-800">247</div>
            <div className="text-xs text-gray-600">Zile Active</div>
          </div>

          <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-4 border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-lg flex items-center justify-center">
                <MapPin className="w-4 h-4 text-white" />
              </div>
              <span className="text-xs text-gray-500">TerrainTreasure</span>
            </div>
            <div className="text-xl font-bold text-gray-800">37%</div>
            <div className="text-xs text-gray-600">Progres Hartă</div>
          </div>

          <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-4 border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg flex items-center justify-center">
                <Target className="w-4 h-4 text-white" />
              </div>
              <span className="text-xs text-gray-500">Obiective</span>
            </div>
            <div className="text-xl font-bold text-gray-800">1,234</div>
            <div className="text-xs text-gray-600">Finalizate</div>
          </div>

          <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-4 border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
                <Flame className="w-4 h-4 text-white" />
              </div>
              <span className="text-xs text-gray-500">Consistență</span>
            </div>
            <div className="text-xl font-bold text-gray-800">{user.currentStreak}</div>
            <div className="text-xs text-gray-600">Zile consecutive</div>
          </div>
        </div>

        {/* Main Content Tabs */}
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-5 bg-gray-50/50 border-b border-gray-200 rounded-none p-2">
              <TabsTrigger 
                value="overview" 
                className="rounded-xl data-[state=active]:bg-white data-[state=active]:shadow-sm py-3 px-4 text-gray-600 data-[state=active]:text-gray-900 font-medium text-sm transition-all"
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Sumar
              </TabsTrigger>
              <TabsTrigger 
                value="achievements" 
                className="rounded-xl data-[state=active]:bg-white data-[state=active]:shadow-sm py-3 px-4 text-gray-600 data-[state=active]:text-gray-900 font-medium text-sm transition-all"
              >
                <Target className="w-4 h-4 mr-2" />
                Obiective
              </TabsTrigger>
              <TabsTrigger 
                value="collection" 
                className="rounded-xl data-[state=active]:bg-white data-[state=active]:shadow-sm py-3 px-4 text-gray-600 data-[state=active]:text-gray-900 font-medium text-sm transition-all"
              >
                <Star className="w-4 h-4 mr-2" />
                Resurse
              </TabsTrigger>
              <TabsTrigger 
                value="activity" 
                className="rounded-xl data-[state=active]:bg-white data-[state=active]:shadow-sm py-3 px-4 text-gray-600 data-[state=active]:text-gray-900 font-medium text-sm transition-all"
              >
                <Calendar className="w-4 h-4 mr-2" />
                Progres
              </TabsTrigger>
              <TabsTrigger 
                value="customize" 
                className="rounded-xl data-[state=active]:bg-white data-[state=active]:shadow-sm py-3 px-4 text-gray-600 data-[state=active]:text-gray-900 font-medium text-sm transition-all"
              >
                <Palette className="w-4 h-4 mr-2" />
                Profil
              </TabsTrigger>
            </TabsList>

            <div className="p-8">
              <TabsContent value="overview" className="mt-0">
                <div className="space-y-8">
                  {/* Progress Overview */}
                  <div className="bg-gradient-to-r from-emerald-50 to-blue-50 rounded-2xl p-6 border border-emerald-100">
                    <div className="flex items-center justify-between mb-6">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-800 mb-1">Progres General Platformă</h3>
                        <p className="text-gray-600 text-sm">Performanța ta în ecosistemul TranscendUp</p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-emerald-600">60%</div>
                        <div className="text-xs text-gray-600">Finalizat</div>
                      </div>
                    </div>
                    
                    {/* Progress Grid */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="bg-white/70 rounded-xl p-4 border border-white/50">
                        <div className="text-lg font-bold text-blue-600 mb-1">247</div>
                        <div className="text-xs text-gray-600 mb-2">Zile Active</div>
                        <div className="w-full bg-blue-100 rounded-full h-2">
                          <div className="bg-blue-500 h-2 rounded-full" style={{ width: '85%' }}></div>
                        </div>
                      </div>
                      
                      <div className="bg-white/70 rounded-xl p-4 border border-white/50">
                        <div className="text-lg font-bold text-emerald-600 mb-1">37</div>
                        <div className="text-xs text-gray-600 mb-2">Progres Hartă</div>
                        <div className="w-full bg-emerald-100 rounded-full h-2">
                          <div className="bg-emerald-500 h-2 rounded-full" style={{ width: '37%' }}></div>
                        </div>
                      </div>
                      
                      <div className="bg-white/70 rounded-xl p-4 border border-white/50">
                        <div className="text-lg font-bold text-purple-600 mb-1">1,234</div>
                        <div className="text-xs text-gray-600 mb-2">Obiective Complete</div>
                        <div className="w-full bg-purple-100 rounded-full h-2">
                          <div className="bg-purple-500 h-2 rounded-full" style={{ width: '68%' }}></div>
                        </div>
                      </div>
                      
                      <div className="bg-white/70 rounded-xl p-4 border border-white/50">
                        <div className="text-lg font-bold text-orange-600 mb-1">{user.currentStreak}</div>
                        <div className="text-xs text-gray-600 mb-2">Streak Actual</div>
                        <div className="w-full bg-orange-100 rounded-full h-2">
                          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '76%' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Application Details */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-white/60 rounded-2xl p-6 border border-gray-100">
                      <div className="flex items-center mb-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mr-4">
                          <BarChart3 className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h4 className="font-semibold text-gray-800">HistoryTracker</h4>
                          <p className="text-sm text-gray-600">Analiza & Statistici</p>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Zile Active</span>
                          <span className="font-semibold text-blue-600">247</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Obiective Complete</span>
                          <span className="font-semibold text-purple-600">1,234</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Etapa Curentă</span>
                          <span className="font-semibold text-emerald-600">37</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white/60 rounded-2xl p-6 border border-gray-100">
                      <div className="flex items-center mb-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl flex items-center justify-center mr-4">
                          <MapPin className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h4 className="font-semibold text-gray-800">TerrainTreasure</h4>
                          <p className="text-sm text-gray-600">Navigare & Explorare</p>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Progres Navigare</span>
                          <span className="font-semibold text-emerald-600">37%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">XP Câștigat</span>
                          <span className="font-semibold text-orange-600">37</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Resurse Descoperite</span>
                          <span className="font-semibold text-purple-600">0</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="achievements" className="mt-0">
                <AchievementsTab userId={user.id} />
              </TabsContent>

              <TabsContent value="collection" className="mt-0">
                <CardsTab userId={user.id} />
              </TabsContent>

              <TabsContent value="activity" className="mt-0">
                <StreakTab userId={user.id} />
              </TabsContent>

              <TabsContent value="customize" className="mt-0">
                <CustomizationTab user={user} />
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

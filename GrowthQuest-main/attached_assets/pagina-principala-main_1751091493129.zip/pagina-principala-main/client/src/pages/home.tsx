import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ProgressCard } from "@/components/ui/progress-card";
import { useToast } from "@/hooks/use-toast";
import { 
  Mountain, 
  User, 
  Trophy, 
  Flame, 
  Gem, 
  TrendingUp, 
  Star, 
  Play, 
  BarChart3, 
  Book, 
  Award,
  Check,
  Medal,
  Crown
} from "lucide-react";

interface DashboardData {
  user: {
    id: number;
    displayName: string;
    totalXP: number;
    currentLevel: number;
    currentStreak: number;
    completedActivities: number;
  };
  level: {
    current: number;
    xpForCurrentLevel: number;
    xpNeededForNextLevel: number;
    progressPercent: number;
  };
  streak: {
    current: number;
    longest: number;
    data: Array<{
      date: string;
      hasActivity: boolean;
    }>;
  };
  achievements: Array<{
    type: string;
    unlockedAt: string;
  }>;
  stats: {
    totalActivities: number;
    totalXP: number;
    currentStreak: number;
  };
}

export default function Home() {
  const { toast } = useToast();
  const userId = 1; // Demo user ID

  const { data: dashboardData, isLoading } = useQuery<DashboardData>({
    queryKey: [`/api/user/${userId}/dashboard`],
  });

  const recordActivityMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/user/${userId}/activity`, {
        xpEarned: 10,
        activitiesCompleted: 1,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/user/${userId}/dashboard`] });
      toast({
        title: "Activitate completă!",
        description: "Ai câștigat 10 XP!",
      });
    },
  });

  const handleStartActivity = () => {
    recordActivityMutation.mutate();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
            <Mountain className="text-white text-xl" />
          </div>
          <p className="text-gray-600">Se încarcă...</p>
        </div>
      </div>
    );
  }

  if (!dashboardData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-600">Nu s-au putut încărca datele</p>
      </div>
    );
  }

  const getAchievementIcon = (type: string) => {
    switch (type) {
      case 'medal': return <Medal className="text-xs" />;
      case 'crown': return <Crown className="text-xs" />;
      default: return <Star className="text-xs" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-lg flex items-center justify-center">
                <Mountain className="text-white text-sm" />
              </div>
              <h1 className="text-xl font-bold text-gray-900">TranscendUp</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-r from-emerald-400 to-green-500 rounded-full flex items-center justify-center text-white font-semibold hover:shadow-lg transition-all duration-200 cursor-pointer">
                <User className="h-4 w-4" />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-emerald-400 to-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <User className="text-white text-xl" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">
              Bun venit, {dashboardData.user.displayName}!
            </h2>
            <p className="text-gray-600">
              Explorează-ți progresul în aventura TranscendUp
            </p>
          </div>
        </div>

        {/* Progress Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {/* Level Card */}
          <ProgressCard className="bg-gradient-to-br from-emerald-400 to-emerald-500">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Trophy className="text-2xl opacity-90" />
                <span className="text-lg font-medium opacity-90">
                  Nivel {dashboardData.level.current}
                </span>
              </div>
            </div>
            
            <div className="text-4xl font-bold mb-2">{dashboardData.user.totalXP}</div>
            <div className="text-sm opacity-90 mb-4">XP total</div>
            
            <div className="text-xs opacity-75">
              {dashboardData.level.xpNeededForNextLevel} XP până la următorul nivel
            </div>
            <div className="w-full bg-white bg-opacity-20 rounded-full h-2 mt-2">
              <div 
                className="bg-white rounded-full h-2 transition-all duration-500" 
                style={{ width: `${dashboardData.level.progressPercent}%` }}
              />
            </div>
          </ProgressCard>

          {/* Streak Card */}
          <ProgressCard className="bg-gradient-to-br from-green-500 to-green-600">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Flame className="text-2xl opacity-90" />
                <span className="text-lg font-medium opacity-90">Streak</span>
              </div>
            </div>
            
            <div className="text-4xl font-bold mb-2">{dashboardData.streak.current} zile</div>
            <div className="text-sm opacity-90 mb-4">actual</div>
            
            <div className="text-xs opacity-75">Continuă să îți menții constanța!</div>
            <div className="flex space-x-1 mt-3">
              {dashboardData.streak.data.map((day, index) => (
                <div 
                  key={index}
                  className={`w-4 h-4 rounded-full ${
                    day.hasActivity ? 'bg-white' : 'bg-white bg-opacity-30'
                  }`} 
                />
              ))}
            </div>
          </ProgressCard>

          {/* Collection Card */}
          <ProgressCard className="bg-gradient-to-br from-lime-400 to-lime-500">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Gem className="text-2xl opacity-90" />
                <span className="text-lg font-medium opacity-90">Colecție</span>
              </div>
            </div>
            
            <div className="text-4xl font-bold mb-2">
              {dashboardData.achievements.length} Cărți
            </div>
            <div className="text-sm opacity-90 mb-4">complete</div>
            
            <div className="text-xs opacity-75">Realizează 3 activități</div>
            <div className="flex space-x-1 mt-3">
              {[...Array(3)].map((_, index) => (
                <div 
                  key={index}
                  className="w-6 h-6 bg-white bg-opacity-30 rounded-lg flex items-center justify-center"
                >
                  {dashboardData.achievements[index] && getAchievementIcon(dashboardData.achievements[index].type)}
                </div>
              ))}
            </div>
          </ProgressCard>
        </div>

        {/* Feature Cards Section */}
        <div className="grid grid-cols-1 gap-6 mb-8">
          {/* Activity Hub Card */}
          <Card className="p-6 hover:shadow-lg transition-all duration-300 border border-gray-100">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-emerald-100 to-emerald-200 rounded-xl flex items-center justify-center">
                <TrendingUp className="text-emerald-600 text-xl" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-900">Harta</h3>
                <p className="text-gray-600 text-sm">
                  Explorează nivelele și câștigă recompense
                </p>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <Button className="bg-emerald-600 text-white hover:bg-emerald-700">
                Disponibil
                <TrendingUp className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Acțiuni rapide</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <Button
              variant="ghost"
              onClick={handleStartActivity}
              disabled={recordActivityMutation.isPending}
              className="flex flex-col items-center space-y-2 p-4 h-auto hover:bg-emerald-50 group"
            >
              <div className="w-12 h-12 bg-gradient-to-r from-emerald-100 to-emerald-200 rounded-xl flex items-center justify-center group-hover:scale-105 transition-transform">
                <Play className="text-emerald-600 text-lg" />
              </div>
              <span className="text-sm font-medium text-gray-700">
                {recordActivityMutation.isPending ? "Se salvează..." : "Start activitate"}
              </span>
            </Button>
            
            <Button
              variant="ghost"
              className="flex flex-col items-center space-y-2 p-4 h-auto hover:bg-green-50 group"
            >
              <div className="w-12 h-12 bg-gradient-to-r from-green-100 to-green-200 rounded-xl flex items-center justify-center group-hover:scale-105 transition-transform">
                <BarChart3 className="text-green-600 text-lg" />
              </div>
              <span className="text-sm font-medium text-gray-700">Vezi progresul</span>
            </Button>
            
            <Button
              variant="ghost"
              className="flex flex-col items-center space-y-2 p-4 h-auto hover:bg-lime-50 group"
            >
              <div className="w-12 h-12 bg-gradient-to-r from-lime-100 to-lime-200 rounded-xl flex items-center justify-center group-hover:scale-105 transition-transform">
                <Book className="text-lime-600 text-lg" />
              </div>
              <span className="text-sm font-medium text-gray-700">Jurnal</span>
            </Button>

            <Button
              variant="ghost"
              onClick={() => window.location.href = '/guide'}
              className="flex flex-col items-center space-y-2 p-4 h-auto hover:bg-blue-50 group"
            >
              <div className="w-12 h-12 bg-gradient-to-r from-blue-100 to-blue-200 rounded-xl flex items-center justify-center group-hover:scale-105 transition-transform">
                <Book className="text-blue-600 text-lg" />
              </div>
              <span className="text-sm font-medium text-gray-700">Ghid de folosire</span>
            </Button>
          </div>
        </Card>
      </main>
    </div>
  );
}

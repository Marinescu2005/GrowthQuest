import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Mountain, 
  User, 
  Trophy, 
  Flame, 
  Gem, 
  Play, 
  BarChart3, 
  Book, 
  ArrowRight,
  CheckCircle,
  Settings
} from "lucide-react";

export default function Guide() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-lg flex items-center justify-center">
                <Mountain className="text-white text-sm" />
              </div>
              <h1 className="text-xl font-bold text-gray-900">TranscendUp</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-r from-emerald-400 to-green-500 rounded-full flex items-center justify-center text-white font-semibold hover:shadow-lg transition-all duration-200 cursor-pointer">
                <User className="h-4 w-4" />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="text-center mb-12">
          <div className="w-20 h-20 bg-gradient-to-r from-emerald-400 to-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <Book className="text-white text-2xl" />
          </div>
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Ghid de utilizare TranscendUp
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Începe aventura ta de dezvoltare personală cu TranscendUp. Acest ghid te va ajuta să înțelegi toate funcțiile aplicației.
          </p>
        </div>

        {/* Login Suggestion Card */}
        <Card className="p-6 mb-8 bg-gradient-to-r from-emerald-50 to-green-50 border-emerald-200">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center">
              <User className="text-white text-xl" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Loghează-te pentru a-ți salva progresul
              </h3>
              <p className="text-gray-700 mb-4">
                Pentru a păstra toate datele tale de progres, realizări și statistici în siguranță, îți recomandăm să te loghezi în aplicație.
              </p>
              <Button 
                className="bg-emerald-600 text-white hover:bg-emerald-700"
                onClick={() => window.location.href = '/api/login'}
              >
                Loghează-te acum
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </Card>

        {/* Guide Steps */}
        <div className="space-y-8">
          <h3 className="text-2xl font-bold text-gray-900 text-center mb-8">
            Cum să folosești TranscendUp
          </h3>

          {/* Step 1: Dashboard Overview */}
          <Card className="p-6">
            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-emerald-600 font-bold">1</span>
              </div>
              <div className="flex-1">
                <h4 className="text-xl font-semibold text-gray-900 mb-3">
                  Înțelege dashboard-ul tău
                </h4>
                <p className="text-gray-700 mb-4">
                  Dashboard-ul principal îți arată progresul în timp real cu trei carduri importante:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div className="bg-emerald-50 p-4 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Trophy className="text-emerald-600 text-lg" />
                      <span className="font-medium text-emerald-800">Nivel</span>
                    </div>
                    <p className="text-sm text-gray-700">
                      Vezi XP-ul total și progresul către următorul nivel
                    </p>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Flame className="text-green-600 text-lg" />
                      <span className="font-medium text-green-800">Streak</span>
                    </div>
                    <p className="text-sm text-gray-700">
                      Urmărește zilele consecutive de activitate
                    </p>
                  </div>
                  <div className="bg-lime-50 p-4 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Gem className="text-lime-600 text-lg" />
                      <span className="font-medium text-lime-800">Colecție</span>
                    </div>
                    <p className="text-sm text-gray-700">
                      Colectează realizări și cărți speciale
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Step 2: Start Activities */}
          <Card className="p-6">
            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-emerald-600 font-bold">2</span>
              </div>
              <div className="flex-1">
                <h4 className="text-xl font-semibold text-gray-900 mb-3">
                  Începe activități zilnice
                </h4>
                <p className="text-gray-700 mb-4">
                  Folosește butonul "Start activitate" pentru a câștiga XP și a menține streak-ul:
                </p>
                <div className="bg-gray-50 p-4 rounded-lg mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gradient-to-r from-emerald-100 to-emerald-200 rounded-xl flex items-center justify-center">
                      <Play className="text-emerald-600 text-lg" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">Start activitate</p>
                      <p className="text-sm text-gray-600">Câștigi 10 XP pentru fiecare activitate completă</p>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2 text-emerald-600">
                  <CheckCircle className="h-4 w-4" />
                  <span className="text-sm">Tip: Completează cel puțin o activitate zilnic pentru a menține streak-ul!</span>
                </div>
              </div>
            </div>
          </Card>

          {/* Step 3: Track Progress */}
          <Card className="p-6">
            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-emerald-600 font-bold">3</span>
              </div>
              <div className="flex-1">
                <h4 className="text-xl font-semibold text-gray-900 mb-3">
                  Urmărește progresul tău
                </h4>
                <p className="text-gray-700 mb-4">
                  Folosește acțiunile rapide pentru a accesa diferite părți ale aplicației:
                </p>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                    <BarChart3 className="text-green-600 text-lg" />
                    <div>
                      <p className="font-medium text-gray-900">Vezi progresul</p>
                      <p className="text-sm text-gray-600">Analizează statisticile detaliate și istoricul activităților</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-lime-50 rounded-lg">
                    <Book className="text-lime-600 text-lg" />
                    <div>
                      <p className="font-medium text-gray-900">Jurnal</p>
                      <p className="text-sm text-gray-600">Ține un jurnal personal cu reflecțiile și progresul tău</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Step 4: Access Settings */}
          <Card className="p-6">
            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-emerald-600 font-bold">4</span>
              </div>
              <div className="flex-1">
                <h4 className="text-xl font-semibold text-gray-900 mb-3">
                  Personalizează experiența
                </h4>
                <p className="text-gray-700 mb-4">
                  Accesează profilul tău prin iconița din colțul din dreapta sus pentru a configura:
                </p>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center space-x-3 mb-3">
                    <Settings className="text-gray-600 text-lg" />
                    <span className="font-medium text-gray-900">Setări disponibile:</span>
                  </div>
                  <ul className="space-y-2 text-sm text-gray-700 ml-6">
                    <li>• Notificări și alerte</li>
                    <li>• Preferințe de cont</li>
                    <li>• Setări de confidențialitate</li>
                    <li>• Obiecitive personale</li>
                  </ul>
                </div>
              </div>
            </div>
          </Card>

          {/* Tips Section */}
          <Card className="p-6 bg-gradient-to-r from-emerald-50 to-green-50 border-emerald-200">
            <h4 className="text-xl font-semibold text-gray-900 mb-4 text-center">
              Sfaturi pentru succes
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-start space-x-3">
                <CheckCircle className="text-emerald-600 h-5 w-5 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-gray-900">Consistența este cheia</p>
                  <p className="text-sm text-gray-700">Completează activități zilnic pentru a menține streak-ul</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <CheckCircle className="text-emerald-600 h-5 w-5 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-gray-900">Setează obiective realiste</p>
                  <p className="text-sm text-gray-700">Începe cu obiective mici și crește-le treptat</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <CheckCircle className="text-emerald-600 h-5 w-5 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-gray-900">Folosește jurnalul</p>
                  <p className="text-sm text-gray-700">Reflectă asupra progresului tău în jurnal</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <CheckCircle className="text-emerald-600 h-5 w-5 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-gray-900">Monitorizează statisticile</p>
                  <p className="text-sm text-gray-700">Verifică progresul săptămânal pentru motivație</p>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* CTA Section */}
        <div className="text-center mt-12">
          <Button 
            className="bg-emerald-600 text-white hover:bg-emerald-700 px-8 py-3 text-lg"
            onClick={() => window.location.href = '/'}
          >
            Începe acum
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
          <p className="text-gray-600 mt-4">
            Ești gata să îți începi călătoria de dezvoltare personală cu TranscendUp!
          </p>
        </div>
      </main>
    </div>
  );
}
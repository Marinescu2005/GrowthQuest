import { cn } from "@/lib/utils";
import { Card } from "@/components/ui/card";

interface ProgressCardProps {
  children: React.ReactNode;
  className?: string;
}

export function ProgressCard({ children, className }: ProgressCardProps) {
  return (
    <Card 
      className={cn(
        "p-6 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-0",
        className
      )}
    >
      {children}
    </Card>
  );
}

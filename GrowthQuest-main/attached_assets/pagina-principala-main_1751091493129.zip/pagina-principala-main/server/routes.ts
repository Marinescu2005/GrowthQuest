import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get user dashboard data
  app.get("/api/user/:id/dashboard", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const achievements = await storage.getUserAchievements(userId);
      const dailyProgress = await storage.getDailyProgress(userId, 7);

      // Calculate level progress
      const currentLevelXP = (user.currentLevel - 1) * 100;
      const nextLevelXP = user.currentLevel * 100;
      const xpForCurrentLevel = user.totalXP - currentLevelXP;
      const xpNeededForNextLevel = nextLevelXP - user.totalXP;
      const levelProgressPercent = Math.floor((xpForCurrentLevel / 100) * 100);

      // Generate streak visualization (last 7 days)
      const streakData = [];
      const today = new Date();
      for (let i = 6; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        const progress = dailyProgress.find(p => 
          p.date.toDateString() === date.toDateString()
        );
        streakData.push({
          date: date.toDateString(),
          hasActivity: progress ? progress.activitiesCompleted > 0 : false
        });
      }

      const dashboardData = {
        user: {
          id: user.id,
          displayName: user.displayName,
          totalXP: user.totalXP,
          currentLevel: user.currentLevel,
          currentStreak: user.currentStreak,
          completedActivities: user.completedActivities,
        },
        level: {
          current: user.currentLevel,
          xpForCurrentLevel,
          xpNeededForNextLevel,
          progressPercent: levelProgressPercent,
        },
        streak: {
          current: user.currentStreak,
          longest: user.longestStreak,
          data: streakData,
        },
        achievements: achievements.map(a => ({
          type: a.achievementType,
          unlockedAt: a.unlockedAt,
        })),
        stats: {
          totalActivities: user.completedActivities,
          totalXP: user.totalXP,
          currentStreak: user.currentStreak,
        }
      };

      res.json(dashboardData);
    } catch (error) {
      console.error("Dashboard error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Record activity completion
  app.post("/api/user/:id/activity", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { xpEarned = 10, activitiesCompleted = 1 } = req.body;

      const user = await storage.updateUserProgress(userId, xpEarned, activitiesCompleted);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Record daily progress
      await storage.recordDailyProgress({
        userId,
        date: new Date(),
        activitiesCompleted,
        xpEarned,
      });

      // Update streak
      await storage.updateUserStreak(userId);

      res.json({ message: "Activity recorded successfully", user });
    } catch (error) {
      console.error("Activity recording error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

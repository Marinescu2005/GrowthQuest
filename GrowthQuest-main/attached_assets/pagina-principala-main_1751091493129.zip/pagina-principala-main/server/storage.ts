import { users, userAchievements, dailyProgress, type User, type InsertUser, type UserAchievement, type DailyProgress, type InsertUserAchievement, type InsertDailyProgress } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserProgress(userId: number, xp: number, activities: number): Promise<User | undefined>;
  getUserAchievements(userId: number): Promise<UserAchievement[]>;
  addUserAchievement(achievement: InsertUserAchievement): Promise<UserAchievement>;
  getDailyProgress(userId: number, days: number): Promise<DailyProgress[]>;
  recordDailyProgress(progress: InsertDailyProgress): Promise<DailyProgress>;
  updateUserStreak(userId: number): Promise<User | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private userAchievements: Map<number, UserAchievement[]>;
  private dailyProgress: Map<string, DailyProgress>;
  private currentUserId: number;
  private currentAchievementId: number;
  private currentProgressId: number;

  constructor() {
    this.users = new Map();
    this.userAchievements = new Map();
    this.dailyProgress = new Map();
    this.currentUserId = 1;
    this.currentAchievementId = 1;
    this.currentProgressId = 1;

    // Create a demo user
    const demoUser: User = {
      id: 1,
      username: "player",
      password: "password",
      displayName: "Player",
      totalXP: 37,
      currentLevel: 1,
      currentStreak: 12,
      longestStreak: 15,
      completedActivities: 0,
      lastActivityDate: new Date(),
      createdAt: new Date(),
    };
    this.users.set(1, demoUser);
    this.currentUserId = 2;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      totalXP: 0,
      currentLevel: 1,
      currentStreak: 0,
      longestStreak: 0,
      completedActivities: 0,
      lastActivityDate: null,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserProgress(userId: number, xp: number, activities: number): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;

    const updatedUser: User = {
      ...user,
      totalXP: user.totalXP + xp,
      completedActivities: user.completedActivities + activities,
      currentLevel: Math.floor((user.totalXP + xp) / 100) + 1,
      lastActivityDate: new Date(),
    };

    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async getUserAchievements(userId: number): Promise<UserAchievement[]> {
    return this.userAchievements.get(userId) || [];
  }

  async addUserAchievement(achievement: InsertUserAchievement): Promise<UserAchievement> {
    const id = this.currentAchievementId++;
    const newAchievement: UserAchievement = {
      ...achievement,
      id,
      unlockedAt: new Date(),
    };

    const userAchievements = this.userAchievements.get(achievement.userId) || [];
    userAchievements.push(newAchievement);
    this.userAchievements.set(achievement.userId, userAchievements);

    return newAchievement;
  }

  async getDailyProgress(userId: number, days: number): Promise<DailyProgress[]> {
    const userProgress = Array.from(this.dailyProgress.values())
      .filter(progress => progress.userId === userId)
      .sort((a, b) => b.date.getTime() - a.date.getTime())
      .slice(0, days);

    return userProgress;
  }

  async recordDailyProgress(progress: InsertDailyProgress): Promise<DailyProgress> {
    const id = this.currentProgressId++;
    const newProgress: DailyProgress = {
      id,
      userId: progress.userId,
      date: progress.date,
      activitiesCompleted: progress.activitiesCompleted || 0,
      xpEarned: progress.xpEarned || 0,
    };

    const key = `${progress.userId}-${progress.date.toDateString()}`;
    this.dailyProgress.set(key, newProgress);

    return newProgress;
  }

  async updateUserStreak(userId: number): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;

    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    const todayProgress = Array.from(this.dailyProgress.values())
      .find(p => p.userId === userId && p.date.toDateString() === today.toDateString());

    if (todayProgress && todayProgress.activitiesCompleted > 0) {
      const updatedUser: User = {
        ...user,
        currentStreak: user.currentStreak + 1,
        longestStreak: Math.max(user.longestStreak, user.currentStreak + 1),
      };
      
      this.users.set(userId, updatedUser);
      return updatedUser;
    }

    return user;
  }
}

export const storage = new MemStorage();

# Progress Tracker Dashboard

## Overview

This is a full-stack web application that provides a gamified progress tracking dashboard. Users can track their activities, earn XP, maintain streaks, and unlock achievements. The application features a modern, responsive design with a language learning app aesthetic similar to Duolingo.

## System Architecture

The application follows a modern full-stack architecture with clear separation between client and server:

- **Frontend**: React + TypeScript with Vite bundler
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Styling**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack React Query for server state
- **Deployment**: Replit with autoscale deployment target

## Key Components

### Frontend Architecture
- **React Router**: Uses Wouter for client-side routing
- **UI Components**: Comprehensive shadcn/ui component library with custom styling
- **State Management**: TanStack React Query for server state synchronization
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Type Safety**: Full TypeScript integration with shared types

### Backend Architecture
- **Express Server**: RESTful API with TypeScript
- **ORM**: Drizzle with PostgreSQL for type-safe database operations
- **Storage Layer**: Abstracted storage interface with in-memory implementation for development
- **API Routes**: Modular route organization with proper error handling
- **Development**: Hot reloading with Vite integration

### Database Schema
The application uses three main tables:
- **users**: Core user information including XP, levels, streaks, and activity counts
- **userAchievements**: Achievement tracking with types and unlock timestamps
- **dailyProgress**: Daily activity and XP tracking for streak calculations

## Data Flow

1. **User Interaction**: Users interact with React components on the frontend
2. **API Calls**: TanStack React Query manages API calls to Express backend
3. **Data Processing**: Express routes handle business logic and data validation
4. **Storage**: Drizzle ORM manages database operations with PostgreSQL
5. **Response**: Data flows back through the same chain with proper error handling

The application implements a dashboard that displays:
- User progress with XP and level information
- Current and longest streak tracking
- Achievement badges with unlock status
- Visual streak calendar for the last 7 days
- Progress bars and gamified UI elements

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React, React DOM, React Router (Wouter)
- **Backend**: Express.js, Node.js types
- **Database**: Drizzle ORM, @neondatabase/serverless for PostgreSQL
- **State Management**: TanStack React Query

### UI and Styling
- **Component Library**: Extensive Radix UI primitives for accessibility
- **Styling**: Tailwind CSS, class-variance-authority for component variants
- **Icons**: Lucide React icon library
- **Utilities**: clsx, tailwind-merge for class management

### Development Tools
- **Build Tools**: Vite, esbuild for production builds
- **Type Safety**: TypeScript, Zod for runtime validation
- **Development**: tsx for TypeScript execution, Replit-specific plugins

## Deployment Strategy

The application is configured for Replit deployment with:
- **Development**: `npm run dev` using tsx for hot reloading
- **Build Process**: Vite builds frontend, esbuild bundles backend
- **Production**: `npm run start` serves the built application
- **Database**: PostgreSQL module enabled in Replit environment
- **Port Configuration**: Server runs on port 5000, mapped to external port 80
- **Autoscale**: Configured for automatic scaling based on traffic

The deployment uses a parallel workflow that starts the application and waits for the port to be available before marking as ready.

## Changelog

Changelog:
- June 24, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.
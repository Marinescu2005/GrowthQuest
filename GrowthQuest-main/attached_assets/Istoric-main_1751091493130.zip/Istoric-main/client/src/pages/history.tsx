import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChartLine, Clock, Target, Trophy, User } from "lucide-react";

export default function History() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header similar to existing app */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-blue-500 rounded-lg flex items-center justify-center">
                <ChartLine className="text-white w-4 h-4" />
              </div>
              <h1 className="text-xl font-bold text-gray-900">TranscendUp</h1>
              <span className="text-gray-400">|</span>
              <h2 className="text-lg font-medium text-gray-700">Istoric & Statistici</h2>
            </div>
            


            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" className="text-gray-600">🔍</Button>
              <Button variant="ghost" size="sm" className="text-gray-600">⬇️</Button>
              <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                <User className="text-white w-4 h-4" />
              </div>
            </div>
          </div>
        </div>
      </header>
      
      {/* Main Content */}
      <div className="bg-white min-h-screen">
        <div className="max-w-6xl mx-auto px-4 py-8">
          {/* Simplified Header */}
          <div className="text-center mb-12">
            <h1 className="text-3xl font-bold text-gray-900 mb-3">
              Istoric & Statistici
            </h1>
            <p className="text-gray-600 mb-8 max-w-xl mx-auto">
              Vizualizează progresul tău în câteva secțiuni simple
            </p>
          </div>

          {/* Simple Navigation Cards - Only Essential Options */}
          <div className="max-w-3xl mx-auto mb-12">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Link href="/timeline">
                <Card className="hover:shadow-md transition-all cursor-pointer group">
                  <CardContent className="p-8 text-center">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-green-200 transition-colors">
                      <Clock className="w-8 h-8 text-green-600" />
                    </div>
                    <h3 className="text-xl font-medium text-gray-900 mb-2">Cronologie</h3>
                    <p className="text-gray-500">Vizualizează realizările și momentele importante din timpul tău în TranscendUp</p>
                  </CardContent>
                </Card>
              </Link>

              <Link href="/analytics">
                <Card className="hover:shadow-md transition-all cursor-pointer group">
                  <CardContent className="p-8 text-center">
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-200 transition-colors">
                      <Trophy className="w-8 h-8 text-blue-600" />
                    </div>
                    <h3 className="text-xl font-medium text-gray-900 mb-2">Analiză</h3>
                    <p className="text-gray-500">Statistici detaliate și grafice pentru a înțelege progresul tău</p>
                  </CardContent>
                </Card>
              </Link>
            </div>
          </div>

          {/* Compact Stats Preview */}
          <div className="max-w-2xl mx-auto">
            <div className="bg-gray-50 rounded-lg p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4 text-center">Progres Rapid</h2>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-500 mb-1">247</div>
                  <div className="text-gray-600 text-xs">Zile Active</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-500 mb-1">1,234</div>
                  <div className="text-gray-600 text-xs">Obiective</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-500 mb-1">37</div>
                  <div className="text-gray-600 text-xs">Nivel</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-4 mb-4 md:mb-0">
              <div className="w-6 h-6 bg-gradient-to-r from-green-500 to-blue-500 rounded"></div>
              <span className="text-gray-600 text-sm">© 2024 TranscendUp. Toate drepturile rezervate.</span>
            </div>
            <div className="flex space-x-6 text-sm">
              <Link href="/" className="text-gray-600 hover:text-blue-600">Acasă</Link>
              <Link href="/profile" className="text-gray-600 hover:text-blue-600">Profil</Link>
              <Link href="/settings" className="text-gray-600 hover:text-blue-600">Setări</Link>
              <Link href="/support" className="text-gray-600 hover:text-blue-600">Suport</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

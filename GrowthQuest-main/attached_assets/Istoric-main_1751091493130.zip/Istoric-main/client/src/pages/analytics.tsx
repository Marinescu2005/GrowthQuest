import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import PerformanceChart from "@/components/charts/performance-chart";
import CategoryChart from "@/components/charts/category-chart";
import { Filter, Download } from "lucide-react";

export default function Analytics() {
  const { data: statistics, isLoading } = useQuery({
    queryKey: ['/api/user/1/statistics'],
  });

  const { data: dashboardData } = useQuery({
    queryKey: ['/api/user/1/dashboard'],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="animate-pulse space-y-8">
            <div className="h-8 bg-gray-200 rounded w-1/3 mx-auto"></div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 h-96 bg-gray-200 rounded-xl"></div>
              <div className="h-80 bg-gray-200 rounded-xl"></div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const monthlyData = statistics?.filter(stat => stat.period === 'monthly').slice(0, 12) || [];
  const chartData = monthlyData.map(stat => stat.objectivesCompleted);
  const chartLabels = monthlyData.map(stat => 
    new Date(stat.date).toLocaleDateString('ro-RO', { month: 'short' })
  );

  const getStatusBadge = (objectives: number) => {
    if (objectives >= 90) return { text: 'Excelent', variant: 'default' as const, className: 'bg-green-50 text-green-600' };
    if (objectives >= 70) return { text: 'Bun', variant: 'secondary' as const, className: 'bg-blue-50 text-blue-600' };
    return { text: 'Mediu', variant: 'outline' as const, className: 'bg-yellow-50 text-yellow-600' };
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Analytics Section */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Analiză Detaliată</h2>
            <p className="text-gray-600 text-lg">Statistici complete despre progresul și utilizarea platformei</p>
          </div>

          {/* Analytics Dashboard */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            {/* Performance Metrics */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-lg font-semibold text-gray-900">
                      Performanța Lunară
                    </CardTitle>
                    <div className="flex space-x-2">
                      <Button size="sm" className="bg-green-500 hover:bg-green-600 text-white">
                        Obiective
                      </Button>
                      <Button size="sm" variant="outline" className="text-gray-600 border-gray-300 hover:bg-gray-50">
                        XP
                      </Button>
                      <Button size="sm" variant="outline" className="text-gray-600 border-gray-300 hover:bg-gray-50">
                        Timp
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="flex justify-center">
                    <div className="w-full max-w-3xl">
                      <PerformanceChart data={chartData} labels={chartLabels} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Category Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">
                  Categorii Obiective
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                {dashboardData && (
                  <>
                    <div className="flex justify-center mb-4">
                      <div className="w-full max-w-xs">
                        <CategoryChart data={dashboardData.categoryBreakdown} />
                      </div>
                    </div>
                    <div className="space-y-2 text-sm mt-4">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-2">
                          <div className="w-3 h-3 bg-transcend-green rounded-full"></div>
                          <span>Sănătate</span>
                        </div>
                        <span className="font-medium">32%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-2">
                          <div className="w-3 h-3 bg-transcend-blue rounded-full"></div>
                          <span>Carieră</span>
                        </div>
                        <span className="font-medium">28%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-2">
                          <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                          <span>Personal</span>
                        </div>
                        <span className="font-medium">24%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-2">
                          <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                          <span>Social</span>
                        </div>
                        <span className="font-medium">16%</span>
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Detailed Statistics Table */}
          <Card className="overflow-hidden">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-lg font-semibold text-gray-900">
                  Statistici Detaliate
                </CardTitle>
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline" className="text-gray-600">
                    <Filter className="w-4 h-4 mr-1" />
                    Filtrează
                  </Button>
                  <Button size="sm" className="bg-blue-500 hover:bg-blue-600 text-white">
                    <Download className="w-4 h-4 mr-1" />
                    Export
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Perioada
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Obiective
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        XP Câștigat
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Streak
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Timp (ore)
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {monthlyData.map((stat) => {
                      const status = getStatusBadge(stat.objectivesCompleted);
                      return (
                        <tr key={stat.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {new Date(stat.date).toLocaleDateString('ro-RO', {
                              month: 'long',
                              year: 'numeric'
                            })}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {stat.objectivesCompleted}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {stat.xpEarned.toLocaleString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {stat.streakDays} zile
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {Math.round(stat.timeSpent / 60)} ore
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <Badge variant={status.variant} className={`${status.className} hover:${status.className}`}>
                              {status.text}
                            </Badge>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  );
}

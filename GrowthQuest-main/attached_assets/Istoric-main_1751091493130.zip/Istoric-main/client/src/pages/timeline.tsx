import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Calendar } from "lucide-react";

export default function Timeline() {
  const { data: milestones, isLoading } = useQuery({
    queryKey: ['/api/user/1/milestones'],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="animate-pulse space-y-8">
            <div className="h-8 bg-gray-200 rounded w-1/3 mx-auto"></div>
            <div className="space-y-6">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const getColorForType = (type: string) => {
    switch (type) {
      case 'level':
        return 'bg-blue-500';
      case 'streak':
        return 'bg-yellow-500';
      case 'major_goal':
        return 'bg-purple-500';
      case 'achievement':
      default:
        return 'bg-green-500';
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Timeline Section */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Cronologia Dezvoltării</h2>
            <p className="text-transcend-gray text-lg">Momentele importante din călătoria ta în TranscendUp</p>
          </div>

          {/* Timeline Filter */}
          <div className="flex justify-center mb-8">
            <div className="bg-gray-50 rounded-lg p-1 shadow-sm border border-gray-200">
              <Button size="sm" className="bg-blue-500 hover:bg-blue-600 text-white">
                Toate
              </Button>
              <Button size="sm" variant="ghost" className="text-gray-600 hover:text-blue-600">
                2024
              </Button>
              <Button size="sm" variant="ghost" className="text-gray-600 hover:text-blue-600">
                2023
              </Button>
              <Button size="sm" variant="ghost" className="text-gray-600 hover:text-blue-600">
                2022
              </Button>
            </div>
          </div>

          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-px h-full w-0.5 bg-gray-200"></div>

            {milestones?.map((milestone, index) => (
              <div
                key={milestone.id}
                className={`relative flex items-center justify-between mb-8 ${
                  index % 2 === 0 ? '' : 'flex-row-reverse'
                }`}
              >
                <div className={`w-5/12 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8'}`}>
                  <Card className="hover:shadow-xl transition-shadow">
                    <CardContent className="p-6">
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        {milestone.title}
                      </h3>
                      <p className="text-gray-600 mb-3">
                        {milestone.description}
                      </p>
                      <div className={`flex items-center text-sm text-blue-600 ${
                        index % 2 === 0 ? 'justify-end' : 'justify-start'
                      }`}>
                        <Calendar className="w-4 h-4 mr-2" />
                        <span>
                          {new Date(milestone.achievedAt!).toLocaleDateString('ro-RO', {
                            day: 'numeric',
                            month: 'long',
                            year: 'numeric'
                          })}
                        </span>
                      </div>
                      {milestone.xpAwarded > 0 && (
                        <div className={`mt-2 text-sm font-medium text-green-600 ${
                          index % 2 === 0 ? 'text-right' : 'text-left'
                        }`}>
                          +{milestone.xpAwarded} XP
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
                <div className={`absolute left-1/2 transform -translate-x-1/2 w-4 h-4 ${getColorForType(milestone.type)} rounded-full border-4 border-white shadow-md`}></div>
                <div className="w-5/12"></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

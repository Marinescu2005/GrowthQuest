export const chartColors = {
  transcendGreen: '#10B981',
  transcendBlue: '#3B82F6',
  yellow: '#F59E0B',
  purple: '#A855F7',
  gray: '#6B7280',
  red: '#EF4444',
  orange: '#F97316',
  teal: '#14B8A6',
};

export const defaultChartOptions = {
  responsive: true,
  maintainAspectRatio: true,
  aspectRatio: 2.5,
  plugins: {
    legend: {
      display: false,
    },
  },
  scales: {
    y: {
      beginAtZero: true,
      grid: {
        color: 'rgba(0, 0, 0, 0.05)',
      },
      ticks: {
        font: {
          size: 11,
        },
      },
    },
    x: {
      grid: {
        color: 'rgba(0, 0, 0, 0.05)',
      },
      ticks: {
        font: {
          size: 11,
        },
      },
    },
  },
};

export const doughnutChartOptions = {
  responsive: true,
  maintainAspectRatio: true,
  aspectRatio: 1.2,
  plugins: {
    legend: {
      display: false,
    },
  },
  cutout: '65%',
};

import { useEffect, useRef } from 'react';
import { Chart, registerables } from 'chart.js';
import { chartColors, defaultChartOptions } from '@/lib/chart-config';

Chart.register(...registerables);

interface FeatureGrowthChartProps {
  data: { version: string; features: number }[];
}

export default function FeatureGrowthChart({ data }: FeatureGrowthChartProps) {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);

  useEffect(() => {
    if (!chartRef.current) return;

    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;

    const colors = [
      chartColors.gray,
      chartColors.yellow,
      chartColors.transcendBlue,
      chartColors.purple,
      chartColors.transcendGreen
    ];

    chartInstance.current = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: data.map(d => `v${d.version}`),
        datasets: [{
          label: 'Funcționalități',
          data: data.map(d => d.features),
          backgroundColor: colors.slice(0, data.length),
          borderRadius: 4
        }]
      },
      options: {
        ...defaultChartOptions,
        scales: {
          ...defaultChartOptions.scales,
          x: {
            grid: {
              display: false
            }
          }
        }
      }
    });

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data]);

  return (
    <div className="w-full" style={{ height: '200px' }}>
      <canvas ref={chartRef} className="w-full h-full" />
    </div>
  );
}

import { useEffect, useRef } from 'react';
import { Chart, registerables } from 'chart.js';
import { chartColors, defaultChartOptions } from '@/lib/chart-config';

Chart.register(...registerables);

interface WeeklyProgressChartProps {
  data: number[];
  labels?: string[];
}

export default function WeeklyProgressChart({ 
  data, 
  labels = ['Lun', 'Mar', 'Mie', 'Joi', 'Vin', 'Sâm', 'Dum'] 
}: WeeklyProgressChartProps) {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);

  useEffect(() => {
    if (!chartRef.current) return;

    // Destroy existing chart
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;

    chartInstance.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [{
          label: 'Obiective Completate',
          data,
          borderColor: chartColors.transcendGreen,
          backgroundColor: `${chartColors.transcendGreen}20`,
          borderWidth: 2,
          fill: true,
          tension: 0.4,
        }]
      },
      options: defaultChartOptions
    });

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data, labels]);

  return (
    <div className="w-full" style={{ height: '200px' }}>
      <canvas ref={chartRef} className="w-full h-full" />
    </div>
  );
}

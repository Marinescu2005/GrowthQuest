import { useEffect, useRef } from 'react';
import { Chart, registerables } from 'chart.js';
import { chartColors, doughnutChartOptions } from '@/lib/chart-config';

Chart.register(...registerables);

interface CategoryChartProps {
  data: {
    health: number;
    career: number;
    personal: number;
    social: number;
  };
}

export default function CategoryChart({ data }: CategoryChartProps) {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);

  useEffect(() => {
    if (!chartRef.current) return;

    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;

    const total = data.health + data.career + data.personal + data.social;
    const percentages = {
      health: Math.round((data.health / total) * 100),
      career: Math.round((data.career / total) * 100),
      personal: Math.round((data.personal / total) * 100),
      social: Math.round((data.social / total) * 100),
    };

    chartInstance.current = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['Sănătate', 'Carieră', 'Personal', 'Social'],
        datasets: [{
          data: [percentages.health, percentages.career, percentages.personal, percentages.social],
          backgroundColor: [
            chartColors.transcendGreen,
            chartColors.transcendBlue,
            chartColors.yellow,
            chartColors.purple
          ],
          borderWidth: 0
        }]
      },
      options: doughnutChartOptions
    });

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data]);

  return (
    <div className="w-full" style={{ height: '180px' }}>
      <canvas ref={chartRef} className="w-full h-full" />
    </div>
  );
}

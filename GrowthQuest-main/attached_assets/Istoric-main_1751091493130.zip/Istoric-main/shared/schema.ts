import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  level: integer("level").default(1),
  totalXP: integer("total_xp").default(0),
  currentStreak: integer("current_streak").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const objectives = pgTable("objectives", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  category: text("category").notNull(),
  xpValue: integer("xp_value").default(10),
  completed: boolean("completed").default(false),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const milestones = pgTable("milestones", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // 'level', 'streak', 'achievement', 'major_goal'
  xpAwarded: integer("xp_awarded").default(0),
  achievedAt: timestamp("achieved_at").defaultNow(),
});

export const statistics = pgTable("statistics", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  period: text("period").notNull(), // 'daily', 'weekly', 'monthly'
  date: timestamp("date").notNull(),
  objectivesCompleted: integer("objectives_completed").default(0),
  xpEarned: integer("xp_earned").default(0),
  streakDays: integer("streak_days").default(0),
  timeSpent: integer("time_spent").default(0), // in minutes
  metadata: jsonb("metadata"), // additional stats data
});

export const platformVersions = pgTable("platform_versions", {
  id: serial("id").primaryKey(),
  version: text("version").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  releaseDate: timestamp("release_date").notNull(),
  featuresCount: integer("features_count").default(0),
  majorUpdate: boolean("major_update").default(false),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertObjectiveSchema = createInsertSchema(objectives).pick({
  userId: true,
  title: true,
  category: true,
  xpValue: true,
});

export const insertMilestoneSchema = createInsertSchema(milestones).pick({
  userId: true,
  title: true,
  description: true,
  type: true,
  xpAwarded: true,
});

export const insertStatisticsSchema = createInsertSchema(statistics).pick({
  userId: true,
  period: true,
  date: true,
  objectivesCompleted: true,
  xpEarned: true,
  streakDays: true,
  timeSpent: true,
  metadata: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Objective = typeof objectives.$inferSelect;
export type InsertObjective = z.infer<typeof insertObjectiveSchema>;
export type Milestone = typeof milestones.$inferSelect;
export type InsertMilestone = z.infer<typeof insertMilestoneSchema>;
export type Statistics = typeof statistics.$inferSelect;
export type InsertStatistics = z.infer<typeof insertStatisticsSchema>;
export type PlatformVersion = typeof platformVersions.$inferSelect;

import { users, objectives, milestones, statistics, platformVersions, type User, type InsertUser, type Objective, type InsertObjective, type Milestone, type InsertMilestone, type Statistics, type InsertStatistics, type PlatformVersion } from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStats(userId: number, level: number, totalXP: number, currentStreak: number): Promise<void>;

  // Objective methods
  getUserObjectives(userId: number): Promise<Objective[]>;
  getObjectivesByCategory(userId: number, category: string): Promise<Objective[]>;
  createObjective(objective: InsertObjective): Promise<Objective>;
  completeObjective(id: number): Promise<void>;

  // Milestone methods
  getUserMilestones(userId: number): Promise<Milestone[]>;
  createMilestone(milestone: InsertMilestone): Promise<Milestone>;

  // Statistics methods
  getUserStatistics(userId: number, period?: string): Promise<Statistics[]>;
  getStatisticsByDateRange(userId: number, startDate: Date, endDate: Date): Promise<Statistics[]>;
  createStatistics(stats: InsertStatistics): Promise<Statistics>;

  // Platform version methods
  getPlatformVersions(): Promise<PlatformVersion[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private objectives: Map<number, Objective>;
  private milestones: Map<number, Milestone>;
  private statistics: Map<number, Statistics>;
  private platformVersions: Map<number, PlatformVersion>;
  private currentUserId: number;
  private currentObjectiveId: number;
  private currentMilestoneId: number;
  private currentStatsId: number;
  private currentVersionId: number;

  constructor() {
    this.users = new Map();
    this.objectives = new Map();
    this.milestones = new Map();
    this.statistics = new Map();
    this.platformVersions = new Map();
    this.currentUserId = 1;
    this.currentObjectiveId = 1;
    this.currentMilestoneId = 1;
    this.currentStatsId = 1;
    this.currentVersionId = 1;

    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Create sample user
    const sampleUser: User = {
      id: 1,
      username: "demo_user",
      password: "password",
      level: 37,
      totalXP: 15847,
      currentStreak: 12,
      createdAt: new Date("2023-01-15"),
    };
    this.users.set(1, sampleUser);
    this.currentUserId = 2;

    // Create sample milestones
    const sampleMilestones: Milestone[] = [
      {
        id: 1,
        userId: 1,
        title: "Prima Conectare",
        description: "Ai început călătoria de dezvoltare personală cu primul obiectiv stabilit și profilul complet.",
        type: "achievement",
        xpAwarded: 100,
        achievedAt: new Date("2023-01-15"),
      },
      {
        id: 2,
        userId: 1,
        title: "Primul Nivel Atins",
        description: "Ai ajuns la Nivelul 5 după ce ai completat 50 de obiective și ai acumulat primele 500 XP.",
        type: "level",
        xpAwarded: 200,
        achievedAt: new Date("2023-02-28"),
      },
      {
        id: 3,
        userId: 1,
        title: "Streak de 30 de Zile",
        description: "Prima ta perioadă de consistență de 30 de zile consecutive cu obiective completate zilnic.",
        type: "streak",
        xpAwarded: 500,
        achievedAt: new Date("2023-05-15"),
      },
      {
        id: 4,
        userId: 1,
        title: "Obiectiv Major Completat",
        description: "Ai finalizat primul tău obiectiv pe termen lung de 6 luni, câștigând 2000 XP bonus.",
        type: "major_goal",
        xpAwarded: 2000,
        achievedAt: new Date("2023-09-10"),
      },
      {
        id: 5,
        userId: 1,
        title: "Nivel Expert Atins",
        description: "Ai ajuns la Nivelul 37 și ai deblocat funcții avansate de analiză și planificare.",
        type: "level",
        xpAwarded: 1000,
        achievedAt: new Date("2024-12-22"),
      },
    ];

    sampleMilestones.forEach(milestone => {
      this.milestones.set(milestone.id, milestone);
    });
    this.currentMilestoneId = 6;

    // Create sample statistics for the past 12 months
    const currentDate = new Date();
    const monthlyData = [
      { month: 0, objectives: 45, xp: 1200, streak: 8 },
      { month: 1, objectives: 62, xp: 1650, streak: 12 },
      { month: 2, objectives: 78, xp: 2080, streak: 15 },
      { month: 3, objectives: 85, xp: 2270, streak: 18 },
      { month: 4, objectives: 95, xp: 2540, streak: 22 },
      { month: 5, objectives: 88, xp: 2350, streak: 19 },
      { month: 6, objectives: 92, xp: 2460, streak: 20 },
      { month: 7, objectives: 98, xp: 2620, streak: 25 },
      { month: 8, objectives: 105, xp: 2810, streak: 28 },
      { month: 9, objectives: 112, xp: 2990, streak: 30 },
      { month: 10, objectives: 89, xp: 2380, streak: 16 },
      { month: 11, objectives: 98, xp: 2620, streak: 22 },
    ];

    monthlyData.forEach((data, index) => {
      const date = new Date(currentDate.getFullYear(), index, 1);
      const stats: Statistics = {
        id: index + 1,
        userId: 1,
        period: "monthly",
        date,
        objectivesCompleted: data.objectives,
        xpEarned: data.xp,
        streakDays: data.streak,
        timeSpent: Math.floor(data.objectives * 15), // approximate 15 minutes per objective
        metadata: {
          categories: {
            health: Math.floor(data.objectives * 0.32),
            career: Math.floor(data.objectives * 0.28),
            personal: Math.floor(data.objectives * 0.24),
            social: Math.floor(data.objectives * 0.16),
          }
        },
      };
      this.statistics.set(stats.id, stats);
    });
    this.currentStatsId = 13;

    // Create platform versions
    const versions: PlatformVersion[] = [
      {
        id: 1,
        version: "1.0",
        title: "TranscendUp Launch",
        description: "Versiunea inițială cu funcționalități de bază pentru obiective și tracking.",
        releaseDate: new Date("2023-01-01"),
        featuresCount: 15,
        majorUpdate: true,
      },
      {
        id: 2,
        version: "1.5",
        title: "Enhanced UI",
        description: "Îmbunătățiri la interfața utilizator și experiența generală.",
        releaseDate: new Date("2023-04-15"),
        featuresCount: 28,
        majorUpdate: false,
      },
      {
        id: 3,
        version: "2.0",
        title: "Advanced Analytics",
        description: "Dashboard-uri avansate, rapoarte detaliate și predicții de progres.",
        releaseDate: new Date("2024-05-01"),
        featuresCount: 45,
        majorUpdate: true,
      },
      {
        id: 4,
        version: "2.5",
        title: "Community Features",
        description: "Funcții sociale: grupuri, provocări comunitare și sistem de mentoring.",
        releaseDate: new Date("2024-09-15"),
        featuresCount: 72,
        majorUpdate: false,
      },
      {
        id: 5,
        version: "3.0",
        title: "AI Integration",
        description: "Asistent AI pentru recomandări personalizate și analiză avansată.",
        releaseDate: new Date("2024-12-01"),
        featuresCount: 98,
        majorUpdate: true,
      },
    ];

    versions.forEach(version => {
      this.platformVersions.set(version.id, version);
    });
    this.currentVersionId = 6;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      level: 1, 
      totalXP: 0, 
      currentStreak: 0,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserStats(userId: number, level: number, totalXP: number, currentStreak: number): Promise<void> {
    const user = this.users.get(userId);
    if (user) {
      user.level = level;
      user.totalXP = totalXP;
      user.currentStreak = currentStreak;
      this.users.set(userId, user);
    }
  }

  async getUserObjectives(userId: number): Promise<Objective[]> {
    return Array.from(this.objectives.values()).filter(obj => obj.userId === userId);
  }

  async getObjectivesByCategory(userId: number, category: string): Promise<Objective[]> {
    return Array.from(this.objectives.values()).filter(obj => 
      obj.userId === userId && obj.category === category
    );
  }

  async createObjective(insertObjective: InsertObjective): Promise<Objective> {
    const id = this.currentObjectiveId++;
    const objective: Objective = { 
      ...insertObjective, 
      id, 
      completed: false,
      completedAt: null,
      createdAt: new Date()
    };
    this.objectives.set(id, objective);
    return objective;
  }

  async completeObjective(id: number): Promise<void> {
    const objective = this.objectives.get(id);
    if (objective) {
      objective.completed = true;
      objective.completedAt = new Date();
      this.objectives.set(id, objective);
    }
  }

  async getUserMilestones(userId: number): Promise<Milestone[]> {
    return Array.from(this.milestones.values())
      .filter(milestone => milestone.userId === userId)
      .sort((a, b) => b.achievedAt!.getTime() - a.achievedAt!.getTime());
  }

  async createMilestone(insertMilestone: InsertMilestone): Promise<Milestone> {
    const id = this.currentMilestoneId++;
    const milestone: Milestone = { 
      ...insertMilestone, 
      id,
      achievedAt: new Date()
    };
    this.milestones.set(id, milestone);
    return milestone;
  }

  async getUserStatistics(userId: number, period?: string): Promise<Statistics[]> {
    return Array.from(this.statistics.values())
      .filter(stats => stats.userId === userId && (!period || stats.period === period))
      .sort((a, b) => b.date.getTime() - a.date.getTime());
  }

  async getStatisticsByDateRange(userId: number, startDate: Date, endDate: Date): Promise<Statistics[]> {
    return Array.from(this.statistics.values())
      .filter(stats => 
        stats.userId === userId && 
        stats.date >= startDate && 
        stats.date <= endDate
      )
      .sort((a, b) => a.date.getTime() - b.date.getTime());
  }

  async createStatistics(insertStats: InsertStatistics): Promise<Statistics> {
    const id = this.currentStatsId++;
    const stats: Statistics = { ...insertStats, id };
    this.statistics.set(id, stats);
    return stats;
  }

  async getPlatformVersions(): Promise<PlatformVersion[]> {
    return Array.from(this.platformVersions.values())
      .sort((a, b) => a.releaseDate.getTime() - b.releaseDate.getTime());
  }
}

export const storage = new MemStorage();

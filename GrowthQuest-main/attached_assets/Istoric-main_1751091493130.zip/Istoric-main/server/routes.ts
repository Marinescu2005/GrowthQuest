import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get user profile with stats
  app.get("/api/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Get user milestones
  app.get("/api/user/:userId/milestones", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const milestones = await storage.getUserMilestones(userId);
      res.json(milestones);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch milestones" });
    }
  });

  // Get user statistics
  app.get("/api/user/:userId/statistics", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const period = req.query.period as string;
      const statistics = await storage.getUserStatistics(userId, period);
      res.json(statistics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // Get statistics by date range
  app.get("/api/user/:userId/statistics/range", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const startDate = new Date(req.query.startDate as string);
      const endDate = new Date(req.query.endDate as string);
      
      const statistics = await storage.getStatisticsByDateRange(userId, startDate, endDate);
      res.json(statistics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch statistics range" });
    }
  });

  // Get platform versions
  app.get("/api/platform/versions", async (req, res) => {
    try {
      const versions = await storage.getPlatformVersions();
      res.json(versions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch platform versions" });
    }
  });

  // Get user objectives
  app.get("/api/user/:userId/objectives", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const category = req.query.category as string;
      
      const objectives = category 
        ? await storage.getObjectivesByCategory(userId, category)
        : await storage.getUserObjectives(userId);
        
      res.json(objectives);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch objectives" });
    }
  });

  // Get dashboard summary
  app.get("/api/user/:userId/dashboard", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      const user = await storage.getUser(userId);
      const recentMilestones = (await storage.getUserMilestones(userId)).slice(0, 3);
      const monthlyStats = await storage.getUserStatistics(userId, "monthly");
      const objectives = await storage.getUserObjectives(userId);
      
      const totalDays = Math.floor((new Date().getTime() - user!.createdAt!.getTime()) / (1000 * 60 * 60 * 24));
      const completedObjectives = objectives.filter(obj => obj.completed).length;
      
      // Calculate weekly progress (last 7 days)
      const weeklyProgress = [12, 8, 15, 10, 18, 6, 9]; // Mock data for demo
      
      // Calculate category breakdown
      const categoryBreakdown = {
        health: Math.floor(completedObjectives * 0.32),
        career: Math.floor(completedObjectives * 0.28),
        personal: Math.floor(completedObjectives * 0.24),
        social: Math.floor(completedObjectives * 0.16),
      };

      res.json({
        user,
        totalDays,
        completedObjectives,
        recentMilestones,
        monthlyStats: monthlyStats.slice(0, 12),
        weeklyProgress,
        categoryBreakdown
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

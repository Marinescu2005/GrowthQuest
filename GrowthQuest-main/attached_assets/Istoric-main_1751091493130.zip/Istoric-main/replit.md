# TranscendUp History & Statistics Dashboard

## Overview

This is a full-stack React application that provides a comprehensive history and statistics dashboard for the TranscendUp platform. The application tracks user progress, objectives, milestones, and statistics over time, offering multiple visualization views including overview, timeline, evolution, and analytics.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with custom TranscendUp brand colors
- **Charts**: Chart.js for data visualization
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js for API server
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (@neondatabase/serverless)
- **Session Management**: PostgreSQL session store (connect-pg-simple)
- **Development**: Full-stack development with Vite middleware integration

### Database Schema
The application uses a PostgreSQL database with the following main tables:
- **users**: User profiles with level, XP, and streak tracking
- **objectives**: User tasks/goals with categories and completion status
- **milestones**: Achievement tracking for levels, streaks, and major goals
- **statistics**: Time-series data for daily/weekly/monthly progress
- **platform_versions**: Version history for platform evolution tracking

## Key Components

### Pages
- **History**: Landing page with feature overview and navigation
- **Timeline**: Chronological view of user milestones and achievements
- **Analytics**: Advanced statistics with performance charts and insights

### Charts & Visualizations
- **Performance Chart**: Line charts showing progress over time
- **Category Chart**: Doughnut charts for objective distribution
- **Weekly Progress Chart**: Bar charts for weekly completion rates
- **Feature Growth Chart**: Timeline visualization for platform evolution

### UI Components
- Comprehensive component library based on Radix UI
- Custom branded color scheme (TranscendUp green/blue)
- Responsive design with mobile-first approach
- Accessible components with proper ARIA labels

## Data Flow

1. **Client Requests**: React components use TanStack Query for data fetching
2. **API Layer**: Express.js routes handle HTTP requests and responses
3. **Data Access**: Storage layer abstracts database operations
4. **Database**: PostgreSQL stores all user data and statistics
5. **Real-time Updates**: Query invalidation ensures fresh data

The application follows a RESTful API pattern with endpoints for:
- User profile and statistics (`/api/user/:userId`)
- Milestones tracking (`/api/user/:userId/milestones`)
- Time-series statistics (`/api/user/:userId/statistics`)
- Date range queries (`/api/user/:userId/statistics/range`)

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **chart.js**: Data visualization library
- **@radix-ui/***: Accessible UI primitives
- **wouter**: Lightweight React router

### Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type safety and developer experience
- **Tailwind CSS**: Utility-first CSS framework
- **ESBuild**: Fast JavaScript bundler for production

## Deployment Strategy

### Development Environment
- **Runtime**: Node.js 20 with TypeScript execution via `tsx`
- **Database**: PostgreSQL 16 module in Replit
- **Development Server**: Vite dev server with HMR
- **Port Configuration**: Application runs on port 5000

### Production Build
- **Client Build**: Vite builds React app to `dist/public`
- **Server Build**: ESBuild bundles server code to `dist/index.js`
- **Database Migrations**: Drizzle Kit handles schema migrations
- **Deployment**: Replit autoscale deployment target

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **NODE_ENV**: Environment mode (development/production)
- **Build Scripts**: Separate build commands for client and server

## Changelog

- June 24, 2025. Initial setup
- June 24, 2025. Optimized page design to match existing TranscendUp interface
  - Updated color scheme from custom transcend colors to standard green/blue theme
  - Improved chart sizing and centering (180px-250px heights)
  - Redesigned layout to match RPG-style interface with consistent white backgrounds
  - Removed duplicate elements and aligned with existing design patterns
- June 24, 2025. Simplified interface for minimalist user experience
  - Reduced navigation to only 3 essential sections (removed Evolution page)
  - Compressed stats cards and charts to smaller, more compact sizes
  - Eliminated complex layouts in favor of clean, simple designs
  - Focused on essential information only to reduce cognitive load
- June 24, 2025. Removed Evolution section completely
  - User feedback indicated Evolution page was not relevant for a pre-launch site
  - Cleaned up navigation and routing to reflect 3-section structure
  - Updated documentation to reflect simplified architecture
- June 24, 2025. Removed Overview/Prezentare section per user request
  - User wanted to eliminate the overview page entirely
  - Simplified navigation to only Timeline and Analytics
  - Updated routing and navigation to reflect 2-section structure
- June 25, 2025. Enhanced chart responsiveness and mobile centering
  - Improved chart centering for all screen sizes including mobile
  - Added responsive sizing with Tailwind classes instead of fixed dimensions
  - Enhanced chart padding and mobile font sizes for better readability

## User Preferences

Preferred communication style: Simple, everyday language.
Design preference: Clean, consistent interface matching existing TranscendUp RPG-style theme.
Interface approach: Minimalist design with only essential options and small, well-designed charts for optimal user experience.
Content preference: Focus only on relevant features for a pre-launch site, avoid placeholder or irrelevant sections.
Overview page preference: More comprehensive analytics with multiple charts and integrated history/progress options while maintaining clean design.